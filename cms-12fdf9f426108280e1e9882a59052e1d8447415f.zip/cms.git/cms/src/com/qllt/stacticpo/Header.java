package com.qllt.stacticpo;

import java.util.List;

import com.qllt.po.Menu;
import com.qllt.po.SubMenu;

public class Header {
	private List<Menu> menus;
	private List<SubMenu> subMenus;
	public List<Menu> getMenus() {
		return menus;
	}
	public void setMenus(List<Menu> menus) {
		this.menus = menus;
	}
	public List<SubMenu> getSubMenus() {
		return subMenus;
	}
	public void setSubMenus(List<SubMenu> subMenus) {
		this.subMenus = subMenus;
	}
	
}

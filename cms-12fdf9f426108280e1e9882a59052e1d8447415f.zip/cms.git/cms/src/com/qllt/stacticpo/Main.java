package com.qllt.stacticpo;

import java.util.List;

import com.qllt.po.News;

public class Main {
	private List<News> tzggList;//通知公告
	private List<News> xwzxList;//新闻资讯
	private List<News> yxjlList;//院系交流
	private List<News> xyzpList;//校园招聘
	private List<News> zxzpList;//在线招聘
	private List<News> sxzpList;//实习招聘
	
	
	public List<News> getXwzxList() {
		return xwzxList;
	}

	public void setXwzxList(List<News> xwzxList) {
		this.xwzxList = xwzxList;
	}

	public List<News> getYxjlList() {
		return yxjlList;
	}

	public void setYxjlList(List<News> yxjlList) {
		this.yxjlList = yxjlList;
	}

	public List<News> getXyzpList() {
		return xyzpList;
	}

	public void setXyzpList(List<News> xyzpList) {
		this.xyzpList = xyzpList;
	}

	public List<News> getZxzpList() {
		return zxzpList;
	}

	public void setZxzpList(List<News> zxzpList) {
		this.zxzpList = zxzpList;
	}

	public List<News> getSxzpList() {
		return sxzpList;
	}

	public void setSxzpList(List<News> sxzpList) {
		this.sxzpList = sxzpList;
	}

	public List<News> getTzggList() {
		return tzggList;
	}

	public void setTzggList(List<News> tzggList) {
		this.tzggList = tzggList;
	}
}

package com.qllt.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qllt.po.Image;
import com.qllt.util.Page;

public class ImageDAOIml extends HibernateDaoSupport implements ImageDAO {
	//添加或修改图片
	public void save(Image image){  
		getHibernateTemplate().save(image);
	}
	//删除图片
	public void delete(Image image){  
		getHibernateTemplate().delete(image);
	}
	//查询图片
	public Image queryByID(int imageID){  
		List<Image> images=getHibernateTemplate().find("from Image where imageID=?",imageID);
		if(images.size()==0){
			return null;
		}else{
			return images.get(0);
		}
	}
	//更新图片
	public void updateImage(Image image){  
		getHibernateTemplate().update(image);
	}
	//查询所有图片
	public List<Image> queryAllImage(Page page,int imageType){
		Session session=getSession();
		Query query=session.createQuery("from Image where imageType=:imageType order by imageOrder,imageID");
		query.setParameter("imageType", imageType);
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	//查询图片数目
	public int queryImageCount(int imageType){
		List<Image> imageList=getHibernateTemplate().find("from Image where imageType=?",imageType);
		return imageList.size();
	}
}

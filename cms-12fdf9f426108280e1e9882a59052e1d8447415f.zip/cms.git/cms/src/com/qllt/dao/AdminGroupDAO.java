package com.qllt.dao;

import java.util.List;

import com.qllt.po.AdminGroup;

public interface AdminGroupDAO {

	public abstract void add(AdminGroup adminGroup);

	public abstract void update(AdminGroup adminGroup);

	public abstract void delete(AdminGroup adminGroup);

	public abstract List<AdminGroup> queryAll();
	public abstract AdminGroup queryByID(int gid);
}
package com.qllt.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qllt.po.Menu;
import com.qllt.po.News;

public class MenuDAOImpl extends HibernateDaoSupport implements MenuDAO{
	//添加
	public void save(Menu menu){
		getHibernateTemplate().save(menu);
	}
	//删除
	public void delete(Menu menu){
		getHibernateTemplate().delete(menu);
	}
	//查询
	public Menu queryByID(int menuID){
		List<Menu> menus=getHibernateTemplate().find("from Menu where menuID=?",menuID);
		if(menus.size()==0){
			return null;
		}else{
			return menus.get(0);                                      
		}
	}
	//更新
	public void update(Menu menu){
		getHibernateTemplate().update(menu);
	}
	//查询所有
	public List<Menu> queryAll(){
		List<Menu> menus=getHibernateTemplate().find("from Menu order by menuOrder,createTime desc");
		return menus;
	}
	//名称查询
	public Menu queryByName(String menuName){
		List<Menu> menus=getHibernateTemplate().find("from Menu where menuName=?",menuName);
		if(menus.size()==0){
			return null;
		}else{
			return menus.get(0);
		}
	}
}

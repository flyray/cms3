package com.qllt.dao;

import java.util.Date;
import java.util.List;

import com.qllt.po.News;
import com.qllt.util.Page;

public interface NewsDAO {

	public abstract void saveNews(News news);

	public abstract void deleteNews(News news);

	public abstract void updateNews(News news);

	/**
	 * 查询新闻总数
	 * @return
	 */
	public abstract int queryNewsCount();

	/**
	 * 根据NewID查询
	 * @return
	 */
	public abstract News queryByNewsID(int newsID);

	/**
	 * 查询每个分类下的新闻总数
	 * @return
	 */
	public abstract int queryNewsCountByItemID(int itemID);

	public abstract int queryNewsCountBySubItemID(int subItemID);

	/**
	 * 查询每个分类下所有新闻
	 * @return
	 */
	public abstract List<News> queryNewsByNewsItemID(int itemID, Page page);

	public abstract List<News> queryNewsByNewsSubItemID(int subItemID, Page page);

	/**
	 * 分页查询所有新闻
	 * @return
	 */
	public abstract List<News> queryNewsAll(Page page);

	/**
	 * 根据关键字查询
	 * @return
	 */
	public abstract List<News> queryByKeywods(String keywords, Page page);

	/**
	 * 获取关键字新闻的个数
	 */
	public abstract int queryCountByKeywords(String keywords);
	/**
	 * 高级检索，查询新闻数量
	 * @param keywords
	 * @param editorName
	 * @param content
	 * @param author
	 * @param createtime
	 * @param recrutTime
	 * @param starttime
	 * @param endtime
	 * @param recruitAddress
	 * @param source
	 * @return
	 */
	public abstract int queryCountAdvancedSearch(String keywords,String editorName,String content,String author,Date createtime,Date recrutTime,String starttime,String endtime,int recruitAddress,String source);
	/**
	 * 高级搜索，查询新闻
	 * @param page
	 * @param keywords
	 * @param editorName
	 * @param content
	 * @param author
	 * @param createtime
	 * @param recrutTime
	 * @param starttime
	 * @param endtime
	 * @param recruitAddress
	 * @param source
	 * @return
	 */
	public abstract List<News> queryAdvancedSearch(Page page,String keywords,String editorName,String content,String author,Date createtime,Date recrutTime,String starttime,String endtime,int recruitAddress,String source);
	
	public abstract News queryByDate(Date date);
	
	/**
	 * 查询校内招聘一周内的新闻数量
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	public abstract int queryXnzpNewsCount(Date beginDate,Date endDate);
	/**
	 * 查询校内招聘一周内的新闻
	 * @param page
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	public abstract List<News> queryXnzpNews(Page page,Date beginDate,Date endDate);
	/*
	 * 用于首页查询新闻
	 * (non-Javadoc)
	 * @see com.qllt.dao.NewsDAO#list(int, int, com.qllt.util.Page)
	 */
	public abstract List<News> list(int subItemID, int itemID, Page page);

	/*
	 * 置顶方法
	 * @see com.qllt.dao.NewsDAO#setTop(int, int)
	 */
	public abstract void setTop(int newsID, int settop);
	
	//统计用到的三个方法
	public abstract String checkNewsAndPosition(String start_time,String end_time,List<Integer> news_number_list,List<Integer> news_number_list_byauthor);
	
	public abstract String checkNewsAndPositionByAuthor(String author,String start_time,String end_time,List<Integer> news_number_list_byauthor,List<Integer> news_number_list);

	public abstract String divideByWeek(String divide_year,List<String> divide_week_list,List<Integer> divide_number_list,List<String> divide_position_list);

	/**
	 * 搜索
	 */
	public abstract List<News> searchNews(String tip,Page page);
	/**
	 * android 访问接口 获取最新newsnum条动态
	 * @param newsNum
	 * @return
	 */
	public abstract List findRecentNewsList(int newsNum);
	
	/**
	 * 查询每个分类下所有新闻list
	 * @return
	 */
	public abstract List queryNewsByNewsItemIDList(int itemID, Page page);

	public abstract List queryNewsByNewsSubItemIDList(int subItemID, Page page);

	/**
	 * 分页查询所有新闻list
	 * @return
	 */
	public abstract List queryNewsAllList(Page page);
	/**
	 * 关键词查询新闻列表
	 * @param keywords
	 * @return
	 */
	public abstract List<News> findNewsListByKeywords(String keywords);
	
	/**
	 * 分页查询新闻list，返回news新闻列表
	 */
	public abstract List<News> queryNewsListByNewsItemID(int itemID,Page page);
	public abstract List<News> queryNewsListByNewsSubItemID(int subItemID,Page page);
	public abstract List<News> queryNewsListAll(Page page);
	
	
	
}
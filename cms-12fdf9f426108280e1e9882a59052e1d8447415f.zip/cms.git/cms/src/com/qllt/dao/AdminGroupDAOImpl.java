package com.qllt.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qllt.po.Admin;
import com.qllt.po.AdminGroup;

public class AdminGroupDAOImpl extends HibernateDaoSupport implements AdminGroupDAO{
	
	public void add(AdminGroup adminGroup){
		getHibernateTemplate().save(adminGroup);
	}
	
	public void update(AdminGroup adminGroup){
		getHibernateTemplate().update(adminGroup);
	}
	public void delete(AdminGroup adminGroup){
		getHibernateTemplate().delete(adminGroup);
	}
	public List<AdminGroup> queryAll(){
		List<AdminGroup> list =this.getHibernateTemplate().find("from AdminGroup order by gid");
		return list;
	}
	public AdminGroup queryByID(int gid){
		List<AdminGroup> list=getHibernateTemplate().find("from AdminGroup where gid=?",gid);
		if(list.size()==0){
			return null;
		}else{
			return list.get(0);
		}
	}
}

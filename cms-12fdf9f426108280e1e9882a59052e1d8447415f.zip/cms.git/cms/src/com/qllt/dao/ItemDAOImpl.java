package com.qllt.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qllt.po.Item;

public class ItemDAOImpl extends HibernateDaoSupport implements ItemDAO {
	
	//添加栏目
	public void saveItem(Item item){
		getHibernateTemplate().save(item);
	}
	//删除栏目
	public void deleteItem(Item item){
		getHibernateTemplate().delete(item);
	}
	//更新栏目
	public void updateItem(Item item){
		getHibernateTemplate().update(item);
	}
	//根据itemID查询
	public Item queryByItemID(int itemID){
		List<Item> item=getHibernateTemplate().find("from Item where itemID=?",itemID);
		if(item.size()==0){
			return null;
		}else{
			return item.get(0);
		}
	}
	//根据itemName查询
	public Item queryItemByName(String itemName){
		List<Item> item=getHibernateTemplate().find("from Item where itemName=?",itemName);
		if(item.size()==0){
			return null;
		}else{
			return item.get(0);
		}
	}
	//查看所有栏目
	public List<Item> queryAllItem(){
		List<Item> item=getHibernateTemplate().find("from Item as i order by i.order,i.createTime");
		return item;
	}
	
}

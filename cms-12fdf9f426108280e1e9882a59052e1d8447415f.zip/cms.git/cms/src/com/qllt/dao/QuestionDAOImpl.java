package com.qllt.dao;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qllt.po.News;
import com.qllt.po.Question;
import com.qllt.util.Page;

public class QuestionDAOImpl extends HibernateDaoSupport implements QuestionDAO 
{
	
	public void saveQuestion(Question question)
	{
		getHibernateTemplate().save(question);
	}
	public void deleteQuestion(Question question)
	{
		getHibernateTemplate().delete(question);
	}
	public void updateQuestion(Question question)
	{
		getHibernateTemplate().update(question);
	}
	/**
	 * 查询提问总数
	 * @return
	 */
	public int queryQuestionCount(){
		String hql="select count(*) from Question";
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	/**
	 * 分页查询所有提问
	 * @return
	 */
	public List<Question> queryQuestionAll(Page page)
	{
		Session session=getSession();
		Query query=session.createQuery("from Question order by createTime desc");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	/**
	 * 根据questionID查询
	 * @return
	 */
	public Question queryByQuestionID(int questionID)
	{
		List<Question> list=getHibernateTemplate().find("from Question where questionID=?",questionID);
		if(list.size()==0)
		{
			return null;
		}
		else
		{
			return list.get(0);
		}
	}
	/**
	 * 查询每个分类下的提问总数(回复/未回复)
	 * @return
	 */
	public int queryShowQuestionCount()
	{
		String hql="select count(*) from Question where isshow=1";
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	public int queryNotShowQuestionCount()
	{
		String hql="select count(*) from Question where isshow=0";
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	/**
	 * 分页查询每个分类下所有提问(回复/未回复)
	 * @return
	 */
	public List<Question> queryShowQuestion(Page page)
	{
		Session sesssion=getSession();
		Query query=sesssion.createQuery("from Question where isshow=1 order by createtime desc");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	public List<Question> queryNotShowQuestion(Page page)
	{
		Session sesssion=getSession();
		Query query=sesssion.createQuery("from Question where isshow=0 order by createtime desc");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	//不分页查询所有未回复提问
	public List<Question> queryAllNotAnswer(){
		String queryString="from Question where isshow=0";
		List<Question> list =getHibernateTemplate().find(queryString);
		return list;
	}
	/**
	 * 查询每个分类下的提问总数(各部门)
	 * @return
	 */
	public int queryClassifyQuestionCount(String classify)
	{
		String hql="select count(*) from Question where classify='"+classify+"'";
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	/**
	 * 分页查询每个提问分类下所有提问(各部门)
	 * @return
	 */
	public List<Question> queryClassifyQuestion(Page page, String classify)
	{
		Session sesssion=getSession();
		
		Query query=sesssion.createQuery("from Question where  classify= '"+classify+"' order by createtime desc");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	/**
	 * 查询每个分类下的未回复提问总数(各部门)
	 * @return
	 */
	public int queryClassifyQuestionCountNot(String classify)
	{
		String hql="select count(*) from Question where isshow=0 and classify="+"'"+classify+"'";
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	/**
	 * 查询每个提问分类下所有未回复提问(各部门)
	 * @return
	 */
	public List<Question> queryClassifyQuestionNot(String classify)
	{
		String queryString="from Question where isshow=0 and classify='"+classify+"'";
		List<Question> list =getHibernateTemplate().find(queryString);
		return list;
	}
	/**
	 * 查询每个分类下的已回复提问总数(各部门)
	 * @return
	 */
	public int queryClassifyQuestionCountYes(String classify)
	{
		String hql="select count(*) from Question where isshow=1 and classify="+"'"+classify+"'";
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	/**
	 * 分页查询每个提问分类下所有已回复提问(各部门)
	 * @return
	 */
	public List<Question> queryClassifyQuestionYes(Page page, String classify)
	{
		Session sesssion=getSession();
		Query query=sesssion.createQuery("from Question where isshow=1 and classify="+"'"+classify+"' order by createtime desc");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	//查询需要显示的新闻的数目
	public int queryShowCount(){
		//查询已回复，并且同意显示的问答
		String hql="select count(*) from Question where isshow=1 and broadcast=1";
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	//分页查询需要显示的新闻
	public List<Question> queryShowDetail(Page page){
		Session sesssion=getSession();
		Query query;
		String hql = "from Question where isshow=1 and broadcast=1 order by createTime desc";
	    query=sesssion.createQuery(hql);
	    query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	//查询所有需要显示的新闻
	public List<Question> queryAllShow(){
		String queryString="from Question where isshow=1 and broadcast=1";
		List<Question> list =getHibernateTemplate().find(queryString);
		return list;
	}
	
}

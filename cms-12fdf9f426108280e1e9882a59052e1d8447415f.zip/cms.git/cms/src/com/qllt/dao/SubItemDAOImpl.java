package com.qllt.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qllt.po.SubItem;

public class SubItemDAOImpl extends HibernateDaoSupport implements SubItemDAO{
	//删除
	public void deleteSubItem(SubItem subItem) {		
		getHibernateTemplate().delete(subItem);
	}
	//添加
	public void saveSubItem(SubItem subItem) {		
		getHibernateTemplate().save(subItem);
	}
	//修改
	public void updateSubItem(SubItem subItem){
		getHibernateTemplate().update(subItem);
	}
	//根据id查询
	public SubItem querySubItemByID(int subItemID) {
		List<SubItem> items = getHibernateTemplate().find("from SubItem where subItemID =?",subItemID);
		if(items.size() == 0) {		
			return null;
		}else {
			return items.get(0);
		}
	}
	//查询所有
	public List<SubItem> queryAllSubItem(int itemID) {	
		List<SubItem> subItems = getHibernateTemplate().find("from SubItem as s where item.itemID=? order by s.order,s.createTime desc",itemID);
		return subItems;
	}
	
	//根据名称查询
	public SubItem querySubItemByName(String subItemName) {		
		List<SubItem> items = getHibernateTemplate().find("from SubItem where subItemName = ?",subItemName);
		if(items.size() == 0) {	
			return null;
		}else {
			return items.get(0);
		}
	}
	//查询所有
		public List<SubItem> queryAllSubItem() {	
			List<SubItem> subItems = getHibernateTemplate().find("from SubItem as s order by s.order");
			return subItems;
		}

}

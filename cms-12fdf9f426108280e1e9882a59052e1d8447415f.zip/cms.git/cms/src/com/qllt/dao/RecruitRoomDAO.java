package com.qllt.dao;

import java.util.List;

import com.qllt.po.RecruitRoom;

public interface RecruitRoomDAO {

	/**
	 * 添加
	 * @param recruitSchool
	 */
	public abstract void add(RecruitRoom recruitRoom);

	/**
	 * 删除
	 * @param 
	 */
	public abstract void delete(RecruitRoom recruitRoom);

	/**
	 * 查找
	 */
	public abstract void findAll(RecruitRoom recruitRoom);

	/**
	 * 更新
	 * @param 
	 */
	public abstract void update(RecruitRoom recruitRoom);

	/**
	 * ajax查询各校区所有教室信息
	 */
	public abstract List<RecruitRoom> findAllRoom(int recruitSchoolNum);
	
	/**
	 * 按照recruitRoomID查询
	 */
	public abstract RecruitRoom findRecruitRoomByID(int recruitRoomID);
	
}
package com.qllt.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qllt.po.Admin;

public class AdminDAOImpl extends HibernateDaoSupport implements AdminDAO {
	
	//添加管理员
	public void save(Admin admin){
		this.getHibernateTemplate().save(admin);
	}
	
	//修改管理员
	public void updateAdmin(Admin admin){
		getHibernateTemplate().update(admin);
	}
	
	//删除管理员
	public void deleteAdmin(Admin admin){
		getHibernateTemplate().delete(admin);
	}
	//根据管理员权限查询
	public List<Admin>  queryAll(){
		List<Admin> list =this.getHibernateTemplate().find("from Admin order by adminID,agid desc");
		return list;
	}
	//通过adminID查询管理员
	public Admin queryByAdminID(int adminID){
		List<Admin> list=getHibernateTemplate().find("from Admin where adminID=?",adminID);
		if(list.size()==0){
			return null;
		}else{
			return list.get(0);
		}
	}
	public Admin queryByAdminName(String adminName){
		List<Admin> list=getHibernateTemplate().find("from Admin where adminName=?",adminName);
		if(list.size()==0){
			return null;
		}else{
			return list.get(0);
		}
	}
}

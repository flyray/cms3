package com.qllt.dao;

import java.util.List;

import com.qllt.po.SubMenu;

public interface SubMenuDAO {

	//添加
	public abstract void save(SubMenu subMenu);

	//删除
	public abstract void delete(SubMenu subMenu);

	//查询
	public abstract SubMenu queryByID(int subMenuID);

	//更新
	public abstract void update(SubMenu subMenu);

	//查询所有
	public abstract List<SubMenu> queryAll();

	//名称查询
	public abstract SubMenu queryByName(String subMenuName);

}
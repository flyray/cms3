package com.qllt.dao;

import java.util.List;

import com.qllt.po.Item;

public interface ItemDAO {

	//添加栏目
	public abstract void saveItem(Item item);

	//删除栏目
	public abstract void deleteItem(Item item);

	//更新栏目
	public abstract void updateItem(Item item);

	//根据itemID查询
	public abstract Item queryByItemID(int itemID);

	//根据itemName查询
	public abstract Item queryItemByName(String itemName);

	//查看所有栏目
	public abstract List<Item> queryAllItem();

}
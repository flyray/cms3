package com.qllt.dao;

import java.util.List;
import com.qllt.po.Question;
import com.qllt.util.Page;

public interface QuestionDAO {

	public abstract void saveQuestion(Question question);

	public abstract void deleteQuestion(Question question);
	
	public abstract void updateQuestion(Question question);
	
	/**
	 * 查询提问总数
	 * @return
	 */
	public abstract int queryQuestionCount();

	/**
	 * 分页查询所有提问
	 * @return
	 */
	public abstract List<Question> queryQuestionAll(Page page);
	
	/**
	 * 根据questionID查询
	 * @return
	 */
	public abstract Question queryByQuestionID(int questionID);

	/**
	 * 查询每个分类下的提问总数(回复/未回复)
	 * @return
	 */
	public abstract int queryShowQuestionCount();
	public abstract int queryNotShowQuestionCount();
	/**
	 * 分页查询每个分类下所有提问(回复/未回复)
	 * @return
	 */
	public abstract List<Question> queryShowQuestion(Page page);
	public abstract List<Question> queryNotShowQuestion(Page page);
	/**
	 * 查询每个分类下的提问总数(各部门)
	 * @return
	 */
	public abstract int queryClassifyQuestionCount(String classify);
	/**
	 * 分页查询每个分类下所有提问(各部门)
	 * @return
	 */
	public abstract List<Question> queryClassifyQuestion(Page page, String classify);
	/**
	 * 查询每个分类下的未回复提问总数(各部门)
	 * @return
	 */
	public abstract int queryClassifyQuestionCountNot(String classify);
	/**
	 * 分页查询每个提问分类下所有未回复提问(各部门)
	 * @return
	 */
	public abstract List<Question> queryClassifyQuestionNot(String classify);
	/**
	 * 查询每个分类下的已回复提问总数(各部门)
	 * @return
	 */
	public abstract int queryClassifyQuestionCountYes(String classify);
	/**
	 * 分页查询每个提问分类下所有已回复提问(各部门)
	 * @return
	 */
	public abstract List<Question> queryClassifyQuestionYes(Page page, String classify);
	/**
	 * 查询需要显示的问答数目
	 * @return
	 */
	public abstract int queryShowCount();
	/**
	 * 分页查询需要显示的问答
	 * @param page
	 * @return
	 */
	public abstract List<Question> queryShowDetail(Page page);
	
	/**
	 * 查询所有需要显示的问答
	 * @return
	 */
	public abstract List<Question> queryAllShow();
	//不分页查询所有未回复提问
	public abstract List<Question> queryAllNotAnswer();
}
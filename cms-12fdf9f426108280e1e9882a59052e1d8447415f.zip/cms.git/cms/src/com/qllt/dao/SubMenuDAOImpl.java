package com.qllt.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qllt.po.Menu;
import com.qllt.po.SubMenu;

public class SubMenuDAOImpl extends HibernateDaoSupport implements SubMenuDAO{
	//添加
	public void save(SubMenu subMenu){
		getHibernateTemplate().save(subMenu);
	}
	//删除
	public void delete(SubMenu subMenu){
		getHibernateTemplate().delete(subMenu);
	}
	//查询
	public SubMenu queryByID(int subMenuID){
		List<SubMenu> subMenus=getHibernateTemplate().find("from SubMenu where subMenuID=?",subMenuID);
		if(subMenus.size()==0){
			return null;
		}else{
			return subMenus.get(0);                                      
		}
	}
	//更新
	public void update(SubMenu subMenu){
		getHibernateTemplate().update(subMenu);
	}
	//查询所有
	public List<SubMenu> queryAll(){
		List<SubMenu> SubMenus=getHibernateTemplate().find("from SubMenu order by subMenuOrder,createTime");
		return SubMenus;
	}
	//名称查询
	public SubMenu queryByName(String subMenuName){
		List<SubMenu> SubMenus=getHibernateTemplate().find("from SubMenu where subMenuName=?",subMenuName);
		if(SubMenus.size()==0){
			return null;
		}else{
			return SubMenus.get(0);
		}
	}
}

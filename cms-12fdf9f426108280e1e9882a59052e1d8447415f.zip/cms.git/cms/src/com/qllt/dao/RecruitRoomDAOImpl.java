package com.qllt.dao;

import java.util.List;

import com.qllt.po.Item;
import com.qllt.po.RecruitRoom;
import com.qllt.po.RecruitSchool;
import com.qllt.po.SubItem;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class RecruitRoomDAOImpl extends HibernateDaoSupport implements RecruitRoomDAO{
	/**
	 * 添加
	 * @param recruitSchool
	 */
	public void add(RecruitRoom recruitRoom){
		getHibernateTemplate().save(recruitRoom);
	}
	/**
	 * 删除
	 * @param 
	 */
	public void delete(RecruitRoom recruitRoom){
		getHibernateTemplate().delete(recruitRoom);
	}
	/**
	 * 查找
	 * 
	 */
	public void findAll(RecruitRoom recruitRoom){
		List<RecruitRoom> list=getHibernateTemplate().find("from RecruitRoom where recruitRoomID>0 order by recruitRoomState desc,recruitroomID asc");//0是一个特殊情况，不使用，不删除
		recruitRoom.setRecruitRoomList(list);
	}
	/**
	 * 更新
	 * @param 
	 */
	public void update(RecruitRoom recruitRoom){
		getHibernateTemplate().update(recruitRoom);
	}
	/**
	 * ajax查询各校区的所有教室信息
	 */
	public List<RecruitRoom> findAllRoom(int recruitSchoolNum){
		List<RecruitRoom> recruitRoomList = getHibernateTemplate().find("from RecruitRoom where recruitRoomBelong=? and recruitRoomState=1",recruitSchoolNum);
		return recruitRoomList;
	}
	/**
	 * 按照recruitRoomID 查询，返回recruitRoom
	 */
	public RecruitRoom findRecruitRoomByID(int recruitRoomID){
		List<RecruitRoom> recruitRoomList=getHibernateTemplate().find("from RecruitRoom where recruitRoomID=?",recruitRoomID);
		if(recruitRoomList.size()==0){
			return null;
		}else{
			return recruitRoomList.get(0);
		}
	}
	
	
	
}



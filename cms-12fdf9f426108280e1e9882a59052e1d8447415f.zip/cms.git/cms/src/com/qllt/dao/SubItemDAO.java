package com.qllt.dao;

import java.util.List;

import com.qllt.po.SubItem;

public interface SubItemDAO {

	public abstract void deleteSubItem(SubItem subItem);

	public abstract List<SubItem> queryAllSubItem(int itemID);

	public abstract SubItem querySubItemByID(int subItemID);

	public abstract SubItem querySubItemByName(String subItemName);

	public abstract void saveSubItem(SubItem subItem);
	public abstract void updateSubItem(SubItem subItem);
	public abstract List<SubItem> queryAllSubItem();
}
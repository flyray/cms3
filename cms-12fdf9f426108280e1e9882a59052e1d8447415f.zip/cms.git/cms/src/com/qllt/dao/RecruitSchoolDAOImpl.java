package com.qllt.dao;

import java.util.List;

import com.qllt.po.Item;
import com.qllt.po.RecruitRoom;
import com.qllt.po.RecruitSchool;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class RecruitSchoolDAOImpl extends HibernateDaoSupport implements RecruitSchoolDAO{
	/**
	 * 添加
	 * @param recruitSchool
	 */
	public void add(RecruitSchool recruitSchool){
		getHibernateTemplate().save(recruitSchool);
	}
	
	/**
	 * 删除
	 * @param 
	 */
	public void delete(RecruitSchool recruitSchool){
		getHibernateTemplate().delete(recruitSchool);
	}
	/**
	 * 查找
	 * 
	 * @param 
	 * @return
	 */
	public void findAll(RecruitSchool recruitSchool){
		List<RecruitSchool> list=getHibernateTemplate().find("from RecruitSchool");
		recruitSchool.setRecruitSchoolList(list);
		
	}
	/**
	 * 更新
	 * @param 
	 */
	public void update(RecruitSchool recruitSchool){
		getHibernateTemplate().update(recruitSchool);
	}
	/**
	 * ajax 查询所有校区
	 * @return
	 */
	public List<RecruitSchool> findAllSchool(){
		List<RecruitSchool> recruitSchool_list=getHibernateTemplate().find("from RecruitSchool");
		return recruitSchool_list;
	}
	/**
	 * 根据招聘校区编号查询查询招聘校区
	 */
	public RecruitSchool findRecruitSchoolByNum(int recruitSchoolNum){
		List<RecruitSchool> list=getHibernateTemplate().find("from RecruitSchool where recruitSchoolNum=?",recruitSchoolNum);
		return list.get(0);
	}
	
}

package com.qllt.dao;

import java.util.List;

import com.qllt.po.RecruitSchool;

public interface RecruitSchoolDAO {

	/**
	 * 添加
	 * @param recruitSchool
	 */
	public abstract void add(RecruitSchool recruitSchool);

	/**
	 * 删除
	 * @param 
	 */
	public abstract void delete(RecruitSchool recruitSchool);

	/**
	 * 查找
	 * 
	 * @param 
	 * @return
	 */
	
	public abstract void findAll(RecruitSchool recruitSchool);

	/**
	 * 更新
	 * @param 
	 */
	public abstract void update(RecruitSchool recruitSchool);
	/**
	 * ajax查询所有校区
	 * @return
	 */
	public abstract List<RecruitSchool> findAllSchool();
	/**
	 * 根据招聘校区编号查询招聘校区
	 * @param recruitSchoolNum
	 * @return
	 */
	public abstract RecruitSchool findRecruitSchoolByNum(int recruitSchoolNum);
	
}
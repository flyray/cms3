package com.qllt.dao;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.junit.Test;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qllt.po.News;
import com.qllt.util.Page;

public class NewsDAOImpl extends HibernateDaoSupport implements NewsDAO{
	public void saveNews(News news){
		getHibernateTemplate().save(news);
	}
	public void deleteNews(News news){
		getHibernateTemplate().delete(news);
	}
	public void updateNews(News news){
		getHibernateTemplate().update(news);
	}
	
	
	/**
	 * 某段时间内发稿总数及所需岗位总数目
	 */
	public String checkNewsAndPosition(String start_time,String end_time,List<Integer> news_number_list,List<Integer> news_number_list_byauthor){
		String queryString="from News where (createtime<'"+end_time+"')and(createtime>'"+start_time+"')";
		List<News> list =getHibernateTemplate().find(queryString);
		int positionNum=0;
		for(int i=0;i<list.size();i++){
			positionNum=positionNum+list.get(i).getPositionNum();	
		}		
		news_number_list_byauthor.add(1);
		news_number_list.add(list.size());
		news_number_list.add(positionNum);	

		return "checkNewsAndPosition_s";
	}
	/**
	 * 某段时间内某作者发稿总数及所需岗位总数目
	 * @param author
	 * @param start_time
	 * @param end_time
	 * @param news_number_list
	 * @return
	 */
	public String checkNewsAndPositionByAuthor(String author,String start_time,String end_time,List<Integer> news_number_list_byauthor,List<Integer> news_number_list){
		String queryString="from News where (createtime<'"+end_time+"')and(createtime>'"+start_time+"')and(author='"+author+"')";
		List<News> list =getHibernateTemplate().find(queryString);
		int positionNum=0;
		for(int i=0;i<list.size();i++){
			positionNum=positionNum+list.get(i).getPositionNum();	
		}		
		news_number_list.add(1);
		news_number_list_byauthor.add(list.size());
		news_number_list_byauthor.add(positionNum);	
		
		return "checkNewsAndPositionByAuthor_s";
	}
	
	public String divideByWeek(String divide_year,List<String> divide_week_list,List<Integer> divide_number_list,List<String> divide_position_list){
		Session session=super.getSession();
		String hql1="select date_format(createtime,'第%v周') as week,count(*)as news_number,sum(positionNum)as positionNum from News where date_format(createtime,'%Y')="+divide_year+" group by date_format(createtime,'第%v周')";			
		Query query1=session.createQuery(hql1);	
		List list=query1.list();	
		Iterator iter=list.iterator();
		while(iter.hasNext()){
			Object[] obj=(Object[])iter.next();
			divide_week_list.add(obj[0].toString());
			divide_number_list.add(Integer.parseInt(obj[1].toString()));
			
		}	
		//DecimalFormat df=new DecimalFormat(".##");//定义截取double的小数点后两位
		int news_sum=0;
		for(int i=0;i<divide_number_list.size();i++){
			news_sum=news_sum+divide_number_list.get(i);
		}
		for(int i=0;i<divide_number_list.size();i++){
			int temp=((100*divide_number_list.get(i))/news_sum);
			divide_position_list.add(temp+"%");
		}
		return "divideByWeek_s";				
	}
	
	
	
	/**
	 * 查询新闻总数
	 * @return
	 */
	public int queryNewsCount(){
		String hql="select count(*) from News";
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	
	/**
	 * 根据NewID查询
	 * @return
	 */
	public News queryByNewsID(int newsID){
		List<News> newslist=getHibernateTemplate().find("from News where newsID=?",newsID);
		if(newslist.size()==0){
			return null;
		}else{
			return newslist.get(0);
		}
	}
	/**
	 * 查询每个分类下的新闻总数
	 * @return
	 */
	public int queryNewsCountByItemID(int itemID){
		String hql="select count(*) from News as n,SubItem as si,Item as i where n.subItem.subItemID=si.subItemID and si.item.itemID=i.itemID and i.itemID="+itemID;
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	public int queryNewsCountBySubItemID(int subItemID){
		String hql="select count(*) from News as n where subItemID="+subItemID;
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	/**
	 * 查询校内招聘一周内的新闻数量
	 */
	public int queryXnzpNewsCount(Date beginDate,Date endDate){
		String bd = new SimpleDateFormat("yyyy-MM-dd").format(beginDate);
		String ed = new SimpleDateFormat("yyyy-MM-dd").format(endDate);
		//String hql="select count(*) from News where recrutTime>"+beginDate+" and recrutTime<"+endDate;
		String hql="select count(*) from News where subItemID=17 and recrutTime>'"+bd+"' and recrutTime<'"+ed+"'";
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	/**
	 * 分页查询校内招聘一周内的新闻
	 */
	public List<News> queryXnzpNews(Page page,Date beginDate,Date endDate){
		String bd = new SimpleDateFormat("yyyy-MM-dd").format(beginDate);
		String ed = new SimpleDateFormat("yyyy-MM-dd").format(endDate);
		Session sesssion=getSession();
		Query query;
		String hql = "from News where subItemID=17 and recrutTime>'"+bd+"' and recrutTime<'"+ed+"' order by settop desc,settoptime desc,recrutTime asc,createtime desc";
	    query=sesssion.createQuery(hql);
	    query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	/**
	 * 查询每个分类下所有新闻
	 * @return
	 */
	public List<News> queryNewsByNewsItemID(int itemID,Page page){
		Session sesssion=getSession();
		Query query;
		if(itemID==7){
			query=sesssion.createQuery("select n from News as n,SubItem as si,Item as i where n.subItem.subItemID=si.subItemID and si.item.itemID=i.itemID and i.itemID=:itemID order by n.settop desc,n.settoptime desc,n.recrutTime desc,n.createtime desc");
		}else{
			query=sesssion.createQuery("select n from News as n,SubItem as si,Item as i where n.subItem.subItemID=si.subItemID and si.item.itemID=i.itemID and i.itemID=:itemID order by n.settop desc,n.settoptime desc,n.createtime desc");
		}
		query.setInteger("itemID", itemID);
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	public List<News> queryNewsByNewsSubItemID(int subItemID,Page page){
		Session sesssion=getSession();
		Query query;
		if(subItemID==17){
			query=sesssion.createQuery("from News as n where subItemID=:subItemID order by settop desc,settoptime desc,n.recrutTime desc,createtime desc");
		}else{
			query=sesssion.createQuery("from News as n where subItemID=:subItemID order by settop desc,settoptime desc,createtime desc");
		}
		query.setInteger("subItemID", subItemID);
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	/**
	 * 分页查询所有新闻
	 * @return
	 */
	public List<News> queryNewsAll(Page page){
		Session session=getSession();
		Query query=session.createQuery("from News order by settop desc,settoptime desc,createtime desc");
//		Query query=session.createSQLQuery("SELECT * FROM(SELECT * FROM news WHERE settop=1 ORDER BY settoptime DESC,createtime DESC) AS t1 UNION SELECT * FROM news WHERE settop=0 ORDER BY createtime desc");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	/**
	 * 根据关键字查询
	 * @return
	 */
	public List<News> queryByKeywods(String keywords,Page page){
		Session sesssion=getSession();
//		Query query=sesssion.createQuery("from News as n where content like :keywords or (title like :keywords) order by n.createtime desc");
		Query query=sesssion.createQuery("select new News(n.newsID,n.title,n.settop,n.createtime,n.recrutTime,n.subItem)from News as n where title like :keywords order by n.createtime desc");
		query.setString("keywords", "%"+keywords+"%");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	/**
	 * 获取关键字新闻的个数
	 */
	public int queryCountByKeywords(String keywords) {
//		List<News> list=getHibernateTemplate().find("from News as n where content like '%"+keywords+"%' or (title like '%"+keywords+"%') order by n.createtime desc");
		Session sesssion=getSession();
		Query query=sesssion.createQuery("select count(*) as count from News as n where title like :keywords");
		query.setString("keywords", "%"+keywords+"%");
		List list=query.list();	
//		System.out.println("关键字新闻个数---------"+list.get(0).toString());
		return Integer.parseInt(list.get(0).toString());
	}
	/**
	 * 高级查询新闻数量
	 */
	public int queryCountAdvancedSearch(String keywords,String editorName,String content,String author,Date createtime,Date recrutTime,String starttime,String endtime,int recruitAddress,String source){
		String sqlString="News as n where";
		if(!keywords.equals("")){
				sqlString=sqlString+" n.title like '%"+keywords+"%'";
				if(!source.equals("")){
					sqlString=sqlString+" and source='"+source+"'";
				}
				if(!editorName.equals("")){
					sqlString=sqlString+" and author='"+editorName+"'";
				}
				if(!starttime.equals("")){
					sqlString=sqlString+" and createtime>'"+starttime+"'";
				}
				if(!endtime.equals("")){
					sqlString=sqlString+" and createtime<'"+endtime+"'";
				}
		}
		else if(!source.equals("")){
			sqlString=sqlString+" source='"+source+"'";
			if(!keywords.equals("")){
				sqlString=sqlString+" and n.title like '%"+keywords+"%'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
			if(!starttime.equals("")){
				sqlString=sqlString+" and createtime>'"+starttime+"'";
			}
			if(!endtime.equals("")){
				sqlString=sqlString+" and createtime<'"+endtime+"'";
			}
		}
		else if(!editorName.equals("")){
			sqlString=sqlString+" author='"+editorName+"'";
			if(!keywords.equals("")){
				sqlString=sqlString+" and n.title like '%"+keywords+"%'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
			if(!starttime.equals("")){
				sqlString=sqlString+" and createtime>'"+starttime+"'";
			}
			if(!endtime.equals("")){
				sqlString=sqlString+" and createtime<'"+endtime+"'";
			}
		}else if(!starttime.equals("")){
			sqlString=sqlString+" createtime>'"+starttime+"'";
			if(!keywords.equals("")){
				sqlString=sqlString+" and n.title like '%"+keywords+"%'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
			if(!endtime.equals("")){
				sqlString=sqlString+" and createtime<'"+endtime+"'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
		}else if(!endtime.equals("")){
			sqlString=sqlString+" createtime<'"+endtime+"'";
			if(!keywords.equals("")){
				sqlString=sqlString+" and n.title like '%"+keywords+"%'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
			if(!starttime.equals("")){
				sqlString=sqlString+" and createtime>'"+starttime+"'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
		}
		sqlString="from "+sqlString;
		
		
		List<News> list=getHibernateTemplate().find(sqlString);
		return list.size();
	}
	/**
	 * 高级查询新闻
	 */
	public List<News> queryAdvancedSearch(Page page,String keywords,String editorName,String content,String author,Date createtime,Date recrutTime,String starttime,String endtime,int recruitAddress,String source){
		Session sesssion=getSession();
		String sqlString="News as n where";
		if(!keywords.equals("")){
				sqlString=sqlString+" n.title like '%"+keywords+"%'";
				if(!source.equals("")){
					sqlString=sqlString+" and source='"+source+"'";
				}
				if(!editorName.equals("")){
					sqlString=sqlString+" and author='"+editorName+"'";
				}
				if(!starttime.equals("")){
					sqlString=sqlString+" and createtime>'"+starttime+"'";
				}
				if(!endtime.equals("")){
					sqlString=sqlString+" and createtime<'"+endtime+"'";
				}
		}
		else if(!source.equals("")){
			sqlString=sqlString+" source='"+source+"'";
			if(!keywords.equals("")){
				sqlString=sqlString+" and n.title like '%"+keywords+"%'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
			if(!starttime.equals("")){
				sqlString=sqlString+" and createtime>'"+starttime+"'";
			}
			if(!endtime.equals("")){
				sqlString=sqlString+" and createtime<'"+endtime+"'";
			}
		}
		else if(!editorName.equals("")){
			sqlString=sqlString+" author='"+editorName+"'";
			if(!keywords.equals("")){
				sqlString=sqlString+" and n.title like '%"+keywords+"%'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
			if(!starttime.equals("")){
				sqlString=sqlString+" and createtime>'"+starttime+"'";
			}
			if(!endtime.equals("")){
				sqlString=sqlString+" and createtime<'"+endtime+"'";
			}
		}else if(!starttime.equals("")){
			sqlString=sqlString+" createtime>'"+starttime+"'";
			if(!keywords.equals("")){
				sqlString=sqlString+" and n.title like '%"+keywords+"%'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
			if(!endtime.equals("")){
				sqlString=sqlString+" and createtime<'"+endtime+"'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
		}else if(!endtime.equals("")){
			sqlString=sqlString+" createtime<'"+endtime+"'";
			if(!keywords.equals("")){
				sqlString=sqlString+" and n.title like '%"+keywords+"%'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
			if(!starttime.equals("")){
				sqlString=sqlString+" and createtime>'"+starttime+"'";
			}
			if(!editorName.equals("")){
				sqlString=sqlString+" and author='"+editorName+"'";
			}
		}
		sqlString="from "+sqlString+" order by n.createtime desc";
		
		Query query=sesssion.createQuery(sqlString);
		//query.setString("keywords", "%"+keywords+"%");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	
	public News queryByDate(Date date){
		List<News> newslist=getHibernateTemplate().find("from News where createtime=?",date);
		if(newslist.size()==0){
			return null;
		}else{
			return newslist.get(0);
		}
	}
	/*
	 * 用于首页查询新闻
	 * (non-Javadoc)
	 * @see com.qllt.dao.NewsDAO#list(int, int, com.qllt.util.Page)
	 */
	public List<News> list(int subItemID,int itemID,Page page){
		Session sesssion=getSession();
		Query query=sesssion.createQuery("from News as n,SubItem as si where subItemID=:subItemID and itemID=:itemID order by n.createtime desc");
		query.setInteger("subItemID", subItemID);
		query.setInteger("itemID", itemID);
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	/*
	 * 置顶方法
	 * @see com.qllt.dao.NewsDAO#setTop(int, int)
	 */
	public void setTop(int newsID,int settop){
		Date settoptime=new Date();
		if(settop==0){//对于取消置顶的新闻来说，把settop置为0，那么SELECT * FROM news ORDER BY settop DESC,settoptime DESC,createtime desc，就可以完成想要的排序了
			Calendar calendar = Calendar.getInstance();
			calendar.set(Calendar.YEAR, 0);
			settoptime=new Date(calendar.get(Calendar.YEAR));
		}
		Session session=getSession();
		//注释这种方法性能不好，会更新所有属性（除非在mapping文件加上<class name=”com.sccin.entity.Student” table=”student” dynamic-update=”true”>，）
//		News news=new News();
//		session.load(news,77);
//		System.out.println(news.getContent());
//		news.setSettop(settop);
//		news.setSettoptime(new Date());
//		session.update(news);
		Query query=session.createQuery("update News as n set n.settop=:settop,n.settoptime=:settoptime  where n.newsID=:newsID");
		query.setInteger("settop", settop);
		query.setInteger("newsID", newsID);
		query.setTimestamp("settoptime", settoptime);//如果使用setDate自动截取时分秒。
		query.executeUpdate();
	}
	public List<News> searchNews(String tip,Page page){
		Session sesssion=getSession();
		Query query=sesssion.createQuery("from News as n where title like :title order by settop desc,settoptime desc,createtime desc");
		query.setString("title", "%"+tip+"%");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	/**
	 * 获得最新动态新闻列表 newsNum条
	 */
	public List<News> findRecentNewsList(int newsNum){
		Session session=getSession();
		String hql="select new News(n.newsID,n.title,n.settop,n.createtime,n.content) from News as n order by n.newsID desc";
		Query query=session.createQuery(hql);
		System.out.println(newsNum+"----------newsNum");
		query.setMaxResults(newsNum);
		List newslist=query.list();
		return newslist;
	}
	
	/**
	 * 查询每个分类下所有新闻list，这个返回的是一个list，是android访问接口访问的，由于之前的写法不好，故此方法保留。
	 * @return
	 */
	public List queryNewsByNewsItemIDList(int itemID,Page page){
		Session sesssion=getSession();
		Query query;
		if(itemID==7){
			query=sesssion.createQuery("select n.newsID,n.title,n.createtime from News as n,SubItem as si,Item as i where n.subItem.subItemID=si.subItemID and si.item.itemID=i.itemID and i.itemID=:itemID order by n.settop desc,n.settoptime desc,n.recrutTime desc,n.createtime desc");
		}else{
			query=sesssion.createQuery("select n.newsID,n.title,n.createtime from News as n,SubItem as si,Item as i where n.subItem.subItemID=si.subItemID and si.item.itemID=i.itemID and i.itemID=:itemID order by n.settop desc,n.settoptime desc,n.createtime desc");
		}
		query.setInteger("itemID", itemID);
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		List newslist=query.list();
		System.out.println("newslist的大小："+newslist.size());
		for(int i=0;i<newslist.size();i++){
			Object []obj=(Object[]) newslist.get(i);
		}
		return newslist;
	}
	public List queryNewsByNewsSubItemIDList(int subItemID,Page page){
		Session sesssion=getSession();
		Query query;
		if(subItemID==17){
			query=sesssion.createQuery("select n.newsID,n.title,n.createtime from News as n where subItemID=:subItemID order by settop desc,settoptime desc,n.recrutTime desc,createtime desc");
		}else{
			query=sesssion.createQuery("select n.newsID,n.title,n.createtime from News as n where subItemID=:subItemID order by settop desc,settoptime desc,createtime desc");
		}
		query.setInteger("subItemID", subItemID);
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		List newslist=query.list();
		System.out.println("newslist的大小："+newslist.size());
		for(int i=0;i<newslist.size();i++){
			Object []obj=(Object[]) newslist.get(i);
			System.out.print(obj[0]+"  ");
			System.out.print(obj[1]+"  ");
			System.out.println(obj[2]);
		}
		return newslist;
	}
	/**
	 * 分页查询所有新闻list
	 * @return
	 */
	public List queryNewsAllList(Page page){
		Session session=getSession();
		String hql="select newsID,title,createtime from News order by settop desc,settoptime desc,createtime desc";
		Query query=session.createQuery(hql);
//		Query query=session.createSQLQuery("SELECT * FROM(SELECT * FROM news WHERE settop=1 ORDER BY settoptime DESC,createtime DESC) AS t1 UNION SELECT * FROM news WHERE settop=0 ORDER BY createtime desc");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		List newslist=query.list();
		return newslist;
	}
	/**
	 * android 访问接口，根据关键字查询得到新闻列表
	 */
	public List<News> findNewsListByKeywords(String keywords){
		Session sesssion=getSession();
		Query query=sesssion.createQuery("select new News(newsID,title,settop,createtime) from News where title like :title order by settop desc,settoptime desc,createtime desc");
		query.setString("title", "%"+keywords+"%");
		query.setFirstResult(0);
		query.setMaxResults(10);
		return query.list();
	}
	
	/**
	 * 查询每个分类下所有新闻，返回News类型的新闻列表
	 * @return
	 */
	public List<News> queryNewsListByNewsItemID(int itemID,Page page){
		Session sesssion=getSession();
		Query query;
		if(itemID==7){
			query=sesssion.createQuery("select new News(n.newsID,n.title,n.settop,n.createtime,n.recrutTime,n.recruitAddress) from News as n,SubItem as si,Item as i where n.subItem.subItemID=si.subItemID and si.item.itemID=i.itemID and i.itemID=:itemID order by n.settop desc,n.settoptime desc,n.recrutTime desc,n.createtime desc");
		}else{
			query=sesssion.createQuery("select new News(n.newsID,n.title,n.settop,n.createtime) from News as n,SubItem as si,Item as i where n.subItem.subItemID=si.subItemID and si.item.itemID=i.itemID and i.itemID=:itemID order by n.settop desc,n.settoptime desc,n.createtime desc");
		}
		query.setInteger("itemID", itemID);
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	public List<News> queryNewsListByNewsSubItemID(int subItemID,Page page){
		Session sesssion=getSession();
		Query query;
		if(subItemID==17){
			query=sesssion.createQuery("select new News(n.newsID,n.title,n.settop,n.createtime,n.recrutTime,n.recruitAddress) from News as n where subItemID=:subItemID order by settop desc,settoptime desc,n.recrutTime desc,createtime desc");
		}else{
			query=sesssion.createQuery("select new News(n.newsID,n.title,n.settop,n.createtime) from News as n where subItemID=:subItemID order by settop desc,settoptime desc,createtime desc");
		}
		query.setInteger("subItemID", subItemID);
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	/**
	 * 分页查询所有新闻，返回News类型的新闻列表
	 * @return
	 */
	public List<News> queryNewsListAll(Page page){
		Session session=getSession();
		Query query=session.createQuery("select new News(n.newsID,n.title,n.settop,n.createtime) from News order by settop desc,settoptime desc,createtime desc");
//		Query query=session.createSQLQuery("SELECT * FROM(SELECT * FROM news WHERE settop=1 ORDER BY settoptime DESC,createtime DESC) AS t1 UNION SELECT * FROM news WHERE settop=0 ORDER BY createtime desc");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	
}

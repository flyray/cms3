package com.qllt.dao;

import java.util.List;

import com.qllt.po.Log;
import com.qllt.util.Page;
import com.qllt.util.Result;

public interface LogDAO {

	//查询日志总数
	public int queryLogCount();
	//查询对应管理员日志总数
	public int queryLogCountbyAdminName(String adminName);
	
	//查询对应新文档的日志总数
	public int queryLogCountbyNewsTitle(String newsTitle);
	//添加日志
	public abstract void add(Log log);

	//删除日志
	public abstract boolean delete(int logID);

	//查询所有日志
	public abstract List<Log> queryAll(Page page);

	//通过adminName查询日志
	public abstract List<Log> queryByAdminName(Page page,String adminName);

	//通过newsTitle查询日志
	public abstract List<Log> queryByNewsTitle(Page page,String newsTitle);

}
package com.qllt.dao;

import java.util.List;

import com.qllt.po.Image;
import com.qllt.util.Page;

public interface ImageDAO {

	public abstract void save(Image image);

	public abstract void delete(Image image);

	public abstract Image queryByID(int imageID);

	public abstract void updateImage(Image image);
	public abstract List<Image> queryAllImage(Page page,int imageType);
	public abstract int queryImageCount(int imageType);
}
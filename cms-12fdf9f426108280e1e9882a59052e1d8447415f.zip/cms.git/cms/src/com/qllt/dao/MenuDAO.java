package com.qllt.dao;

import java.util.List;

import com.qllt.po.Menu;

public interface MenuDAO {

	//添加
	public abstract void save(Menu menu);

	//删除
	public abstract void delete(Menu menu);

	//查询
	public abstract Menu queryByID(int menuID);

	//更新
	public abstract void update(Menu menu);

	//查询所有
	public abstract List<Menu> queryAll();
	//
	public abstract Menu queryByName(String menuName);
}
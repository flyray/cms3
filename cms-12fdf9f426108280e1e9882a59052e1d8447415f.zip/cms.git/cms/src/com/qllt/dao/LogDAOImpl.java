package com.qllt.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qllt.po.Log;
import com.qllt.util.Page;

public class LogDAOImpl extends HibernateDaoSupport implements LogDAO{
	
	//添加日志
	public void add(Log log){
		this.getHibernateTemplate().save(log);
	}

	//查询日志总数
	public int queryLogCount(){
		String hql="select count(*) from Log";
		Object object=getHibernateTemplate().find(hql).get(0);
		long count=(Long)object;
		return (int)count;
	}
	//查询对应管理员的日志总数
	public int queryLogCountbyAdminName(String adminName){
		Object object=getHibernateTemplate().find("select count(*) from Log where adminName=?",adminName).get(0);
		long count=(Long)object;
		return (int)count;
	}
	//查询对应新闻的日志总数
	public int queryLogCountbyNewsTitle(String newsTitle){
		Object object=getHibernateTemplate().find("select count(*) from Log where newsTitle=?",newsTitle).get(0);
		long count=(Long)object;
		return (int)count;
	}
	//删除日志
	public boolean delete(int logID){
		List<Log> list=getHibernateTemplate().find("from Log where logID=?",logID);
		if(list.size()!=0){
			getHibernateTemplate().delete(list.get(0));
			return true;
		}else 
			return false;
		
	}
	//查询所有日志
	public  List<Log>  queryAll(Page page){
		Session session=getSession();
		Query query=session.createQuery("from Log order by time desc");
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	
	//通过adminName查询日志
	public List<Log> queryByAdminName(Page page,String adminName){
		Session session=getSession();
		Query query=session.createQuery("from Log where adminName=:adminName order by time desc").setString("adminName", adminName);
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
	//通过newsTitle查询日志
	public List<Log> queryByNewsTitle(Page page,String newsTitle){
		Session session=getSession();
		Query query=session.createQuery("from Log where newsTitle=:newsTitle order by time desc").setString("newsTitle", newsTitle);
		query.setFirstResult(page.getBeginIndex());
		query.setMaxResults(page.getEveryPage());
		return query.list();
	}
}

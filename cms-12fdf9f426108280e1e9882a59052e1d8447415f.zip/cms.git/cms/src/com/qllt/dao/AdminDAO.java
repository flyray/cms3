package com.qllt.dao;

import java.util.List;

import com.qllt.po.Admin;

public interface AdminDAO {

	//添加管理员
	public abstract void save(Admin admin);

	//修改管理员
	public abstract void updateAdmin(Admin admin);

	//删除管理员
	public abstract void deleteAdmin(Admin admin);

	//根据管理员权限查询
	public abstract List<Admin> queryAll();

	//通过adminID查询管理员
	public abstract Admin queryByAdminID(int adminID);
	
	public abstract Admin queryByAdminName(String adminName);
}
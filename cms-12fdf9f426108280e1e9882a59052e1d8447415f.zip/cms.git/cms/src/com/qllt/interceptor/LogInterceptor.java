package com.qllt.interceptor;

import java.util.Map;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
import com.qllt.po.Admin;
import com.qllt.po.AdminGroup;
import com.qllt.service.AdminService;

public class LogInterceptor extends  AbstractInterceptor{
	AdminService adminService;

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}
	@Override
	public String intercept(ActionInvocation arg0) throws Exception {
		ActionContext act = (ActionContext)arg0.getInvocationContext();
		Map session = act.getSession();
		String adminname = (String)session.get("adminName");
		Admin admin = adminService.queryAdminByAdminName(adminname);
		AdminGroup adminGroup = admin.getAdminGroup();
		String agName = adminGroup.getAgName();
		if(agName.equals("admin")){
			return arg0.invoke();
		}
		return null;
	}

}

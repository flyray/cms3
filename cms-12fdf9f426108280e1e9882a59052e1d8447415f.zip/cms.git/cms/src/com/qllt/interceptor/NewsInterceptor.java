package com.qllt.interceptor;

import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
import com.qllt.action.NewsAction;
import com.qllt.service.AdminService;
import com.qllt.service.LogService;
import com.qllt.po.Admin;
import com.qllt.po.AdminGroup;
import com.qllt.po.Log;
/**
 * 把所有删除操作写入日志。
 * @author Administrator
 *
 */
public class NewsInterceptor extends MethodFilterInterceptor {
	AdminService adminService;
	LogService logService;

	public void setLogService(LogService logService) {
		this.logService = logService;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}


	@Override
	protected String doIntercept(ActionInvocation arg0) throws Exception {
		String adminName;
		String subitems;//得到登陆管理员的权限字符串
		Admin admin;
		AdminGroup adminGroup;//得到管理员所属的权限组
		NewsAction action;//当前执行的action
		String subItemID;//当前执行action中的栏目号
		String result = null;
		
		//管理员执行的方法
		String method = arg0.getProxy().getMethod();
		//得到当前action
		action = (NewsAction)arg0.getAction();
		//新闻标题在此处获得，否则一旦删除就无法获得
		if(method.equals("delete")){//如果是删除方法，则需用action去查找newsTitle
			action.find();
		}
		String newsTitle = action.getTitle();
		//当前action的subItemID
		subItemID = Integer.toString(action.getSubItemID());
		
		
		//取出请求相关的ActionContext实例以及session和session中的admin属性
		ActionContext ctx = arg0.getInvocationContext();
		Map session = ctx.getSession();
		adminName = (String)session.get("adminName");
		//通过查询得到管理员所属的权限组
		if(adminName!=null){
			admin = adminService.queryAdminByAdminName(adminName);
			adminGroup=admin.getAdminGroup();
			//如果管理员是admin分组的，直接放行
			String agName = adminGroup.getAgName();
			if(agName.equals("admin")){
				result = arg0.invoke();
			}
			//得到管理员所能管理的子栏目的字符串，并转化为字符串数组
			subitems = adminGroup.getSubitemList();
			String []items = subitems.split(",");
			
			//判断管理员所管理栏目中是否包含正在处理的栏目
			for(int i=0;i<items.length;i++){
				if(items[i].equals(subItemID)||adminName.equals("admin")){
					result = arg0.invoke();
				}
			}
		}
		/*
		 * 将操作记录存到日志中
		 */
		
		//系统时间
		SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		String time=df.format(new Date());
		//ip
		String ip = org.apache.struts2.ServletActionContext.getRequest().getRemoteAddr();	

		//实例化日志
		Log log = new Log();
		log.setAdminName(adminName);
		log.setIp(ip);
		log.setMethod(method);
		log.setNewsTitle(newsTitle);
		log.setTime(time);
		//添加日志
		logService.add(log);
		return "nopopedom";
	}
}

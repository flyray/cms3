package com.qllt.interceptor;

import java.util.Map;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class UserInterceptor extends AbstractInterceptor {

	private int popedom;//定义一个属性，用于控制不同action的权限，任意一个acton对拦截器传入权限参数，
	public void setPopedom(int popedom) {
		this.popedom = popedom;
	}
	public String intercept(ActionInvocation invocation) throws Exception {
		ActionContext context=invocation.getInvocationContext();
		Map session =context.getContext().getSession();
		String username=(String)session.get("username");
		if(username==null||"".equals(username)){
			return Action.LOGIN;
		}else{
			return invocation.invoke();//不拦截进行下一步操作！
		}
	}

}

package com.qllt.interceptor;

import java.util.Map;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class AdminInterceptor extends AbstractInterceptor{
	public String intercept(ActionInvocation invocation) throws Exception{
		ActionContext ctx=invocation.getInvocationContext();
		Map session=ctx.getSession();
		String adminName=(String)session.get("adminName");
		if(adminName!=null){
			return invocation.invoke();
		}
		ctx.put("admin_denglu", "你还没有登录后台请登录");
		return Action.LOGIN;
		
	}
}

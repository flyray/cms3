package com.qllt.interceptor;

import java.util.Map;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
import com.qllt.service.AdminService;
import com.qllt.po.Admin;
import com.qllt.po.AdminGroup;
/*
 * 拦截对普通用户对admin表的添加，修改等操作
 */
public class AdminControlInterceptor extends MethodFilterInterceptor {

	AdminService adminService;

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}
	@Override
	public String doIntercept(ActionInvocation arg0) throws Exception {
		
		ActionContext ctx = arg0.getInvocationContext();
		Map session = ctx.getSession();
		String adminName = (String)session.get("adminName");
		Admin admin = adminService.queryAdminByAdminName(adminName);
		AdminGroup adminGroup = admin.getAdminGroup();
		String agName = adminGroup.getAgName();
		if(agName.equals("admin")){
			return arg0.invoke();
		}else{
			return null;
		}
		
	}

}

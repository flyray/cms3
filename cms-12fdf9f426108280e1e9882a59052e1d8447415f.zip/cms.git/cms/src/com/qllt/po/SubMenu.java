package com.qllt.po;

import java.util.Date;

public class SubMenu {
	private int subMenuID;
	private String subMenuName;
	private int subMenuOrder;
	private Date createTime;
	private String subMenuLink;
	private int menuID;
	public int getSubMenuID() {
		return subMenuID;
	}
	public void setSubMenuID(int subMenuID) {
		this.subMenuID = subMenuID;
	}
	public String getSubMenuName() {
		return subMenuName;
	}
	public void setSubMenuName(String subMenuName) {
		this.subMenuName = subMenuName;
	}
	public int getSubMenuOrder() {
		return subMenuOrder;
	}
	public void setSubMenuOrder(int subMenuOrder) {
		this.subMenuOrder = subMenuOrder;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getSubMenuLink() {
		return subMenuLink;
	}
	public void setSubMenuLink(String subMenuLink) {
		this.subMenuLink = subMenuLink;
	}
	public int getMenuID() {
		return menuID;
	}
	public void setMenuID(int menuID) {
		this.menuID = menuID;
	}
	
}

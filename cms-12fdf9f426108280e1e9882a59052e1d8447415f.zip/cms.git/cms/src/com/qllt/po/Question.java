package com.qllt.po;

import java.util.Date;

public class Question 
{
	private int questionID;
	private String title;
	private String content;
	private String name;
	private String email;
	private Date createTime;
	private int isshow;
	private String answer;
	private String classify;
	private String phone;
	//后续添加的5个属性
	private String replyperson;
	private Date replytime;
	private int broadcast;
	private int showorder;
	private Date settoptime;
	
	public Question()
	{}
	public Question(int questionID,String title,String content,String name,String email,Date createTime,int isshow,String answer,String classify,String phone,String replyperson,Date replytime,int broadcast,int showorder,Date settoptime)
	{
		super();
		this.questionID = questionID;
		this.title = title;
		this.content = content;
		this.name = name;
		this.email = email;
		this.createTime = createTime;
		this.isshow = isshow;
		this.answer = answer;
		this.classify = classify;
		this.phone = phone;
		//后续添加的5个方法
		this.replyperson=replyperson;
		this.replytime=replytime;
		this.broadcast=broadcast;
		this.showorder=showorder;
		this.settoptime=settoptime;
	}
	
	public Date getSettoptime() {
		return settoptime;
	}
	public void setSettoptime(Date settoptime) {
		this.settoptime = settoptime;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public String getReplyperson() {
		return replyperson;
	}
	public void setReplyperson(String replyperson) {
		this.replyperson = replyperson;
	}
	public Date getReplytime() {
		return replytime;
	}
	public void setReplytime(Date replytime) {
		this.replytime = replytime;
	}
	public int getBroadcast() {
		return broadcast;
	}
	public void setBroadcast(int broadcast) {
		this.broadcast = broadcast;
	}
	public int getShoworder() {
		return showorder;
	}
	public void setShoworder(int showorder) {
		this.showorder = showorder;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public int getQuestionID() {
		return questionID;
	}
	public void setQuestionID(int questionID) {
		this.questionID = questionID;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getIsshow() {
		return isshow;
	}
	public void setIsshow(int isshow) {
		this.isshow = isshow;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getClassify() {
		return classify;
	}
	public void setClassify(String classify) {
		this.classify = classify;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
}

package com.qllt.po;

import java.util.Date;

public class Item implements Comparable<Item>{
	private int itemID;
	private String itemName;
	private int order;
	private Date createTime;
	
	public Item() {
	}
	public Item(int itemID, String itemName, String itemLink, int order,
			Date createTime) {
		super();
		this.itemID = itemID;
		this.itemName = itemName;
		this.order = order;
		this.createTime = createTime;
	}
	public int getItemID() {
		return itemID;
	}
	public void setItemID(int itemID) {
		this.itemID = itemID;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public int compareTo(Item o) {
		// TODO Auto-generated method stub
		return o.getItemID()-this.getItemID();
	}
	
}

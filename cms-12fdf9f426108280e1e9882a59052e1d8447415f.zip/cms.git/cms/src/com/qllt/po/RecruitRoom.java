package com.qllt.po;

import java.util.ArrayList;
import java.util.List;

public class RecruitRoom {
	
	private int recruitRoomID;
	private String recruitRoomName;
	private int recruitRoomBelong;
	private int recruitRoomState;
	private List<RecruitRoom> recruitRoomList;
	
	
	public int getRecruitRoomID(){
		return recruitRoomID;
	}
	public void setRecruitRoomID(int recruitRoomID) {
		this.recruitRoomID = recruitRoomID;
	}
	public String getRecruitRoomName() {
		return recruitRoomName;
	}
	public void setRecruitRoomName(String recruitRoomName) {
		this.recruitRoomName = recruitRoomName;
	}
	public int getRecruitRoomBelong() {
		return recruitRoomBelong;
	}
	public void setRecruitRoomBelong(int recruitRoomBelong) {
		this.recruitRoomBelong = recruitRoomBelong;
	}
	public List<RecruitRoom> getRecruitRoomList() {
		return recruitRoomList;
	}
	public void setRecruitRoomList(List<RecruitRoom> recruitRoomList) {
		this.recruitRoomList = recruitRoomList;
	}
	public int getRecruitRoomState() {
		return recruitRoomState;
	}
	public void setRecruitRoomState(int recruitRoomState) {
		this.recruitRoomState = recruitRoomState;
	}
	
}

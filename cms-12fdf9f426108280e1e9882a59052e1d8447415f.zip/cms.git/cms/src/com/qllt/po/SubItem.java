package com.qllt.po;

import java.util.Date;

public class SubItem {
	private int subItemID;
	private String subItemName;
	private Item item;
	private int order;
	private Date createTime;
	
	public SubItem() {
	}
	public SubItem(int subItemID, String subItemName, Item item, int order,
			String subItemLink) {
		super();
		this.subItemID = subItemID;
		this.subItemName = subItemName;
		this.item = item;
		this.order = order;
	}
	
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public int getSubItemID() {
		return subItemID;
	}
	public void setSubItemID(int subItemID) {
		this.subItemID = subItemID;
	}
	public String getSubItemName() {
		return subItemName;
	}
	public void setSubItemName(String subItemName) {
		this.subItemName = subItemName;
	}
	
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
}

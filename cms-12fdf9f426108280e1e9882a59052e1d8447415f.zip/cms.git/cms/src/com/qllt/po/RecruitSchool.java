package com.qllt.po;

import java.util.List;

public class RecruitSchool {
	
	private int recruitSchoolID;
	private String recruitSchoolName;
	private int recruitSchoolNum;
	private List<RecruitSchool> recruitSchoolList;//记录查询得到的校区名字列表
	
	
	
	public int getRecruitSchoolID() {
		return recruitSchoolID;
	}
	public void setRecruitSchoolID(int recruitSchoolID) {
		this.recruitSchoolID = recruitSchoolID;
	}
	public List<RecruitSchool> getRecruitSchoolList() {
		return recruitSchoolList;
	}
	public void setRecruitSchoolList(List<RecruitSchool> recruitSchoolList) {
		this.recruitSchoolList = recruitSchoolList;
	}
	public String getRecruitSchoolName() {
		return recruitSchoolName;
	}
	public void setRecruitSchoolName(String recruitSchoolName) {
		this.recruitSchoolName = recruitSchoolName;
	}
	public int getRecruitSchoolNum() {
		return recruitSchoolNum;
	}
	public void setRecruitSchoolNum(int recruitSchoolNum) {
		this.recruitSchoolNum = recruitSchoolNum;
	}
	
}

package com.qllt.po;

import java.util.Date;
import java.util.List;


/**
 * Menu entity. @author MyEclipse Persistence Tools
 */

public class Menu {
	
	private int menuID;
	private String menuName;
	private int menuOrder;
	private Date createTime;
	private String menuLink;
	private List<SubMenu> submenus;
	public int getMenuID() {
		return menuID;
	}
	public void setMenuID(int menuID) {
		this.menuID = menuID;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public int getMenuOrder() {
		return menuOrder;
	}
	public void setMenuOrder(int menuOrder) {
		this.menuOrder = menuOrder;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getMenuLink() {
		return menuLink;
	}
	public void setMenuLink(String menuLink) {
		this.menuLink = menuLink;
	}
	public List<SubMenu> getSubmenus() {
		return submenus;
	}
	public void setSubmenus(List<SubMenu> submenus) {
		this.submenus = submenus;
	}
	

}
package com.qllt.po;

import java.io.Serializable;

/**
 * 权限说明：
 * 权限除了基本的添加、删除修改，最重要的是置顶权限。
 * @author 张帅
 *
 */
public class AdminGroup implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int gid;
	private String agName;
	private String subitemList;
	private int popedom;
	
	public String getAgName() {
		return agName;
	}
	public void setAgName(String agName) {
		this.agName = agName;
	}
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getSubitemList() {
		return subitemList;
	}
	public void setSubitemList(String subitemList) {
		this.subitemList = subitemList;
	}
	public int getPopedom() {
		return popedom;
	}
	public void setPopedom(int popedom) {
		this.popedom = popedom;
	}
	
}

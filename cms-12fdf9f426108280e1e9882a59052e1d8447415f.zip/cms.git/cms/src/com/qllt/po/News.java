package com.qllt.po;

import java.util.Date;

public class News {
	private int newsID;
	private String title;
	private String content;
	private Date createtime;
	private int settop;
	private Date settoptime;
	private String link;	//用于直接链接
	private int islink;	//是否是直接链接
	private String source;	//来源
	private String author;	//作者
	private Admin editor;	//编辑人
	private String color;	//标题颜色
	private SubItem subItem;	//所属栏目
	private boolean isrecruit;	//是否是招聘类型新闻
	private Date recrutTime;	//招聘时间
	private Date recruitTimeEnd;
	private int recruitAddress;	//招聘地点
	private int positionNum;	//招聘岗位数
	private int hasread;
	private int bold;
//为了招聘教室信息的查询额外添加的两个属性
	private String recruitRoomName;
	private String recruitSchoolName;
	public News() {
	}
	public News(int newsID, String title, String content, Date createtime,
			int settop, Date settoptime, String link, int islink,
			String source, String author, Admin editor, String color,
			SubItem subItem, boolean isrecruit, Date recrutTime,Date recruitTimeEnd,
			int recruitAddress, int positionNum, int hasread,int bold) {
		super();
		this.newsID = newsID;
		this.title = title;
		this.content = content;
		this.createtime = createtime;
		this.settop = settop;
		this.settoptime = settoptime;
		this.link = link;
		this.islink = islink;
		this.source = source;
		this.author = author;
		this.editor = editor;
		this.color = color;
		this.subItem = subItem;
		this.isrecruit = isrecruit;
		this.recrutTime = recrutTime;
		this.recruitTimeEnd = recruitTimeEnd;
		this.recruitAddress = recruitAddress;
		this.positionNum = positionNum;
		this.hasread = hasread;
		this.bold=bold;
	}
	public News(int newsID, String title,int settop, Date createtime){
		this.newsID = newsID;
		this.title = title;
		this.settop = settop;
		this.createtime = createtime;
	}
	public News(int newsID, String title,int settop, Date createtime,Date recrutTime,int recruitAddress){
		this.newsID = newsID;
		this.title = title;
		this.settop = settop;
		this.createtime = createtime;
		this.recrutTime = recrutTime;
		this.recruitAddress = recruitAddress;
	}
	//根据关键字查询新闻列表
	public News(int newsID,String title,int settop,Date createtime,Date recrutTime,SubItem subItem){
		this.newsID=newsID;
		this.title=title;
		this.settop=settop;
		this.createtime=createtime;
		this.recrutTime=recrutTime;
		this.subItem=subItem;
	}
	//android 访问接口获取最新10条动态
	public News(int newsID,String title,int settop,Date createtime,String content){
		this.newsID = newsID;
		this.title = title;
		this.settop = settop;
		this.createtime = createtime;
		this.content=content;
	}
	public Date getRecruitTimeEnd() {
		return recruitTimeEnd;
	}
	public void setRecruitTimeEnd(Date recruitTimeEnd) {
		this.recruitTimeEnd = recruitTimeEnd;
	}
	public String getRecruitRoomName() {
		return recruitRoomName;
	}
	public void setRecruitRoomName(String recruitRoomName) {
		this.recruitRoomName = recruitRoomName;
	}
	public String getRecruitSchoolName() {
		return recruitSchoolName;
	}
	public void setRecruitSchoolName(String recruitSchoolName) {
		this.recruitSchoolName = recruitSchoolName;
	}
	public int getBold() {
		return bold;
	}
	public void setBold(int bold) {
		this.bold = bold;
	}
	public int getHasread() {
		return hasread;
	}
	public void setHasread(int hasread) {
		this.hasread = hasread;
	}
	public int getPositionNum() {
		return positionNum;
	}
	public void setPositionNum(int positionNum) {
		this.positionNum = positionNum;
	}
	public int getNewsID() {
		return newsID;
	}
	public void setNewsID(int newsID) {
		this.newsID = newsID;
	}
	public String getTitle() {
		return title;
	}
	//重载getTitle便于前台页面从数据库截取自定义的字数
	public String getTitle(int len){
		if(len<title.length()){
			return title.substring(0,len);
		}else{
			return title;
		}
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public int getSettop() {
		return settop;
	}
	public void setSettop(int settop) {
		this.settop = settop;
	}
	public Date getSettoptime() {
		return settoptime;
	}
	public void setSettoptime(Date settoptime) {
		this.settoptime = settoptime;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	
	public int getIslink() {
		return islink;
	}
	public void setIslink(int islink) {
		this.islink = islink;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Admin getEditor() {
		return editor;
	}
	public void setEditor(Admin editor) {
		this.editor = editor;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public SubItem getSubItem() {
		return subItem;
	}
	public void setSubItem(SubItem subItem) {
		this.subItem = subItem;
	}
	public boolean isIsrecruit() {
		return isrecruit;
	}
	public void setIsrecruit(boolean isrecruit) {
		this.isrecruit = isrecruit;
	}
	public Date getRecrutTime() {
		return recrutTime;
	}
	public void setRecrutTime(Date recrutTime) {
		this.recrutTime = recrutTime;
	}
	public int getRecruitAddress() {
		return recruitAddress;
	}
	public void setRecruitAddress(int recruitAddress) {
		this.recruitAddress = recruitAddress;
	}
}

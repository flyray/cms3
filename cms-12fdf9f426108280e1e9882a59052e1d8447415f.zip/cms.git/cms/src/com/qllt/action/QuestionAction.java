package com.qllt.action;

import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.opensymphony.xwork2.ActionContext;
import com.qllt.po.Question;
import com.qllt.service.QuestionService;
import com.qllt.util.Page;
import com.qllt.util.Result;

public class QuestionAction 
{
	private int questionID;
	private String title;
	private String content;
	private String name;
	private String email;
	private int isshow;
	private Date createTime;
	private int currentPage=1;
	private int everyPage;
	private String answer;
	private String classify;
	private String phone;
	//新添加的五个属性
	private String replyperson;
	private Date replytime;
	private int broadcast;
	private int showorder;
	private Date settoptime;
	
	private int fenlei;
	private Page page;
	private String ajax_message;
	private List<Question> questionlist;
	private QuestionService questionService;
	
	public String getReplyperson() {
		return replyperson;
	}
	public void setReplyperson(String replyperson) {
		this.replyperson = replyperson;
	}
	public Date getReplytime() {
		return replytime;
	}
	public void setReplytime(Date replytime) {
		this.replytime = replytime;
	}
	public int getBroadcast() {
		return broadcast;
	}
	public void setBroadcast(int broadcast) {
		this.broadcast = broadcast;
	}
	public int getShoworder() {
		return showorder;
	}
	public void setShoworder(int showorder) {
		this.showorder = showorder;
	}
	public Date getSettoptime() {
		return settoptime;
	}
	public void setSettoptime(Date settoptime) {
		this.settoptime = settoptime;
	}
	public int getQuestionID() {
		return questionID;
	}
	public void setQuestionID(int questionID) {
		this.questionID = questionID;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getIsshow() {
		return isshow;
	}
	public void setIsshow(int isshow) {
		this.isshow = isshow;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getClassify() {
		return classify;
	}
	public void setClassify(String classify) {
		this.classify = classify;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getFenlei() {
		return fenlei;
	}
	public void setFenlei(int fenlei) {
		this.fenlei = fenlei;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getEveryPage() {
		return everyPage;
	}
	public void setEveryPage(int everyPage) {
		this.everyPage = everyPage;
	}
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
	public List<Question> getQuestionlist() {
		return questionlist;
	}
	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}
	public QuestionService getQuestionService() {
		return questionService;
	}
	public void setQuestionService(QuestionService questionService) {
		this.questionService = questionService;
	}
	public String getAjax_message() {
		return ajax_message;
	}
	public void setAjax_message(String ajax_message) {
		this.ajax_message = ajax_message;
	}
	/**
	 * 添加提问
	 * @return 
	 */
	public String add()
	{
		if(title!=null&&content!=null&&name!=null&&email!=null)
		{
			switch(fenlei)
			{
				case 1:
					classify="就业管理部";
					break;
				case 2:
					classify="就业指导部";
					break;
				case 3:
					classify="就业市场部";
					break;
				case 4:
					classify="就业信息部";
					break;
				case 5:
					classify="";
					break;
				default:
					classify="其它";
					break;
			}
		Question question=new Question();
		question.setTitle(title);
		question.setContent(content);
		Date date=new Date();
		question.setCreateTime(date);
		question.setName(name);
		question.setEmail(email);
		question.setAnswer(answer);
		question.setClassify(classify);
		question.setPhone(phone);
		//新添加的五个属性
		broadcast=0;
		showorder=0;
		
		question.setBroadcast(broadcast);
		question.setShoworder(showorder);
		
		
		questionService.addQuestion(question);
		return "add_s";
		}
		else
		{
			return "add_f";
		}
	}
	/**
	 * 删除提问
	 * @return
	 */
	public String delete()
	{
		questionService.deleteQuestionByID(questionID);
		return "delete_s";
	}
	public String delete1()
	{
		questionService.deleteQuestionByID(questionID);
		return "delete1_s";
	}
	/**
	 * 修改提问
	 * @return
	 */
	public String update()
	{
		Question question=new Question();
		question.setQuestionID(questionID);
		question.setTitle(title);
		question.setContent(content);
		question.setCreateTime(createTime);
		question.setAnswer(answer);
		question.setName(name);
		question.setEmail(email);
		question.setIsshow(isshow);
		question.setAnswer(answer);
		question.setClassify(classify);
		question.setPhone(phone);
		//新加的五个属性
		question.setReplyperson(replyperson);
		question.setReplytime(replytime);
		question.setBroadcast(broadcast);
		question.setShoworder(showorder);
		question.setSettoptime(settoptime);
		currentPage=getCurrentPage();//修改后跳转到当前页
		questionService.updateQuestion(question);
		return "update_s";
	}
	/**
	 * 回复提问并发送邮件
	 * @return
	 */
	public String update1()
	{
		Question question=new Question();
		question.setQuestionID(questionID);
		question.setTitle(title);
		question.setContent(content);
		question.setCreateTime(createTime);
		question.setAnswer(answer);
		question.setName(name);
		question.setEmail(email);
		question.setIsshow(isshow);
		question.setClassify(classify);
		question.setPhone(phone);
		//新加的五个属性
		question.setReplyperson(replyperson);
		Date date=new Date();
		question.setReplytime(date);
		question.setBroadcast(broadcast);
		question.setShoworder(showorder);
		question.setSettoptime(settoptime);
		
		
		currentPage=getCurrentPage();//修改后跳转到当前页
		questionService.updateQuestion(question);
		if(sendEmail(email,answer,classify).equals("send_s"))
				return "update1_s";
		else
			return "update1_f";
	}
	/**
	 * Ajax方式查询详细提问
	 * @return
	 */
	public String find()
	{
		Question question=questionService.findQuestionByID(questionID);
		title=question.getTitle();
		content=question.getContent();
		createTime=question.getCreateTime();
		answer=question.getAnswer();
		name=question.getName();
		email=question.getEmail();
		isshow=question.getIsshow();
		classify=question.getClassify();
		phone=question.getPhone();
		//新添的五个属性
		replyperson=question.getReplyperson();
		replytime=question.getReplytime();
		broadcast=question.getBroadcast();
		showorder=question.getShoworder();
		settoptime=question.getSettoptime();
		return "find_s";
	}
	/**
	 * 分页查询所有提问
	 * @return
	 */
	public String findAll()
	{
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(10);
		Result result=questionService.findAllQuestion(zpage);
		page=result.getPage();
		questionlist=result.getList();
		return "findAll_s";
	}
	//分页查询所有未回复提问
	public String findAllNot(){
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(10);
		Result result=questionService.findAllQuestion1(zpage);
		page=result.getPage();
		questionlist=result.getList();
		return "findAllNot_s";
	}
	//不分页查询所有未回复提问
	public String findAllNotAnswer(){
		questionlist=questionService.findAllNotAnswer();
		return "findAllNotAnswer_s";
	}
	/**
	 * 分页查询每个分类下所有提问(各部门)
	 * @return
	 */
	public String findAll1()
	{
		switch(fenlei)//纯粹为了解决乱码的无奈之举
		{
			case 1:
				classify="就业管理部";
				break;
			case 2:
				classify="就业指导部";
				break;
			case 3:
				classify="就业市场部";
				break;
			case 4:
				classify="就业信息部";
				break;
			case 5:
				classify="";
				break;
			default:
				classify="其它";
				break;
		}
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(10);
		Result result = questionService.findClassifyQuestion(zpage,classify);
		page=result.getPage();
		questionlist=result.getList();
		return "findAll1_s";
	}
	/**
	 * 不分页查询每个分类下所有未回复提问(各部门)
	 * @return
	 */
	public String findAll1Not()
	{
		switch(fenlei)//纯粹为了解决乱码的无奈之举
		{
			case 1:
				classify="就业管理部";
				break;
			case 2:
				classify="就业指导部";
				break;
			case 3:
				classify="就业市场部";
				break;
			case 4:
				classify="就业信息部";
				break;
			case 5:
				classify="";
				break;
			default:
				classify="其它";
				break;
		}
		
		questionlist = questionService.findClassifyQuestionNot(classify);
		return "findAll1Not_s";
	}
	/**
	 * 分页查询每个分类下所有已回复提问
	 * @return
	 */
	public String findAll1Yes()
	{
		switch(fenlei)//纯粹为了解决乱码的无奈之举
		{
			case 1:
				classify="就业管理部";
				break;
			case 2:
				classify="就业指导部";
				break;
			case 3:
				classify="就业市场部";
				break;
			case 4:
				classify="就业信息部";
				break;
			case 5:
				classify="";
				break;
			default:
				classify="其它";
				break;
		}
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(10);
		Result result=questionService.findClassifyQuestionYes(zpage,classify);
		page=result.getPage();
		questionlist=result.getList();
		return "findAll1Yes_s";
	}
	
	
	
	/*
	 * 发送邮件模块
	 */
	public String sendEmail(String where,String content,String classify)
	{
		String departmentEmail="sdu_xinxibu@163.com";//部门邮箱(默认信息网)
		String password="xinxibu_sdu";//邮箱密码
		if(classify.equals("就业管理部"))
		{
			departmentEmail="sdu_guanlibu@163.com";
			password="guanlibu_sdu";
		}
		else if(classify.equals("就业市场部"))
		{
			departmentEmail="sdu_shichangbu@163.com";
			password="shichangbu_sdu";
		}
		else if(classify.equals("就业信息部"))
		{
			departmentEmail="sdu_xinxibu@163.com";
			password="xinxibu_sdu";
		}
		else if(classify.equals("就业指导部"))
		{
			departmentEmail="sdu_zhidaobu@163.com";
			password="zhidaobu_sdu";
		}
		else
		{
			departmentEmail="sdu_xinxibu@163.com";//测试邮箱
			password="xinxibu_sdu";
		}
		try
		{
			//邮件信息
			String to_mail=where;//要发送到那个邮箱
			String to_title="山东大学就业指导中心问题回复";//邮件标题
			String to_content=content;//邮件正文
			//--------建立邮件会话--------
			Properties props=new Properties();//也可用Properties props = System.getProperties(); 
			props.put("mail.smtp.host","smtp.163.com");  //存储发送邮件服务器的信息
			props.put("mail.smtp.auth","true");       //同时通过验证
			Session s=Session.getInstance(props);         //根据属性新建一个邮件会话
			s.setDebug(true);
			//----由邮件会话新建一个消息对象----
			MimeMessage message=new MimeMessage(s);   //由邮件会话新建一个消息对象
			//--------设置邮件--------
			InternetAddress from=new InternetAddress(departmentEmail);
			message.setFrom(from);              //设置发件人
			InternetAddress to=new InternetAddress(to_mail);
			message.setRecipient(Message.RecipientType.TO,to);
			//设置收件人,并设置其接收类型为TO
			message.setSubject(to_title);       //设置主题
			message.setText(to_content);        //设置信件内容
			message.setSentDate(new Date());    //设置发信时间
			//--------发送邮件--------
			message.saveChanges();              //存储邮件信息
			Transport transport=s.getTransport("smtp");
			//--以smtp方式登录邮箱,第一个参数是发送邮件用的邮件服务器SMTP地址;第二个参数为用户名;第3个参数为密码
			transport.connect("smtp.163.com",departmentEmail,password);
			//发送邮件,其中第二个参数是所有已设好的收件人地址
			transport.sendMessage(message,message.getAllRecipients());
			transport.close();
		}
		catch(MessagingException e)
		{
			return "send_f";
		}
		return "send_s";
	}
}

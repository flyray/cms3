package com.qllt.action;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.qllt.util.RandomValidateCode;

public class ImageValidateAction extends ActionSupport{
	private String inputString;
	public String execute() throws Exception {
		HttpServletResponse response = ServletActionContext.getResponse();
		HttpServletRequest request=ServletActionContext.getRequest();
		response.setContentType("image/jpeg");//设置相应类型,告诉浏览器输出的内容为图片
	    response.setHeader("Pragma", "No-cache");//设置响应头信息，告诉浏览器不要缓存此内容
	    response.setHeader("Cache-Control", "no-cache");
	    response.setDateHeader("Expire", 0);
	    RandomValidateCode randomValidateCode = new RandomValidateCode();
	    randomValidateCode.getRandcode(request,response);
	    return null;
	}
	//把验证码的验证放到服务器端，避免session不同步的问题
	public String numCheck(){
		Map session=ActionContext.getContext().getSession();
		String sessionString=(String) session.get(RandomValidateCode.RANDOMCODEKEY);
		//ajax返回客户端
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		String ajax_message=null;;
		if(inputString.equalsIgnoreCase(sessionString)){
			ajax_message="{'yes':'"+1+"'}";
		}else{
			ajax_message="{'yes':'"+0+"'}";
		}
		try {
			response.getWriter().write(ajax_message);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
	public String getInputString() {
		return inputString;
	}
	public void setInputString(String inputString) {
		this.inputString = inputString;
	}
	
}

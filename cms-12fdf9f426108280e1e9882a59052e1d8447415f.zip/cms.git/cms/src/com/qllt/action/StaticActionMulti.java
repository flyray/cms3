package com.qllt.action;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import javax.servlet.ServletContext;


import com.qllt.po.Item;
import com.qllt.po.News;
import com.qllt.po.RecruitRoom;
import com.qllt.po.RecruitSchool;
import com.qllt.po.SubItem;
import com.qllt.service.NewsService;
import com.qllt.service.RecruitRoomService;
import com.qllt.service.RecruitSchoolService;
import com.qllt.service.SubItemService;
import com.qllt.util.FreeMarker;
import com.qllt.util.Page;
import com.qllt.util.PageUtil;

public class StaticActionMulti implements Runnable{
	static int subitemlistindex=0;
	static int subItemListLength;
	static int metux=1;
	static int[] subItemList;
	static SubItemService subItemService;
	static NewsService newsService;
	static int everyPage;
	static String basePath;
	static ServletContext  actionContext;
	static String templateFile;
	static RecruitSchoolService recruitSchoolService;//根据招聘校区编号查询招聘校区
	static RecruitRoomService recruitRoomService;//根据招聘教室ID查询招聘教室
	
	int subitemindex=0;//每个线程单独一个subitemindex
	
	int currentPage;
	String templatePath = "/";
	Page page=new Page();
	
	public void initSubitem(int subItemListLength,int []subItemList,int everyPage,SubItemService subItemService,NewsService newsService,RecruitSchoolService recruitSchoolService,RecruitRoomService recruitRoomService,String basePath,ServletContext  actionContext,String templateFile){
		this.subItemListLength=subItemListLength;
		this.subItemList=subItemList;
		subitemlistindex=0;
		
		this.everyPage=everyPage;
		this.subItemService=subItemService;
		this.newsService=newsService;
		this.recruitRoomService=recruitRoomService;
		this.recruitSchoolService=recruitSchoolService;
		this.basePath=basePath;
		this.actionContext=actionContext;
		this.templateFile=templateFile;
		
		StaticActionMulti t1=new StaticActionMulti();
		StaticActionMulti t2=new StaticActionMulti();
		
		new Thread(t1).start();
		new Thread(t2).start();
	}
	
	public void run() {
		// TODO Auto-generated method stub
		while(subitemlistindex<subItemListLength){
			while(p()==false){
				//循环忙等
			}
			this.subitemindex=subitemlistindex;
			subitemlistindex++;
			v();
			//多线程生成静态化subitem列表页
			currentPage = 1;//每次重置当前页
			page.setCurrentPage(currentPage);
			page.setEveryPage(everyPage);
			//得到一级栏目名称和其下二级栏目的名称
			SubItem subItem = subItemService.findSubItemByID(subItemList[subitemindex]);
			Item it = subItem.getItem();
			List<SubItem> subItemList1 = subItemService.findAllSubItem(it.getItemID());
			//求出新闻条数和新闻页数
			int newsNum = newsService.queryNewsCountBySubItemID(subItemList[subitemindex]);
			int pageNum;
			if(newsNum%everyPage==0){
				pageNum = newsNum/everyPage;
			}
			else{
				pageNum = newsNum/everyPage+1;
			}
			//为每个二级栏目分页生成静态文件
			for(int j=0;j<pageNum;j++){
				page=PageUtil.createPage(page,newsNum);
				List<News> newsList = newsService.queryNewsListByNewsSubItemID(subItemList[subitemindex], page);
				String FilePath = "html/subItems/"+"subItem"+subItemList[subitemindex]+"-"+currentPage+".html";
				Map<String,Object> root=new HashMap<String, Object>();
				root.put("item",it);
				root.put("subItem",subItem);
				root.put("subItemList", subItemList1);
				root.put("newsList", newsList);
				root.put("currentPage", currentPage);
				root.put("pageNum",pageNum);
				root.put("basePath",basePath);
				//如果是校内招聘，用特定模板，其他的用另外模板
				if(subItemList[subitemindex]==17){
					//为新闻list中的每个新闻添加recruitAddress2属性
					for(News news_temp:newsList){
						int recruitAddress=news_temp.getRecruitAddress();
						RecruitRoom recruitRoom_temp=recruitRoomService.findRecruitRoomByID(recruitAddress);
						news_temp.setRecruitRoomName(recruitRoom_temp.getRecruitRoomName());
						
						//查询招聘校区信息
						int recruitSchoolNum=recruitRoom_temp.getRecruitRoomBelong();
						RecruitSchool recruitSchool_temp=recruitSchoolService.findRecruitSchoolByNum(recruitSchoolNum);
						news_temp.setRecruitSchoolName(recruitSchool_temp.getRecruitSchoolName());
					}
					String templateFileSpecial = "WEB-INF/templates/schoolrecuit_subitem.ftl";
					FreeMarker.analysisTemplatePath(templatePath,templateFileSpecial,FilePath,root,actionContext);
					//FreeMarker.analysisTemplate(templatePath,templateFileSpecial,FilePath,root);
				}
				else{
					FreeMarker.analysisTemplatePath(templatePath,templateFile,FilePath,root,actionContext);
				}
				//FreeMarker.analysisTemplatePath(templatePath,templateFile,FilePath,root,actionContext);
				currentPage++;
				page.setCurrentPage(currentPage);
			}
			
			
		}
		
		
	}
	public boolean createSubitem(){
		
		
		
		return true;
	}
	
	public static synchronized boolean p(){
		metux--;
		if(metux<0){
			metux++;
			return false;
		}
		return true;
	}
	public static synchronized boolean v(){
		metux++;
		if(metux>1){
			metux--;
			return false;
		}
		return true;
	}
	
}

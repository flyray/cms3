package com.qllt.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.qllt.po.AdminGroup;
import com.qllt.po.Item;
import com.qllt.po.SubItem;
import com.qllt.service.AdminGroupService;
import com.qllt.service.AdminService;
import com.qllt.service.ItemService;
import com.qllt.service.SubItemService;
import com.qllt.util.CommonMethod;

public class AdminGroupAction extends ActionSupport{
	private int gid;
	private String agName;
	private String[] subitemList;
	private int popedom;
	private List<AdminGroup> list;
	private List<SubItem> subItems;
	private List<Item> itemList;
	private ItemService itemService;
	private AdminGroupService adminGroupService;
	private SubItemService subItemService;
	private AdminService adminService;
	private String subitem_add;
	
	
	public String getSubitem_add() {
		return subitem_add;
	}
	public void setSubitem_add(String subitem_add) {
		this.subitem_add = subitem_add;
	}
	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}
	public void setSubItemService(SubItemService subItemService) {
		this.subItemService = subItemService;
	}
	public String getAgName() {
		return agName;
	}
	public void setAgName(String agName) {
		this.agName = agName;
	}
	public void setAdminGroupService(AdminGroupService adminGroupService) {
		this.adminGroupService = adminGroupService;
	}
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	
	public List<SubItem> getSubItems() {
		return subItems;
	}
	public void setSubItems(List<SubItem> subItems) {
		this.subItems = subItems;
	}
	
	public List<Item> getItemList() {
		return itemList;
	}
	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}
	public void setItemService(ItemService itemService) {
		this.itemService = itemService;
	}
	public String[] getSubitemList() {
		return subitemList;
	}
	public void setSubitemList(String[] subitemList) {
		this.subitemList = subitemList;
	}
	public int getPopedom() {
		return popedom;
	}
	public void setPopedom(int popedom) {
		this.popedom = popedom;
	}
	public List<AdminGroup> getList() {
		return list;
	}
	public void setList(List<AdminGroup> list) {
		this.list = list;
	}
	public String add(){
		AdminGroup ag=new AdminGroup();
		ag.setGid(gid);
		ag.setAgName(agName);
		if(subitemList!=null){
			String subitem_data=CommonMethod.SA2S(subitemList);//String[]转换成String，方便存入数据库
			ag.setSubitemList(subitem_data);
		}
		ag.setPopedom(popedom);
		adminGroupService.add(ag);
		this.addActionMessage("添加成功！");
		return "add_s";
	}
	
	public String find_Ajax(){
		HttpServletRequest request=ServletActionContext.getRequest();
		int gid=Integer.parseInt(request.getParameter("gid"));
		AdminGroup ag=adminGroupService.findByID(gid);
		gid=ag.getGid();
		agName=ag.getAgName();
		String[] subitemList=CommonMethod.S2SA(ag.getSubitemList().trim());
		subItems=new ArrayList<SubItem>();
		itemList = itemService.findAllItem();
		for(int i=0;i<subitemList.length;i++){
			SubItem subItem=subItemService.findSubItemByID(Integer.valueOf(subitemList[i]));
			subItems.add(subItem);
		}
		popedom=ag.getPopedom();
		String ajax_message;
		ajax_message="{'gid':'"+gid+"','subItems':'"+subItems+"','popedom':'"+popedom+"','itemList':'"+itemList+"','agName':'"+agName+"'}";
		//ajax返回客户端
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(ajax_message);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
	public String find(){
		AdminGroup adminGroup=adminGroupService.findByID(gid);
		agName=adminGroup.getAgName();
		if(adminGroup.getSubitemList()!=null){
			String[] subitemList=CommonMethod.S2SA(adminGroup.getSubitemList().trim());
			subItems=new ArrayList<SubItem>();
			for(int i=0;i<subitemList.length;i++){
				SubItem subItem=subItemService.findSubItemByID(Integer.valueOf(subitemList[i]));
				subItems.add(subItem);
			}
		}
		popedom=adminGroup.getPopedom();
		return "find_s";
	}
	public String update(){
		AdminGroup ag=new AdminGroup();
		ag.setGid(gid);
		ag.setAgName(agName);
		if(subitemList!=null){
			String subitem_data=CommonMethod.SA2S(subitemList);//String[]转换成String，方便存入数据库
			if(!subitem_add.equals("-1"))
				subitem_data+=","+subitem_add;
			ag.setSubitemList(subitem_data);
		}
		ag.setPopedom(popedom);
		adminGroupService.update(ag);
		this.addActionMessage("修改成功！");
		return "update_s";
	}
	public String delete(){
		AdminGroup ag=adminGroupService.findByID(gid);
		agName = ag.getAgName();
		if(agName=="admin"){//默认admin管理组不能删除
			this.addActionMessage("最高权限admin管理组，不能删除！");
			return "delete_e";
		}else{
			adminGroupService.delete(ag);
			this.addActionMessage("删除成功！");
			return "delete_s";
		}
	}
	public String findAll(){
		subItems=subItemService.findAllSubItem();
		list=adminGroupService.findAll();
		itemList=itemService.findAllItem();
		return "findAll_s";
	}
	public String look(){
		find();
		return "look_s";
	}
}
package com.qllt.action;

import java.util.Date;
import java.util.List;

import com.opensymphony.xwork2.ActionSupport;
import com.qllt.po.Log;
import com.qllt.service.LogService;
import com.qllt.service.LogServiceImpl;
import com.qllt.util.Page;
import com.qllt.util.Result;
import com.qllt.po.Log;

public class LogAction extends ActionSupport{
	private int logID;
	private String adminName;
	private String newsTitle;
	private String ip;
	private Date time;
	private List<Log> list;//记录查询到的日志列表
	private int currentPage=1;
	private Page page;
	
	
	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	public List<Log> getList() {
		return list;
	}

	public void setList(List<Log> list) {
		this.list = list;
	}

	public int getLogID() {
		return logID;
	}

	public void setLogID(int logID) {
		this.logID = logID;
	}

	
	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getNewsTitle() {
		return newsTitle;
	}

	public void setNewsTitle(String newsTitle) {
		this.newsTitle = newsTitle;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	private LogService logService;

	public void setLogService(LogService logService) {
		this.logService = logService;
	}
	
	//删除日志
	public String delete(){
		if(logService.delete(logID)){
			this.addActionMessage("删除成功");
		}else
			this.addActionMessage("删除失败");
		return "delete";
	}
	
	//查询所有日志
	public String findAll(){
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(20);
		Result result = logService.queryAll(zpage);
		page=result.getPage();
		list=result.getList();
		return "find";
	}
	//通过adminName查询日志
	public String adminName_findAll(){
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(20);
		Result result = logService.queryByAdminName(zpage,adminName);
		page=result.getPage();
		list=result.getList();
		return "find_adminName";
	}

	//通过newsTitle查询日志
	public String news_findAll(){
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(20);
		Result result = logService.queryByNewsTitle(zpage,newsTitle);
		page=result.getPage();
		list=result.getList();
		return "find_news";
	}
	
}

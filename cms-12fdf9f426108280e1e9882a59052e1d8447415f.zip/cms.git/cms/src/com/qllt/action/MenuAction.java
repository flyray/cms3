package com.qllt.action;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.qllt.po.Menu;
import com.qllt.service.MenuService;

public class MenuAction extends ActionSupport {

	private int menuID;
	private String menuName;
	private int menuOrder;
	private Date createTime;
	private String menuLink;
	private List<Menu> menulist;
	private MenuService menuService;
	
	public void setMenuService(MenuService menuService) {
		this.menuService = menuService;
	}
	
	public List<Menu> getMenulist() {
		return menulist;
	}

	public void setMenulist(List<Menu> menulist) {
		this.menulist = menulist;
	}

	public int getMenuID() {
		return menuID;
	}
	public void setMenuID(int menuID) {
		this.menuID = menuID;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public int getMenuOrder() {
		return menuOrder;
	}
	public void setMenuOrder(int menuOrder) {
		this.menuOrder = menuOrder;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getMenuLink() {
		return menuLink;
	}
	public void setMenuLink(String menuLink) {
		this.menuLink = menuLink;
	}
	/**
	 * 添加
	 * @return
	 */
	public String add(){
		Menu menu=new Menu();
		menu.setCreateTime(new Date());
		menu.setMenuLink(menuLink);
		menu.setMenuName(menuName);
		menu.setMenuOrder(menuOrder);
		if(menuService.addMenu(menu)){
			this.addActionMessage("添加成功！");
		}else{
			this.addActionMessage("添加失败！");
			
		}
		return "add_s";
	}
	/**
	 * 修改
	 * @return
	 */
	public String update(){
		Menu menu=new Menu();
		menu.setMenuID(menuID);
		menu.setCreateTime(new Date());
		menu.setMenuLink(menuLink);
		menu.setMenuName(menuName);
		menu.setMenuOrder(menuOrder);
		if(menuService.updateMenu(menu)){
			this.addActionMessage("修改成功！");
		}else{
			this.addActionMessage("修改成功！");
		}
		return "update_s";
	}
	/**
	 * 删除
	 * @return
	 */
	public String delete(){
		if(menuService.deleteMenu(menuID)){
			this.addActionMessage("删除成功！");
		}else{
			this.addActionMessage("删除失败！");
		}
		return "delete_s";
	}
	/**
	 * 查询所有
	 * @return
	 */
	public String findAll(){
		menulist=menuService.queryAllMenu();
		return "findAll_s";
	}
	/**
	 * ajax查询
	 * @return
	 */
	public String findAjax(){
		HttpServletRequest request=ServletActionContext.getRequest();
		int menuID=Integer.parseInt(request.getParameter("menuID"));
		Menu menu=menuService.queryByMenuID(menuID);
		menuName=menu.getMenuName();
		menuLink=menu.getMenuLink();
		menuOrder=menu.getMenuOrder();
		String ajax_message="{'menuName':'"+menuName+"','menuLink':'"+menuLink+"','menuOrder':'"+menuOrder+"'}";
		HttpServletResponse response=ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(ajax_message);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
}

package com.qllt.action;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.qllt.po.Image;
import com.qllt.service.ImageService;
import com.qllt.util.CommonMethod;
import com.qllt.util.Page;
import com.qllt.util.Result;

public class ImageAction extends ActionSupport {
	private int imageID;
	private File imageFile; //用来封装上传文件
	private String imageFileContentType;
	private String imageFileFileName;
	private String imageDescription;
	private String imageLink;
	private int imageType;
	private List<Image> imageList;
	private ImageService imageService;
	private ByteArrayInputStream imageStream;
	private int imageOrder;
	
	public int getImageOrder() {
		return imageOrder;
	}
	public void setImageOrder(int imageOrder) {
		this.imageOrder = imageOrder;
	}
	public File getImageFile() {
		return imageFile;
	}
	public void setImageFile(File imageFile) {
		this.imageFile = imageFile;
	}
	public String getImageFileContentType() {
		return imageFileContentType;
	}
	public void setImageFileContentType(String imageFileContentType) {
		this.imageFileContentType = imageFileContentType;
	}
	public String getImageFileFileName() {
		return imageFileFileName;
	}
	public void setImageFileFileName(String imageFileFileName) {
		this.imageFileFileName = imageFileFileName;
	}
	public String getImageDescription() {
		return imageDescription;
	}
	public void setImageDescription(String imageDescription) {
		this.imageDescription = imageDescription;
	}
	public String getImageLink() {
		return imageLink;
	}
	public void setImageLink(String imageLink) {
		this.imageLink = imageLink;
	}
	public int getImageType() {
		return imageType;
	}
	public void setImageType(int imageType) {
		this.imageType = imageType;
	}
	public List<Image> getImageList() {
		return imageList;
	}
	public void setImageList(List<Image> imageList) {
		this.imageList = imageList;
	}
	public void setImageService(ImageService imageService) {
		this.imageService = imageService;
	}
	
	public int getImageID() {
		return imageID;
	}
	public void setImageID(int imageID) {
		this.imageID = imageID;
	}
	public ByteArrayInputStream getImageStream() {
		return imageStream;
	}
	public void setImageStream(ByteArrayInputStream imageStream) {
		this.imageStream = imageStream;
	}
	/**
	 * 添加图片
	 * @return
	 */
	public String add(){
		Image image=new Image();
		image.setImageDescription(imageDescription);
		image.setImageLink(imageLink);
		image.setImageType(imageType);
		image.setImageOrder(imageOrder);
		File file=getImageFile();
		if(file!=null&&file.exists()){
			image.setImageBinary(CommonMethod.getBytesFromFile(file));
			imageService.addImage(image);
			this.addActionMessage("图片添加成功！");
		}else{
			this.addActionMessage("图片添加失败！");
		}
		return "add_s";
	}
	/**
	 * 分类查找所有图片
	 * @return
	 */
	public String findAll(){
		Page zpage=new Page();
		zpage.setCurrentPage(1);
		zpage.setEveryPage(10);	
		Result result=imageService.findAllImage(zpage, 1);
		//page=result.getPage();
		imageList=result.getList();
		return "findAll_s";
	}
	/**
	 * 显示图片,显示为图片流
	 * @return
	 */
	public String show(){
		Image image=imageService.findImageByID(imageID);
		imageStream=new ByteArrayInputStream(image.getImageBinary());
		return "show_stream";
	}
	/**
	 * 查看图片详细信息
	 * @return
	 */
	public String find(){
		Image image=imageService.findImageByID(imageID);
		imageFileFileName=image.getImageName();
		imageOrder=image.getImageOrder();
		imageType=image.getImageType();
		imageLink=image.getImageLink();
		imageDescription=image.getImageDescription();
		imageStream=new ByteArrayInputStream(image.getImageBinary());
		return "find_s";
	}
	/**
	 * ajax查看
	 * @return
	 */
	public String findAjax(){
		//获取客户端
		HttpServletRequest request=ServletActionContext.getRequest();
		int imageID=Integer.parseInt(request.getParameter("imageID"));
		
		Image image=imageService.findImageByID(imageID);
		imageFileFileName=image.getImageName();
		imageOrder=image.getImageOrder();
		imageType=image.getImageType();
		imageLink=image.getImageLink();
		imageDescription=image.getImageDescription();
		try {//处理空指针异常
			imageStream=new ByteArrayInputStream(image.getImageBinary());
		} catch (NullPointerException e) {
		}
		
		String ajax_message="{'imageOrder':'"+imageOrder+"','imageType':'"+imageType+"','imageLink':'"+imageLink+"','imageDescription':'"+imageDescription+"',}";
		//ajax返回客户端
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(ajax_message);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
	/**
	 * 更新
	 * @return
	 */
	public String update(){
		Image image=new Image();
		image.setImageID(imageID);
		image.setImageName(imageFileFileName);
		image.setImageOrder(imageOrder);
		image.setImageDescription(imageDescription);
		image.setImageLink(imageLink);
		image.setImageType(imageType);
		File file=getImageFile();
		if(file!=null&&file.exists()){//上传了图片
			image.setImageBinary(CommonMethod.getBytesFromFile(file));
			imageService.updateImage(image);
			this.addActionMessage("修改成功！");
		}else if(file==null){//没上传图片
			image.setImageBinary(imageService.findImageByID(imageID).getImageBinary());
			imageService.updateImage(image);
			this.addActionMessage("修改成功！");
		}else{
			this.addActionMessage("修改失败！");
			
		}
		
		return "update_s";	
	}
	public String delete(){
		if(imageService.deleteImage(imageID)){
			this.addActionMessage("删除成功！");
		}else{
			this.addActionMessage("删除失败！");
		}
		return "delete_s";
	}
}

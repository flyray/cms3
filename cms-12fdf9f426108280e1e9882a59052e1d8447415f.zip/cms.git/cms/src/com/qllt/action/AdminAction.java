package com.qllt.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.qllt.po.Admin;
import com.qllt.po.AdminGroup;
import com.qllt.service.AdminGroupService;
import com.qllt.service.AdminService;
import com.qllt.util.MD5;

public class AdminAction extends ActionSupport {
	private int adminID;
	private String adminName;
	private String adminPassword;
	private List<Admin> list;
	private String ajax_message;
	private int agid;
	private List<AdminGroup> aglist;
	private AdminGroup adminGroup;
	private String phoneNum;
	private String email;
	private String sex;
	private String remarks;
	private String IDcard;
	private String originaladminPassword;
	private AdminGroupService adminGroupService;
	private AdminService adminService;
	
	
	public void setAdminGroupService(AdminGroupService adminGroupService) {
		this.adminGroupService = adminGroupService;
	}

	public List<AdminGroup> getAglist() {
		return aglist;
	}

	public void setAglist(List<AdminGroup> aglist) {
		this.aglist = aglist;
	}

	public AdminGroup getAdminGroup() {
		return adminGroup;
	}

	public void setAdminGroup(AdminGroup adminGroup) {
		this.adminGroup = adminGroup;
	}

	public String getAjax_message() {
		return ajax_message;
	}
	
	public int getAgid() {
		return agid;
	}


	public void setAgid(int agid) {
		this.agid = agid;
	}


	public void setAjax_message(String ajaxMessage) {
		ajax_message = ajaxMessage;
	}
	public int getAdminID() {
		return adminID;
	}
	public void setAdminID(int adminID) {
		this.adminID = adminID;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {  
		this.adminPassword = adminPassword;
	}
	public List<Admin> getList() {
		return list;
	}
	public void setList(List<Admin> list) {
		this.list = list;
	}
	
	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getIDcard() {
		return IDcard;
	}

	public void setIDcard(String iDcard) {
		IDcard = iDcard;
	}

	public String getOriginaladminPassword() {
		return originaladminPassword;
	}

	public void setOriginaladminPassword(String originaladminPassword) {
		this.originaladminPassword = originaladminPassword;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}
	public String goin(){
		
		return "goin_s";
	}
	/**
	 * 添加管理员
	 * @return
	 */
	public String add(){
		Admin admin=new Admin();
		admin.setAdminName(adminName);
		MD5 md5=new MD5();//md5加密,md5加密是不可逆的
		String md5_p=md5.getMD5ofStr(adminPassword);
		admin.setAdminPassword(md5_p);
		AdminGroup adminGroup=new AdminGroup();
		adminGroup.setGid(agid);
		admin.setAdminGroup(adminGroup);
		admin.setEmail(email);
		admin.setPhoneNum(phoneNum);
		admin.setRemarks(remarks);
		admin.setSex(sex);
		admin.setIDcard(IDcard);
		if(adminService.addAdmin(admin)){
			this.addActionMessage("添加成功！");
		}else{
			this.addActionMessage("添加失败！");
		}
		return "add_s";
	}
	/**
	 * ajax查找
	 * @return
	 */
	public String queryByAdminName(){
		Admin admin = adminService.queryAdminByAdminName(adminName);
		List<Admin> l = new ArrayList<Admin>();
		l.add(admin);
		this.setList(l);
		aglist=adminGroupService.findAll();	
		return "queryByAdminName_s";
	}
	public String find(){
		HttpServletRequest request=ServletActionContext.getRequest();
		int adminID=Integer.parseInt(request.getParameter("adminID"));
		Admin admin=adminService.queryAdminByID(adminID);
		adminName=admin.getAdminName();
		String password = admin.getAdminPassword();
		int agid = admin.getAdminGroup().getGid();
		//adminPassword
		String agName=admin.getAdminGroup().getAgName();
		String phoneNum=admin.getPhoneNum();
		String email=admin.getEmail();
		String sex=admin.getSex();
		String remarks = admin.getRemarks();
		String IDcard = admin.getIDcard();
		String ajax_message;
		ajax_message="{'adminName':'"+adminName+"','agid':'"+agid+"','password':'"+password+"','agName':'"+agName+"','phoneNum':'"+phoneNum+"','email':'"+email+"','sex':'"+sex+"','remarks':'"+remarks+"','IDcard':'"+IDcard+"'}";
		//ajax返回客户端
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(ajax_message);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
	public String update(){
		Admin admin=new Admin();
		admin.setAdminID(adminID);
		admin.setAdminName(adminName);
        admin.setAdminPassword(adminPassword);//此处的密码是之前从数据库取出的，不需要再次进行加密
		AdminGroup adminGroup=new AdminGroup();
		adminGroup.setGid(agid);
		admin.setAdminGroup(adminGroup);
		admin.setEmail(email);
		admin.setPhoneNum(phoneNum);
		admin.setRemarks(remarks);
		admin.setSex(sex);
		admin.setIDcard(IDcard);
		adminService.updateAdmin(admin);
		return "update_s";
	}
	public String delete(){
		Admin admin = adminService.queryAdminByID(adminID);
		AdminGroup adminGroup = admin.getAdminGroup();
		if(adminGroup.getAgName().equals("admin")){
			this.addActionMessage("不可以删除管理员！");
		}else{
			if(adminService.deleteAdmin(adminID)){
				this.addActionMessage("删除成功！");
			}else{
				this.addActionMessage("删除失败！");
			}
		}
		return "delete_s";
	}
	public String findAll(){
		list=adminService.queryAllAdmin();
		aglist=adminGroupService.findAll();
		return "findAll_s";
	}
	
	public String login(){
		Admin admin = new Admin();
		if(adminName==null||adminName.equals("")){
			return "input";
		}else{
			admin.setAdminName(adminName.trim());
		}
		MD5 md5=new MD5();//由于md5加密不可逆,所以直接修改覆盖就可以
		admin.setAdminPassword(md5.getMD5ofStr(adminPassword.trim()));
		if(adminService.isLogin(admin)) {
			Map session = ActionContext.getContext().getSession();
			session.put("adminName", adminName);
			
			this.addActionMessage("登录成功！");
			adminGroup = adminService.queryAdminByAdminName(adminName).getAdminGroup();
			session.put("adminGroup",adminGroup);
			return "login_s";
		} else {
			this.addActionMessage("用户名或密码错误！");
			return "input";
		}
	}
	public String logout(){
		Map session=ActionContext.getContext().getSession();
		session.remove("adminName");
		this.addActionMessage("注销成功！");
		return "logout_s";
	}
	/*
	 * 查看个人信息
	 */
	public String checkSelf(){
		ActionContext act = ActionContext.getContext();
		Map session = act.getSession();
		String adminname = (String)session.get("adminName");
		Admin admin = adminService.queryAdminByAdminName(adminname);
		adminID = admin.getAdminID();
		adminName=admin.getAdminName();
		adminGroup = admin.getAdminGroup();
		phoneNum = admin.getPhoneNum();
		email = admin.getEmail();
		sex = admin.getSex();
		remarks = admin.getRemarks();
		IDcard = admin.getIDcard();
		return "checkSelf_s";
	}
	public String changePSWFind(){
		ActionContext act = ActionContext.getContext();
		Map session = act.getSession();
		adminName = (String)session.get("adminName");
		Admin admin = adminService.queryAdminByAdminName(adminName);
		adminID = admin.getAdminID();
		return "changePSWFind_s";
	}
	/*
	 * 修改个人密码
	 */
	public String changePSW(){
		//先获得数据库中存放的信息，看看输入的密码是否正确
		Admin admin = adminService.queryAdminByID(adminID);
		String orginalPassword = admin.getAdminPassword();
		MD5 md51=new MD5();
		String originalpswinput = md51.getMD5ofStr(originaladminPassword);//输入的密码进行MD5转化
		if(!orginalPassword.equals(originalpswinput)){
			this.addActionMessage("原密码输入错误");
			return "changePSW_s";
		}
		//密码正确，进行密码修改
		admin.setAdminName(adminName);
		MD5 md5=new MD5();//由于md5加密不可逆,所以直接修改覆盖就可以
		String md5_p=md5.getMD5ofStr(adminPassword);
		admin.setAdminPassword(md5_p);
		adminService.updateAdmin(admin);
		this.addActionMessage("修改成功");
		return "changePSW_s";
	}
}

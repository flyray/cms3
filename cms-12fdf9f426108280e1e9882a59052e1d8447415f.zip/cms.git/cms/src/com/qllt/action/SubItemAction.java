package com.qllt.action;

import java.io.IOException;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.qllt.po.Item;
import com.qllt.po.SubItem;
import com.qllt.service.ItemService;
import com.qllt.service.SubItemService;

public class SubItemAction extends ActionSupport {
	private int subItemID;
	private String subItemName;
	private int itemID;
	private int order;
	private String subItemLink;
	private List<SubItem> subItems;
	private List<Item> items;
	private Map<Item,List> map;
	private SubItemService subItemService;
	private ItemService itemService;
	
	
	public Map<Item, List> getMap() {
		return map;
	}
	public void setMap(Map<Item, List> map) {
		this.map = map;
	}
	
	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
	public void setItemService(ItemService itemService) {
		this.itemService = itemService;
	}
	public List<SubItem> getSubItems() {
		return subItems;
	}
	public void setSubItems(List<SubItem> subItems) {
		this.subItems = subItems;
	}
	public int getSubItemID() {
		return subItemID;
	}
	public void setSubItemID(int subItemID) {
		this.subItemID = subItemID;
	}
	public String getSubItemName() {
		return subItemName;
	}
	public void setSubItemName(String subItemName) {
		this.subItemName = subItemName;
	}
	public int getItemID() {
		return itemID;
	}
	public void setItemID(int itemID) {
		this.itemID = itemID;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public void setSubItemService(SubItemService subItemService) {
		this.subItemService = subItemService;
	}
	
	public String getSubItemLink() {
		return subItemLink;
	}
	public void setSubItemLink(String subItemLink) {
		this.subItemLink = subItemLink;
	}
	public String add(){
		SubItem subItem=new SubItem();
		subItem.setSubItemName(subItemName);
		subItem.setOrder(order);
		Item item=new Item();
		item.setItemID(itemID);
		subItem.setItem(item);
		subItem.setCreateTime(new Date());
		if(subItemService.addSubItem(subItem)){
			this.addActionMessage("添加成功！");
		}else{
			this.addActionMessage("添加失败！");
		}
		return "add_s";
	}
	public String findAjax(){
		HttpServletRequest request=ServletActionContext.getRequest();
		int subItemID=Integer.parseInt(request.getParameter("subItemID"));
		SubItem subItem=subItemService.findSubItemByID(subItemID);
		subItemName=subItem.getSubItemName();
		order=subItem.getOrder();
		itemID=subItem.getItem().getItemID();
		
		String ajax_message;
		ajax_message="{'subItemName':'"+subItemName+"','order':'"+order+"','subItemLink':'"+subItemLink+"','itemID':'"+itemID+"'}";
		//ajax返回客户端
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(ajax_message);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
	public String update(){
		SubItem subItem=new SubItem();
		subItem.setSubItemID(subItemID);
		subItem.setSubItemName(subItemName);
		subItem.setOrder(order);
		Item item=new Item();
		item.setItemID(itemID);
		subItem.setItem(item);
		subItem.setCreateTime(new Date());
		if(subItemService.updateSubItem(subItem)){
			this.addActionMessage("修改成功！");
		}else{
			this.addActionMessage("修改失败！");
		}
		return "update_s";
	}
	public String delete(){
		if(subItemService.deleteSubItemd(subItemID)){
			this.addActionMessage("删除成功！");
		}else{
			this.addActionMessage("删除失败！");
		}
		return "delete_s";
	}
	public String findAll(){
		items=itemService.findAllItem();
		map=new LinkedHashMap<Item,List>();
		for(Item item:items){
			subItems=subItemService.findAllSubItem(item.getItemID());
			map.put(item, subItems);
		}
		return "findAll_s";
	}
	public String findAllAjax(){
		subItems=subItemService.findAllSubItem(itemID);
		
		JSONArray jsonArray2 = JSONArray.fromObject(subItems);
		//ajax返回客户端
		jsonArray2.toString();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(jsonArray2.toString());
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
	//ajax查询所有的子栏目
	public void findAllSubItems(){
		subItems=subItemService.findAllSubItem();
		System.out.println(subItems.size());
		JSONArray jsonArray2 = JSONArray.fromObject(subItems);
		//ajax返回客户端
		jsonArray2.toString();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(jsonArray2.toString());
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
}

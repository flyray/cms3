package com.qllt.action;

import java.util.List;

import com.opensymphony.xwork2.ActionSupport;
import com.qllt.po.News;
import com.qllt.service.NewsService;
import com.qllt.util.Page;
import com.qllt.util.Result;

public class SearchAction extends ActionSupport{
	private String tip;//查询条件
	private List<News> newsList;//查询到的新闻列表
	private int currentPage=1;
	private Page page;
	private NewsService newsService;
	
	private News news;
	
	
	public News getNews() {
		return news;
	}

	public void setNews(News news) {
		this.news = news;
	}

	public NewsService getNewsService() {
		return newsService;
	}

	public String getTip() {
		return tip;
	}

	public void setTip(String tip) {
		this.tip = tip;
	}
	
	public List<News> getNewsList() {
		return newsList;
	}

	public void setNewsList(List<News> newsList) {
		this.newsList = newsList;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}

	public String search(){
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(20);
		newsList = newsService.searchNews(tip,zpage);
		page = zpage;
		news=newsList.get(0);
		return "success";
	}
}
	
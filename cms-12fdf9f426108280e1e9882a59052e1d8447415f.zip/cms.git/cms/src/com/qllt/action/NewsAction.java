package com.qllt.action;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.write.DateTime;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.qllt.po.Admin;
import com.qllt.po.Item;
import com.qllt.po.News;
import com.qllt.po.RecruitRoom;
import com.qllt.po.RecruitSchool;
import com.qllt.po.SubItem;
import com.qllt.service.ItemService;
import com.qllt.service.NewsService;
import com.qllt.service.RecruitRoomService;
import com.qllt.service.RecruitSchoolService;
import com.qllt.service.SubItemService;
import com.qllt.util.CommonMethod;
import com.qllt.util.FreeMarker;
import com.qllt.util.Page;
import com.qllt.util.Result;

public class NewsAction extends ActionSupport {
	private int newsID;
	private String title;
	private String content;
	private Date createtime;
	private int settop; 	//1置顶，0取消置顶
	private Date settoptime;
	private String link;	//用于直接链接
	private int islink;	//是否是直接链接
	private String source;	//来源
	private String author;	//作者
	private String editorName;	//编辑人
	private String color;	//标题颜色
	private int subItemID;	//所属栏目
	private boolean isrecruit;	//是否是招聘类型新闻
	
//招聘时间拼写错误，recruitTime，但是不改了。可以用，以后注意就行
	private Date recrutTime;	//招聘时间
	private Date recruitTimeEnd;
	private int recruitAddress;	//招聘地点
	private int positionNum;	//招聘岗位数
	private List<News> newslist;
	private String ajax_message;
	private int currentPage=1;
	private Page page;
	private int updatetime=0;
	private String keywords;
	private int s_item;
	private int itemID;
	private int hasread;
	private int bold;
	private NewsService newsService;
	private ItemService itemService;
	private SubItemService subItemService;
	private String translateInfo;
	private int everyPage;
	//做统计新加的属性
	private String start_time;
	private String end_time;
	private int jobNumber;
	//确定要进行分组的年份
	private String divide_year;
	//news_number_list用来在jsp之间传递查询到的数据
	private List<Integer> news_number_list=new ArrayList<Integer>();
	private List<Integer> news_number_list_byauthor=new ArrayList<Integer>();
	//divide_list用来传递查询到的关于分组的数据，有星期与新闻数目，岗位数目
	private List<String> divide_week_list=new ArrayList<String>();
	private List<Integer> divide_number_list=new ArrayList<Integer>();
	private List<String> divide_position_list=new ArrayList<String>();
	
	private RecruitSchoolService recruitSchoolService;//根据招聘校区编号查询招聘校区
	private RecruitRoomService recruitRoomService;//根据招聘教室ID查询招聘教室
	private String recruitSchoolName;//接收查询到的招聘校区名字
	private String recruitRoomName;//接收查询到的招聘教室的名字
	
	//新闻搜索需要使用的开始时间和结束时间
	private String starttime;
	private String endtime;
	
	
	public Date getRecruitTimeEnd() {
		return recruitTimeEnd;
	}
	public void setRecruitTimeEnd(Date recruitTimeEnd) {
		this.recruitTimeEnd = recruitTimeEnd;
	}
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public RecruitSchoolService getRecruitSchoolService() {
		return recruitSchoolService;
	}
	public void setRecruitSchoolService(RecruitSchoolService recruitSchoolService) {
		this.recruitSchoolService = recruitSchoolService;
	}
	public RecruitRoomService getRecruitRoomService() {
		return recruitRoomService;
	}
	public void setRecruitRoomService(RecruitRoomService recruitRoomService) {
		this.recruitRoomService = recruitRoomService;
	}
	public String getRecruitSchoolName() {
		return recruitSchoolName;
	}
	public void setRecruitSchoolName(String recruitSchoolName) {
		this.recruitSchoolName = recruitSchoolName;
	}
	public String getRecruitRoomName() {
		return recruitRoomName;
	}
	public void setRecruitRoomName(String recruitRoomName) {
		this.recruitRoomName = recruitRoomName;
	}
	public int getEveryPage() {
		return everyPage;
	}
	public void setEveryPage(int everyPage) {
		this.everyPage = everyPage;
	}
	public int getItemID() {
		return itemID;
	}
	public void setItemID(int itemID) {
		this.itemID = itemID;
	}
	public void setItemService(ItemService itemService) {
		this.itemService = itemService;
	}
	public void setSubItemService(SubItemService subItemService) {
		this.subItemService = subItemService;
	}
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public List<Integer> getNews_number_list_byauthor() {
		return news_number_list_byauthor;
	}
	public void setNews_number_list_byauthor(List<Integer> news_number_list_byauthor) {
		this.news_number_list_byauthor = news_number_list_byauthor;
	}
	public List<String> getDivide_position_list() {
		return divide_position_list;
	}
	public void setDivide_position_list(List<String> divide_position_list) {
		this.divide_position_list = divide_position_list;
	}
	public NewsService getNewsService() {
		return newsService;
	}
	public String getTranslateInfo() {
		return translateInfo;
	}
	public String getEnd_time() {
		return end_time;
	}
	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}
	public int getJobNumber() {
		return jobNumber;
	}
	public void setJobNumber(int jobNumber) {
		this.jobNumber = jobNumber;
	}
	public String getDivide_year() {
		return divide_year;
	}
	public void setDivide_year(String divide_year) {
		this.divide_year = divide_year;
	}
	public List<Integer> getNews_number_list() {
		return news_number_list;
	}
	public void setNews_number_list(List<Integer> news_number_list) {
		this.news_number_list = news_number_list;
	}
	public List<String> getDivide_week_list() {
		return divide_week_list;
	}
	public void setDivide_week_list(List<String> divide_week_list) {
		this.divide_week_list = divide_week_list;
	}
	public List<Integer> getDivide_number_list() {
		return divide_number_list;
	}
	public void setDivide_number_list(List<Integer> divide_number_list) {
		this.divide_number_list = divide_number_list;
	}
	
	public int getBold() {
		return bold;
	}
	public void setBold(int bold) {
		this.bold = bold;
	}
	public int getHasread() {
		return hasread;
	}
	public void setHasread(int hasread) {
		this.hasread = hasread;
	}
	public int getNewsID() {
		return newsID;
	}
	public void setNewsID(int newsID) {
		this.newsID = newsID;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public int getSettop() {
		return settop;
	}
	public void setSettop(int settop) {
		this.settop = settop;
	}
	public Date getSettoptime() {
		return settoptime;
	}
	public void setSettoptime(Date settoptime) {
		this.settoptime = settoptime;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	
	public int getIslink() {
		return islink;
	}
	public void setIslink(int islink) {
		this.islink = islink;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public String getEditorName() {
		return editorName;
	}
	public void setEditorName(String editorName) {
		this.editorName = editorName;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getSubItemID() {
		return subItemID;
	}
	public void setSubItemID(int subItemID) {
		this.subItemID = subItemID;
	}
	public boolean isIsrecruit() {
		return isrecruit;
	}
	public void setIsrecruit(boolean isrecruit) {
		this.isrecruit = isrecruit;
	}
	public Date getRecrutTime() {
		return recrutTime;
	}
	public void setRecrutTime(Date recrutTime) {
		this.recrutTime = recrutTime;
	}
	public int getRecruitAddress() {
		return recruitAddress;
	}
	public void setRecruitAddress(int recruitAddress) {
		this.recruitAddress = recruitAddress;
	}
	public int getPositionNum() {
		return positionNum;
	}
	public void setPositionNum(int positionNum) {
		this.positionNum = positionNum;
	}
	public List<News> getNewslist() {
		return newslist;
	}
	public void setNewslist(List<News> newslist) {
		this.newslist = newslist;
	}
	public String getAjax_message() {
		return ajax_message;
	}
	public void setAjax_message(String ajax_message) {
		this.ajax_message = ajax_message;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
	public int getUpdatetime() {
		return updatetime;
	}
	public void setUpdatetime(int updatetime) {
		this.updatetime = updatetime;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public int getS_item() {
		return s_item;
	}
	public void setS_item(int s_item) {
		this.s_item = s_item;
	}
	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}
	
	
	/**
	 * 某段时间之内所发稿件数目及其中所含的岗位数目
	 */
	public String checkNewsAndPosition(){
		newsService.checkNewsAndPosition(start_time, end_time, news_number_list,news_number_list_byauthor);
		return "checkNewsAndPosition_s";
	}
	
	/**
	 * 某段时间之内某作者所发稿件数目及其中所含的岗位数目
	 */
	public String checkNewsAndPositionByAuthor(){
		newsService.checkNewsAndPositionByAuthor(author,start_time, end_time, news_number_list_byauthor,news_number_list);	
		return "checkNewsAndPositionByAuthor_s";
	}
	/**
	 * 按周统计数据
	 */
	public String divideByWeek(){
		newsService.divideByWeek(divide_year, divide_week_list, divide_number_list, divide_position_list);
		return "divideByWeek_s";
	}
	
	
	
	/**
	 * 添加新闻
	 * @return 
	 */
	public String add(){
		News news=new News();
		Admin admin=new Admin();
		admin.setAdminName(editorName);
		news.setEditor(admin);
		news.setTitle(title);
		news.setContent(content);
		Date date=new Date();
		news.setCreatetime(date);
		SubItem subItem=new SubItem();
		subItem.setSubItemID(subItemID);
		news.setSubItem(subItem);
		news.setSettop(0);//不置顶，单独写置顶的方法
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, 0);
		news.setSettoptime(new Date(calendar.get(Calendar.YEAR)));
		news.setAuthor(author);
		news.setColor(color);
		if(islink==0){
			news.setLink("   ");
		}else{
			news.setLink(link);
		}
		news.setIslink(islink);
		news.setSource(source); 
		news.setIsrecruit(isrecruit);
		news.setRecrutTime(recrutTime);
		news.setRecruitTimeEnd(recruitTimeEnd);
		news.setRecruitAddress(recruitAddress);
		news.setPositionNum(positionNum);
		news.setHasread(hasread);
		news.setBold(bold);
		if(newsService.addNews(news)){
			/*静态化*/
			News news_temp=newsService.findBydate(date);
			Item item_temp=itemService.findItemByItemID(s_item);
			SubItem subItem_temp=subItemService.findSubItemByID(subItemID);
			List<SubItem> subItemList = subItemService.findAllSubItem(item_temp.getItemID());
			int news_id=news_temp.getNewsID();
			
			//查询招聘教室信息
			recruitAddress=news_temp.getRecruitAddress();
			RecruitRoom recruitRoom_temp=recruitRoomService.findRecruitRoomByID(recruitAddress);
			recruitRoomName=recruitRoom_temp.getRecruitRoomName();
			
			//查询招聘校区信息
			int recruitSchoolNum=recruitRoom_temp.getRecruitRoomBelong();
			RecruitSchool recruitSchool_temp=recruitSchoolService.findRecruitSchoolByNum(recruitSchoolNum);
			recruitSchoolName=recruitSchool_temp.getRecruitSchoolName();
			
			//将招聘校区信息放进news对象中，然后一起传进ftl文件中
			news.setRecruitSchoolName(recruitSchoolName);
			//将招聘教室信息放进news对象中，然后一起传进ftl文件中
			news.setRecruitRoomName(recruitRoomName);
			
			Map<String,Object> root=new HashMap<String, Object>();
			root.put("news",news);
			root.put("item",item_temp);
			root.put("subItem",subItem_temp);
			root.put("subItemList",subItemList);
			//将招聘教室及招聘校区put进root
			root.put("recruitSchoolName",recruitSchoolName);
			root.put("recruitRoomName",recruitRoomName);
			root.put("basePath",CommonMethod.getBasePath());
			String rootPath="html/news/";
			String dirPath=new SimpleDateFormat("yyyy/MM/dd").format(date);
			/*创建目录*/
			CommonMethod.dirMake(rootPath, dirPath);
			String ss[]=dirPath.split("/");//ss[0]为yyyy,ss[1]为MMdd
			String templatesPath="/";
			
			String itemname=item_temp.getItemName();
			String templateFile="WEB-INF/templates/newsDetail2.ftl";
			
			if(itemname.equals("专题")){
				templateFile="WEB-INF/templates/zhuanti.ftl";
			}
			
			String htmlFile="html/news/"+ss[0]+"/"+ss[1]+"/"+ss[2]+"/news-"+news_id+".html";
			FreeMarker.analysisTemplate(templatesPath,templateFile,htmlFile,root);
			this.addActionMessage("发表成功！");
			translateInfo="发表成功！";
		}else{
			this.addActionMessage("发表失败！");
			this.translateInfo="发表失败！！";
		}
		return "add_s";
	}
	/**
	 * Ajax方式查询详细新闻
	 * @return
	 */
	public String findAjax(){
		HttpServletRequest request=ServletActionContext.getRequest();
		int newsID=Integer.parseInt(request.getParameter("newsID"));
		News news=newsService.findNewsByID(newsID);
		title=news.getTitle();
		content=news.getContent();
		createtime=news.getCreatetime();
		settop=news.getSettop();
		settoptime=news.getSettoptime();
		link=news.getLink();
		islink=news.getIslink();
		source=news.getSource();
		author=news.getAuthor();
		editorName=news.getEditor().getAdminName();
		color=news.getColor();
		subItemID=news.getSubItem().getSubItemID();
		isrecruit=news.isIsrecruit();
		recrutTime=news.getRecrutTime();
		recruitTimeEnd=news.getRecruitTimeEnd();
		recruitAddress=news.getRecruitAddress();
		positionNum=news.getPositionNum();
		hasread=news.getHasread();
		bold=news.getBold();
		ajax_message="{'title':'"+title+"','content':'"+content+"','createtime':'"+createtime+"','settop':'"+settop+"','settoptime':'"+settoptime+"','link':'"+link+"','islink':'"+islink+"','editorName':'"+editorName+"','color':'"+color+"','subItemID':'"+subItemID+"','isrecruit':'"+isrecruit+"','recrutTime':'"+recrutTime+"','recruitTimeEnd':'"+recruitTimeEnd+"','recruitAddress':'"+recruitAddress+"','positionNum':'"+positionNum+"','hasread':'"+hasread+"'}";
		//ajax返回客户端
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(ajax_message);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
	/**
	 * Ajax方式查询详细新闻
	 * @return
	 */
	public String find(){
		News news=newsService.findNewsByID(newsID);
		title=news.getTitle();
		content=news.getContent();
		createtime=news.getCreatetime();
		settop=news.getSettop();
		settoptime=news.getSettoptime();
		link=news.getLink();
		islink=news.getIslink();
		source=news.getSource();
		author=news.getAuthor();
		editorName=news.getEditor().getAdminName();
		color=news.getColor();
		subItemID=news.getSubItem().getSubItemID();
		isrecruit=news.isIsrecruit();
		recrutTime=news.getRecrutTime();
		recruitTimeEnd=news.getRecruitTimeEnd();
		recruitAddress=news.getRecruitAddress();
		positionNum=news.getPositionNum();
		hasread=news.getHasread();
		bold=news.getBold();
		return "find_s";
	}
	/**
	 * 删除新闻
	 * @return
	 */
	public String delete(){
		//获得新闻，得到其地址
		News newd = newsService.findNewsByID(newsID);
		Date newsDate = newd.getCreatetime();
		String dirPath=new SimpleDateFormat("yyyy/MM/dd").format(newsDate);
		String filepath=ServletActionContext.getServletContext().getRealPath("html/news/"+dirPath+"/news-"+newsID+".html");
		//如果删除，将静态化文件也删除
		if(newsService.deleteNewsByID(newsID)){
			//filepath=ServletActionContext.getServletContext().getRealPath("html/news/news-"+newsID+".html");
			File file=new File(filepath);
			if(file.exists()){
				file.delete();
			}
			this.addActionMessage("删除成功！");
		}else{
			this.addActionMessage("删除失败！");
		}
		return "delete_s";
	}
	/**
	 * 修改新闻
	 * @return
	 */
	public String update(){
		News news=new News();
		Admin admin=new Admin();
		news.setNewsID(newsID);//修改提供id
		admin.setAdminName(editorName);
		news.setEditor(admin);
		news.setTitle(title);
		news.setContent(content);
		SubItem subItem=new SubItem();
		subItem.setSubItemID(subItemID);
		news.setSubItem(subItem);
		news.setSettop(settop);//不置顶，单独写置顶的方法
		news.setSettoptime(settoptime);
		news.setAuthor(author);
		news.setColor(color);
		news.setIslink(islink);
		news.setLink(link);
		System.out.println(source+"：来源");
		news.setSource(source);
		news.setIsrecruit(isrecruit);
		news.setRecrutTime(recrutTime);
		news.setRecruitTimeEnd(recruitTimeEnd);
		news.setRecruitAddress(recruitAddress);
		news.setPositionNum(positionNum);
		news.setHasread(hasread);
		news.setBold(bold);
		Date date_temp=new Date();
		String dirPath=null;
//		if(updatetime==1){//修改时间
//			news.setCreatetime(date_temp);
//			dirPath=new SimpleDateFormat("yyyy/MM/dd").format(date_temp);
//		}else{
		//更新时不修改时间
			news.setCreatetime(createtime);
			dirPath=new SimpleDateFormat("yyyy/MM/dd").format(createtime);
//		}
		currentPage=getCurrentPage();//修改后跳转到当前页
		if(newsService.updateNews(news)){
			SubItem subItem_temp=subItemService.findSubItemByID(subItemID);
			int itemID_temp=subItem_temp.getItem().getItemID();
			Item item_temp=itemService.findItemByItemID(itemID_temp);
			List<SubItem> subItemList = subItemService.findAllSubItem(itemID_temp);
			
			//查询招聘教室信息
			RecruitRoom recruitRoom_temp=recruitRoomService.findRecruitRoomByID(recruitAddress);
			recruitRoomName=recruitRoom_temp.getRecruitRoomName();
			//查询招聘校区信息
			int recruitSchoolNum=recruitRoom_temp.getRecruitRoomBelong();
			RecruitSchool recruitSchool_temp=recruitSchoolService.findRecruitSchoolByNum(recruitSchoolNum);
			recruitSchoolName=recruitSchool_temp.getRecruitSchoolName();
			
			//将招聘校区信息放进news对象中，然后一起传进ftl文件中
			news.setRecruitSchoolName(recruitSchoolName);
			//将招聘教室信息放进news对象中，然后一起传进ftl文件中
			news.setRecruitRoomName(recruitRoomName);
			
			
			Map<String,Object> root=new HashMap<String, Object>();
			root.put("news",news);
			root.put("item",item_temp);
			root.put("subItem",subItem_temp);
			root.put("subItemList",subItemList);
			//将招聘教室及招聘校区put进root
			root.put("recruitSchoolName",recruitSchoolName);
			root.put("recruitRoomName",recruitRoomName);
			root.put("basePath",CommonMethod.getBasePath());
			String rootPath="html/news/";
			CommonMethod.dirMake(rootPath, dirPath);
			String ss[]=dirPath.split("/");//ss[0]为yyyy,ss[1]为MMdd
			String templatesPath="/";
			
			String itemname=item_temp.getItemName();
			String templateFile="WEB-INF/templates/newsDetail2.ftl";
			if(itemname.equals("专题")){
				templateFile="WEB-INF/templates/zhuanti.ftl";
			}
			String htmlFile="html/news/"+ss[0]+"/"+ss[1]+"/"+ss[2]+"/news-"+newsID+".html";
			if(updatetime==1){//删除原来文件
				String path_temp=new SimpleDateFormat("yyyy/MM/dd").format(createtime);
				String ss2[]=path_temp.split("/");//ss[0]为yyyy,ss[1]为MMdd
				String htmlFile_temp="html/news/"+ss2[0]+"/"+ss2[1]+"/"+ss2[2]+"/news-"+newsID+".html";
				String real_file=CommonMethod.getRealPath(htmlFile_temp);
				File file=new File(real_file);
				if(file.exists()){
					file.delete();
				}
			}
			FreeMarker.analysisTemplate(templatesPath,templateFile,htmlFile,root);
			
			this.addActionMessage("修改成功！");
			translateInfo="修改成功！";
		}else{
			this.addActionMessage("修改失败！");
		}
		return "update_s";
	}
	/**
	 * 分页查询所有新闻
	 * @return
	 */
	public String findAll(){
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(20);
		Result result=newsService.findAllNews(zpage,0,0);
		page=result.getPage();
		newslist=result.getList();
		return "findAll_s";
	}
	public String list(){
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(20);
		Result result=newsService.findAllNews(zpage,subItemID,itemID);
		page=result.getPage();
		newslist=result.getList();
		return "findAll_s";
	}
	/**
	 * 简单关键字搜索
	 * @return
	 */
	public String findByKeyWords(){
		
		if(currentPage>1){
			Page zpage=new Page();
			zpage.setCurrentPage(currentPage);
			zpage.setEveryPage(16);
			
			try {
				keywords=new String(keywords.getBytes("iso-8859-1"),"utf-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Result result=newsService.findByKeyWords(zpage, keywords);
			page=result.getPage();
			newslist=result.getList();
			return "findByKeyWords_s";
		}else{
			//限制前台搜索时间间隔至少为3秒
			ActionContext act=ActionContext.getContext();
			Date date_temp=new Date();
			Map session=act.getSession();
			Date findbykeyword_time=(Date)session.get("findbykeyword_time");
			
			if(findbykeyword_time==null){
				session.put("findbykeyword_time", date_temp);
				//第一次搜索，可以执行
				Page zpage=new Page();
				zpage.setCurrentPage(currentPage);
				zpage.setEveryPage(16);
				//中文转码
				try {
					keywords=new String(keywords.getBytes("iso-8859-1"),"utf-8");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Result result=newsService.findByKeyWords(zpage, keywords);
				page=result.getPage();
				newslist=result.getList();
				return "findByKeyWords_s";
				
			}else{
				session.put("findbykeyword_time", date_temp);
				long time_session=findbykeyword_time.getTime();
				long time_current=date_temp.getTime();
				//下面是限制搜索时间的，以毫秒为单位
				if(time_current-time_session>3000){
					//时间超过3秒，可以执行
					Page zpage=new Page();
					zpage.setCurrentPage(currentPage);
					zpage.setEveryPage(16);
					//windows下面需要显示的转码
					//linux下不需要转码，需要注释掉
					
					try {
						keywords=new String(keywords.getBytes("iso-8859-1"),"utf-8");
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					Result result=newsService.findByKeyWords(zpage, keywords);
					page=result.getPage();
					newslist=result.getList();
					return "findByKeyWords_s";
					
				}else{
					newslist=null;
					return "findByKeyWords_s";
				}
				
			}
		}
		
		
		
		
	}
	/**
	 * 高级搜索
	 * @return
	 */
	public String advancedSearch(){
		//搜索过程需要转码
		try {
			//	editorName=new String(editorName.getBytes("iso-8859-1"),"utf-8");
			keywords=new String(keywords.getBytes("iso-8859-1"),"utf-8");
			editorName=new String(editorName.getBytes("iso-8859-1"),"utf-8");
			source=new String(source.getBytes("iso-8859-1"),"utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		//限制搜索时间间隔
		if(currentPage>1){
			Page zpage=new Page();
			zpage.setCurrentPage(currentPage);
			zpage.setEveryPage(20);
			/*
			 * keywords新闻标题关键字 editorName编辑 content新闻内容 author作者 createtime发布时间  
			 * recrutTime(拼写有误，但是又这样做了)招聘时间 recruitAddress int型数据，这个有点不一样 source来源
			 * starttime开始时间 endtime结束时间
			 * 
			 */
			Result result=newsService.advancedSearch(zpage, keywords,editorName,content,author,createtime,recrutTime,starttime,endtime,recruitAddress,source);
			page=result.getPage();
			newslist=result.getList();
			
			return "advancedSearch_s";
		}else{
			ActionContext act=ActionContext.getContext();
			Date date_temp=new Date();
			Map session=act.getSession();
			Date advancedSearch_time=(Date)session.get("advancedSearch_time");
			
			if(advancedSearch_time==null){
				session.put("advancedSearch_time", date_temp);
				Page zpage=new Page();
				zpage.setCurrentPage(currentPage);
				zpage.setEveryPage(20);
				/*
				 * keywords新闻标题关键字 editorName编辑 content新闻内容 author作者 createtime发布时间  
				 * recrutTime(拼写有误，但是又这样做了)招聘时间 recruitAddress int型数据，这个有点不一样 source来源
				 * starttime开始时间 endtime结束时间
				 * 
				 */
				Result result=newsService.advancedSearch(zpage, keywords,editorName,content,author,createtime,recrutTime,starttime,endtime,recruitAddress,source);
				page=result.getPage();
				newslist=result.getList();
				
				return "advancedSearch_s";
			}else{
				session.put("advancedSearch_time", date_temp);
				long time_session=advancedSearch_time.getTime();
				long time_current=date_temp.getTime();
				//下面是限制搜索时间的，以毫秒为单位
				if(time_current-time_session>3000){
					Page zpage=new Page();
					zpage.setCurrentPage(currentPage);
					zpage.setEveryPage(20);
					/*
					 * keywords新闻标题关键字 editorName编辑 content新闻内容 author作者 createtime发布时间  
					 * recrutTime(拼写有误，但是又这样做了)招聘时间 recruitAddress int型数据，这个有点不一样 source来源
					 * starttime开始时间 endtime结束时间
					 * 
					 */
					Result result=newsService.advancedSearch(zpage, keywords,editorName,content,author,createtime,recrutTime,starttime,endtime,recruitAddress,source);
					page=result.getPage();
					newslist=result.getList();
					
					return "advancedSearch_s";
				}else{
					newslist=null;
					return "advancedSearch_s";
				}
			}
		}
		
		
	}
	
	
	public String setTop(){
		newsService.setTop(newsID, settop);
		if(settop==1){
			this.addActionMessage("置顶成功！");
		}else{
			this.addActionMessage("取消置顶成功！");
		}
		return "settop_s";
	}
	
	/***************************安卓访问接口********************************************************************/
	/**
	 * 获取所有新闻 Android
	 * @return
	 */
	public String findAllAndroid()
	{
		HttpServletRequest request=ServletActionContext.getRequest();
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(everyPage);
		Result result=newsService.findAllNews(zpage,subItemID,itemID);
		page=result.getPage();
		newslist=result.getList();
		//[{id:0,title:"xxx",content:"xxx",time:"2013-07-29"},{id:1,title:"xxx",content:"xxx",time:"2013-07-30"}]
		StringBuilder json = new StringBuilder();
		json.append('[');
		for(News news : newslist)
		{
			try 
			{
				json.append('{');
				json.append("id:").append(news.getNewsID()).append(",");
				json.append("title:\"").append(URLEncoder.encode(news.getTitle(),"gbk")).append("\",");
				json.append("content:\"").append(URLEncoder.encode(news.getContent(),"gbk")).append("\",");
				json.append("time:\"").append(URLEncoder.encode(news.getCreatetime().toString(),"gbk")).append("\"");
				json.append("},");
			}
			catch (UnsupportedEncodingException e) 
			{
				e.printStackTrace();
			}
		}
		json.deleteCharAt(json.length() - 1);
		json.append(']');
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try 
		{
			response.getWriter().write(json.toString());
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
		return null;
	}
	/**
	 * 获取最新动态（10条）Android
	 */
	public String recentNewsListAndroid(){
		int newsNum=10;
		HttpServletRequest request=ServletActionContext.getRequest();
		newslist = newsService.findRecentNewsList(newsNum);
		//[{id:0,title:"xxx",time:"2013-07-29"},{id:1,title:"xxx",time:"2013-07-30"}]
		
		StringBuilder json = new StringBuilder();
		json.append('[');
		for(News news : newslist)
		{	
			try{
				json.append('{');
				json.append("id:").append(news.getNewsID()).append(",");
				json.append("title:\"").append(URLEncoder.encode(news.getTitle(),"gbk")).append("\",");
				json.append("content:\"").append(URLEncoder.encode(news.getContent(),"gbk")).append("\",");
				json.append("time:\"").append(URLEncoder.encode(news.getCreatetime().toString(),"gbk")).append("\"");
				json.append("},");
			}
			catch (UnsupportedEncodingException e) 
			{
				e.printStackTrace();
			}
				
		}
		json.deleteCharAt(json.length() - 1);
		json.append(']');
		System.out.println(json);
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try 
		{
			response.getWriter().write(json.toString());
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
		
		return null;
	}
	
	/**
	 * 获取分类新闻列表 Android
	 * @return
	 */
	public String findNewsListByClassification(){
		HttpServletRequest request=ServletActionContext.getRequest();
		Page zpage=new Page();
		zpage.setCurrentPage(currentPage);
		zpage.setEveryPage(everyPage);
		Result result=newsService.findAllNewsList(zpage,subItemID,itemID);
		
		page=result.getPage();
		List NewsListByClassification=result.getList();
		//[{id:0,title:"xxx",content:"xxx",time:"2013-07-29"},{id:1,title:"xxx",content:"xxx",time:"2013-07-30"}]
		StringBuilder json = new StringBuilder();
		json.append('[');
		for(int i=0;i<NewsListByClassification.size();i++)
		{	
			Object[] obj=(Object[])NewsListByClassification.get(i);
			
				try{
					json.append('{');
					json.append("id:").append(obj[0]).append(",");
					json.append("title:\"").append(URLEncoder.encode(obj[1].toString(),"gbk")).append("\",");
					json.append("time:\"").append(URLEncoder.encode(obj[2].toString(),"gbk")).append("\"");
					/*
					json.append("title:\"").append(obj[1]).append("\",");
					json.append("time:\"").append(obj[2]).append("\"");
					*/
					json.append("},");
				}
				catch (UnsupportedEncodingException e) 
				{
					e.printStackTrace();
				}
				
				
		}
		json.deleteCharAt(json.length() - 1);
		json.append(']');
		System.out.println(json);
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try 
		{
			response.getWriter().write(json.toString());
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
		return null;
	}
	/**
	 * 根据新闻ID获取新闻详细信息
	 * @return
	 */
	/**范例 [{id:1000,title:"成都农商",content:"一二三",time:"2013-10-11 09:21:45.0",author:"原创",editor:"刘振华",source:""}]**/
	public String findNewsByNewsID(){
		HttpServletRequest request=ServletActionContext.getRequest();
		News news = newsService.findNewsByID(newsID);
		StringBuilder json = new StringBuilder();
		
		try{
			json.append('[');
			json.append('{');
			json.append("id:").append(news.getNewsID()).append(",");
			json.append("title:\"").append(URLEncoder.encode(news.getTitle(),"gbk")).append("\",");
			json.append("content:\"").append(URLEncoder.encode(news.getContent(),"gbk")).append("\",");
			json.append("time:\"").append(URLEncoder.encode(news.getCreatetime().toString(),"gbk")).append("\",");
			json.append("author:\"").append(URLEncoder.encode(news.getAuthor(),"gbk")).append("\",");
			json.append("editor:\"").append(URLEncoder.encode(news.getEditor().getAdminName(),"gbk")).append("\",");
			json.append("source:\"").append(URLEncoder.encode(news.getSource(),"gbk")).append("\"");
			json.append("},");
			json.deleteCharAt(json.length() - 1);
			json.append(']');
		}
		catch (UnsupportedEncodingException e) 
		{
			e.printStackTrace();
		}
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try 
		{
			response.getWriter().write(json.toString());
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
		return null;
	}
	/**
	 * 根据关键词查询返回新闻列表信息
	 * @return
	 */
	public String findNewsListByKeywords(){
		HttpServletRequest request=ServletActionContext.getRequest();
		System.out.println(keywords);
		try {
			keywords=new String(keywords.getBytes("iso-8859-1"),"utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		newslist = newsService.findNewsListByKeywords(keywords);
		//[{id:0,title:"xxx",time:"2013-07-29"},{id:1,title:"xxx",time:"2013-07-30"}]
		StringBuilder json = new StringBuilder();
		json.append('[');
		for(News news : newslist)
		{	
			try{
				json.append('{');
				json.append("id:").append(news.getNewsID()).append(",");
				json.append("title:\"").append(URLEncoder.encode(news.getTitle(),"gbk")).append("\",");
				json.append("time:\"").append(URLEncoder.encode(news.getCreatetime().toString(),"gbk")).append("\"");
				json.append("},");
			}
			catch (UnsupportedEncodingException e) 
			{
				e.printStackTrace();
			}
				
		}
		json.deleteCharAt(json.length() - 1);
		json.append(']');
		System.out.println(json);
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try 
		{
			response.getWriter().write(json.toString());
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
		return null;
	}
	
	

}

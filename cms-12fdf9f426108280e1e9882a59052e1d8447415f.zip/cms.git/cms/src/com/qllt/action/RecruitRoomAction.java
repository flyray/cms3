package com.qllt.action;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.struts2.ServletActionContext;

import com.qllt.po.RecruitRoom;
import com.qllt.po.SubItem;
import com.qllt.service.RecruitRoomService;

public class RecruitRoomAction {
	
	private int recruitRoomID;
	private String recruitRoomName;
	private int recruitRoomBelong;
	private int recruitRoomState;
//	private List<RecruitRoom> recruitRoomList; 不好用，还是用类吧
	private RecruitRoomService recruitRoomService;
	private RecruitRoom recruitRoom=new RecruitRoom();
	
	public RecruitRoom getRecruitRoom() {
		return recruitRoom;
	}
	public void setRecruitRoom(RecruitRoom recruitRoom) {
		this.recruitRoom = recruitRoom;
	}
	public RecruitRoomService getRecruitRoomService() {
		return recruitRoomService;
	}
	public void setRecruitRoomService(RecruitRoomService recruitRoomService) {
		this.recruitRoomService = recruitRoomService;
	}
	
	public int getRecruitRoomID() {
		return recruitRoomID;
	}
	public void setRecruitRoomID(int recruitRoomID) {
		this.recruitRoomID = recruitRoomID;
	}
	public String getRecruitRoomName() {
		return recruitRoomName;
	}
	public void setRecruitRoomName(String recruitRoomName) {
		this.recruitRoomName = recruitRoomName;
	}
	public int getRecruitRoomBelong() {
		return recruitRoomBelong;
	}
	public void setRecruitRoomBelong(int recruitRoomBelong) {
		this.recruitRoomBelong = recruitRoomBelong;
	}
	
	public int getRecruitRoomState() {
		return recruitRoomState;
	}
	public void setRecruitRoomState(int recruitRoomState) {
		this.recruitRoomState = recruitRoomState;
	}
	/**
	 * 添加新闻
	 * @return
	 */
	public String add(){
		RecruitRoom recruitRoom=new RecruitRoom();
		recruitRoom.setRecruitRoomName(recruitRoomName);
		recruitRoom.setRecruitRoomBelong(recruitRoomBelong);
		recruitRoomService.add(recruitRoom);
		return "add_s";
	}
	/**
	 * 更新
	 * @return
	 */
	public String update(){
		RecruitRoom recruitRoom=new RecruitRoom();
		recruitRoom.setRecruitRoomID(recruitRoomID);
		recruitRoom.setRecruitRoomName(recruitRoomName);
		recruitRoom.setRecruitRoomBelong(recruitRoomBelong);
		recruitRoomService.update(recruitRoom);
		
		return "update_s";
	}
	/**
	 * 删除 仅仅根据主键(recruitRoomID)就可以完成删除，其余的属性没有影响
	 * @return
	 */
	
	public String delete(){
		RecruitRoom recruitRoom=new RecruitRoom();
		recruitRoom.setRecruitRoomID(recruitRoomID);
		recruitRoom.setRecruitRoomName(recruitRoomName);
		recruitRoom.setRecruitRoomBelong(recruitRoomBelong);
		recruitRoomService.delete(recruitRoom);
				
		return "delete_s";
	}
	
	public String changeState(){
		RecruitRoom recruitRoom=new RecruitRoom();
		recruitRoom=recruitRoomService.findRecruitRoomByID(recruitRoomID);
		if(recruitRoom.getRecruitRoomState()==1){
			recruitRoom.setRecruitRoomState(0);
		}else{
			recruitRoom.setRecruitRoomState(1);
		}
		recruitRoomService.update(recruitRoom);
		
		return "update_s";
	}
	/**
	 * 查询所有的教室信息
	 * @return
	 */
	public String findAll(){
		recruitRoomService.findAll(recruitRoom);
		return "findAll_s";
	}
	
	/**
	 * ajax查询所有教室信息
	 */
	public String findAllAjax(){
		
		HttpServletRequest request=ServletActionContext.getRequest();
		int recruitSchoolNum=Integer.parseInt(request.getParameter("recruitSchoolNum"));
		List<RecruitRoom> recruitRoomList=recruitRoomService.findAllRoom(recruitSchoolNum);
		JSONArray jsonArray2 = JSONArray.fromObject(recruitRoomList);
		//ajax返回客户端
		jsonArray2.toString();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(jsonArray2.toString());
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	/**
	 * 按照recruitRoomID进行查询，得到所有的数据，然后得到相应的recruitRoomName及recruitRoomBelong
	 */
	public String findAjax(){
		
		HttpServletRequest request=ServletActionContext.getRequest();
		int recruitRoomID=Integer.parseInt(request.getParameter("recruitRoomID"));
		RecruitRoom recruitRoom=recruitRoomService.findRecruitRoomByID(recruitRoomID);
		String recruitRoomName=recruitRoom.getRecruitRoomName();
		int recruitSchoolNum=recruitRoom.getRecruitRoomBelong();
		//用于返回给客户端的数据
		String ajax_message;
		ajax_message="{'recruitRoomName':'"+recruitRoomName+"','recruitSchoolNum':'"+recruitSchoolNum+"','recruitRoomID':'"+recruitRoomID+"'}";
		
		//将查询得到的数据返回客户端
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(ajax_message);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		
		return null;
	}
	
}

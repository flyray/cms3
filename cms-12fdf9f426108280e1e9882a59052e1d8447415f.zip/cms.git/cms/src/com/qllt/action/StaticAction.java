package com.qllt.action;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.qllt.po.Item;
import com.qllt.po.Menu;
import com.qllt.po.News;
import com.qllt.po.Question;
import com.qllt.po.RecruitRoom;
import com.qllt.po.RecruitSchool;
import com.qllt.po.SubItem;
import com.qllt.po.SubMenu;
import com.qllt.service.AdminService;
import com.qllt.service.ItemService;
import com.qllt.service.MenuService;
import com.qllt.service.NewsService;
import com.qllt.service.QuestionService;
import com.qllt.service.RecruitRoomService;
import com.qllt.service.RecruitSchoolService;
import com.qllt.service.SubItemService;
import com.qllt.service.SubMenuService;
import com.qllt.stacticpo.Header;
import com.qllt.stacticpo.Main;
import com.qllt.util.CommonMethod;
import com.qllt.util.FreeMarker;
import com.qllt.util.Page;
import com.qllt.util.PageUtil;
import com.qllt.util.Result;

/**
 * @author Administrator
 *
 */
public class StaticAction extends ActionSupport{
	private ItemService itemService;
	private SubItemService subItemService;
	private NewsService newsService;
	private MenuService menuService;
	private QuestionService questionService;
	
	private int ifupdate;//生成策略：1:非零，累加生成（更新生成） 2：生成所有
	private int itemID;
	private int subItemID;
	private int everyPage=20;
	private List<Item> items;
	private List<SubItem> subItems;
	private int[] itemList;
	private int[] subItemList;
	private AdminService adminService;
	private SubMenuService subMenuService;
	private RecruitSchoolService recruitSchoolService;//根据招聘校区编号查询招聘校区
	private RecruitRoomService recruitRoomService;//根据招聘教室ID查询招聘教室
	private String recruitSchoolName;//接收查询到的招聘校区名字
	private String recruitRoomName;//接收查询到的招聘教室的名字
	
	public void setQuestionService(QuestionService questionService) {
		this.questionService = questionService;
	}
	public String getRecruitSchoolName() {
		return recruitSchoolName;
	}
	public void setRecruitSchoolName(String recruitSchoolName) {
		this.recruitSchoolName = recruitSchoolName;
	}
	public String getRecruitRoomName() {
		return recruitRoomName;
	}
	public void setRecruitRoomName(String recruitRoomName) {
		this.recruitRoomName = recruitRoomName;
	}
	public void setRecruitSchoolService(RecruitSchoolService recruitSchoolService) {
		this.recruitSchoolService = recruitSchoolService;
	}
	public void setRecruitRoomService(RecruitRoomService recruitRoomService) {
		this.recruitRoomService = recruitRoomService;
	}
	public void setSubMenuService(SubMenuService subMenuService) {
		this.subMenuService = subMenuService;
	}
	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}
	public List<SubItem> getSubItems() {
		return subItems;
	}
	public void setSubItems(List<SubItem> subItems) {
		this.subItems = subItems;
	}
	
	public int[] getItemList() {
		return itemList;
	}
	public void setItemList(int[] itemList) {
		this.itemList = itemList;
	}
	public int[] getSubItemList() {
		return subItemList;
	}
	public void setSubItemList(int[] subItemList) {
		this.subItemList = subItemList;
	}
	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
	
	public int getEveryPage() {
		return everyPage;
	}
	public void setEveryPage(int everyPage) {
		this.everyPage = everyPage;
	}
	
	public int getIfupdate() {
		return ifupdate;
	}
	public void setIfupdate(int ifupdate) {
		this.ifupdate = ifupdate;
	}
	public int getItemID() {
		return itemID;
	}
	public void setItemID(int itemID) {
		this.itemID = itemID;
	}
	public int getSubItemID() {
		return subItemID;
	}
	public void setSubItemID(int subItemID) {
		this.subItemID = subItemID;
	}
	public void setItemService(ItemService itemService) {
		this.itemService = itemService; 
	}
	public void setSubItemService(SubItemService subItemService) {
		this.subItemService = subItemService;
	}
	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}
	public void setMenuService(MenuService menuService) {
		this.menuService = menuService;
	}
	
	/**
	 * 
	 * @return
	 */
	public String createHeaderAndFooter(){
		List<Menu> menus=menuService.queryAllMenu();
		List<SubMenu> subMenus=subMenuService.queryAllSubMenu();
		Header header=new Header();
		header.setMenus(menus);
		header.setSubMenus(subMenus);
		Map<String,Object> root=new HashMap<String, Object>();
		root.put("header", header);
		root.put("bathPath",CommonMethod.getBasePath());
		String templatesPath="/WEB-INF/templates/common";
		FreeMarker.analysisTemplate(templatesPath,"/header.ftl","header.html",root);//生成header
		FreeMarker.analysisTemplate(templatesPath,"/footer.ftl","footer.html",root);//生成footer
		FreeMarker.analysisTemplate(templatesPath,"/footer2.ftl","footer2.html",root);//生成footer2
		this.addActionMessage("头部及底部静态化生成成功！");
		//生成其他页面
		createOthers();
		return SUCCESS;
	}
	/**
	 * 
	 * @return
	 */
	public String createIndex(){
		//判断header.html是否存在，如果不存在则生成一下
		boolean b=CommonMethod.fileExits("header.html");
		if(!b){
			createHeaderAndFooter();
		}
		List<Menu> menus=menuService.queryAllMenu();
		Header header=new Header();
		header.setMenus(menus);
		//查取各栏目的新闻，各16条
		Page page =new Page();
		Page page2 =new Page();
		page.setEveryPage(16);
		page2.setEveryPage(15);
		List<News> tzggList=newsService.findAllNews(page, 0, 6).getList();//通知公告
		List<News> xwzxList=newsService.findAllNews(page, 35, 0).getList();//新闻资讯
		List<News> yxjlList=newsService.findAllNews(page, 6, 0).getList();//院系交流
		List<News> xyzpList=newsService.findAllNews(page2, 17, 6).getList();//校园招聘
		List<News> zxzpList=newsService.findAllNews(page, 18, 6).getList();//在线招聘
		List<News> sxzpList=newsService.findAllNews(page, 19, 6).getList();//实习招聘
		//用main对象包装各栏目的新闻
		Main main=new Main();
		main.setTzggList(tzggList);
		main.setXwzxList(xwzxList);
		main.setYxjlList(yxjlList);
		main.setXyzpList(xyzpList);
		main.setZxzpList(zxzpList);
		main.setSxzpList(sxzpList);
		
		Map<String,Object> root=new HashMap<String, Object>();
		root.put("header", header);
		root.put("main",main);
		String templatesPath="/";
		String templateFile="WEB-INF/templates/index.ftl";
		String htmlFile="index.html"; 
		FreeMarker.analysisTemplate(templatesPath,templateFile,htmlFile,root);
		this.addActionMessage("首页静态化成功！");
		return SUCCESS;
	}
	//p，v操作必须是原子的,因此要加同步关键字
		public synchronized boolean v_all(){
			CommonMethod.allmetux++;
			if(CommonMethod.allmetux>1){
				CommonMethod.allmetux--;
				return false;
			}
			return true;
		}
		public synchronized boolean p_all(){
			CommonMethod.allmetux--;
			if(CommonMethod.allmetux<0){
				CommonMethod.allmetux++;
				return false;
			}
			return true;
		}
		/**
		 * 该方法是onekey2线程安全的版本
		 */
	/**
	 * 总的静态化方法：有4个参数，page,subItemID,itemID,isupdate
	 * 其中isupdate!=0为更新不存在html文件的新闻，isupdate==0是为强制更新所有新闻;
	 * @return
	 */
	public String createAllNews(){
		if(p_all()==true){//申请锁成功
			createAllNews_unsafe();

			CommonMethod.ajaxMessage("所有新闻静态化成功！", false);
			v_all();
		}else{
			CommonMethod.ajaxMessage("其他用户正在静态化中,您发布的新闻将在下一次静态化生成！", true);
		}
		this.addActionMessage("所有新闻页静态化成功！");
		return SUCCESS;
	}
	private void createAllNews_unsafe(){
		//判断header.heml是否存在，如果不存在，生成一下
		String basePath=CommonMethod.getBasePath();
		boolean b=CommonMethod.fileExits("header.html");
		if(!b){
			createHeaderAndFooter();
		}
		//查询到所有新闻
		Page page=new Page();
		int count=newsService.queryNewsCount();
		page.setEveryPage(count);
		Result result=newsService.findAllNews(page, 0, 0);
		List<News> newslist=result.getList();
		for(News news:newslist){
			//获得新闻创建日期，并以此创建目录
			Date date=news.getCreatetime();
			int news_id=news.getNewsID();
			int subitemID=news.getSubItem().getSubItemID();
			//查询招聘教室信息
			int recruitAddress;
			recruitAddress=news.getRecruitAddress();
			RecruitRoom recruitRoom_temp=recruitRoomService.findRecruitRoomByID(recruitAddress);
			recruitRoomName=recruitRoom_temp.getRecruitRoomName();
			//查询招聘校区信息
			int recruitSchoolNum=recruitRoom_temp.getRecruitRoomBelong();
			RecruitSchool recruitSchool_temp=recruitSchoolService.findRecruitSchoolByNum(recruitSchoolNum);
			recruitSchoolName=recruitSchool_temp.getRecruitSchoolName();
			
			//将招聘校区信息放进news对象中，然后一起传进ftl文件中
			news.setRecruitSchoolName(recruitSchoolName);
			//将招聘教室信息放进news对象中，然后一起传进ftl文件中
			news.setRecruitRoomName(recruitRoomName);
			
			Map<String,Object> root=new HashMap<String, Object>();
			root.put("basePath",basePath);
			String rootPath="html/news/";
			String dirPath=new SimpleDateFormat("yyyy/MM/dd").format(date);
			CommonMethod.dirMake(rootPath, dirPath);
			//生成模板和目标文件的地址
			String ss[]=dirPath.split("/");//ss[0]为yyyy,ss[1]为MMdd
			String templatesPath="/";
			String templateFile="WEB-INF/templates/newsDetail.ftl";
			
			//查询subItem,然后确定item ，如果是“专题则换一个模版
			SubItem subItem_temp=subItemService.findSubItemByID(subitemID);
			int itemID_temp=subItem_temp.getItem().getItemID();
			Item item_temp=itemService.findItemByItemID(itemID_temp);
			String itemname=item_temp.getItemName();
			if(itemname.equals("专题")){
				templateFile="WEB-INF/templates/zhuanti.ftl";
			}
			
			String htmlFile="html/news/"+ss[0]+"/"+ss[1]+"/"+ss[2]+"/news-"+news_id+".html";
			if(ifupdate!=0){//只生成不存在的，极少数情况使用。
				boolean bb=CommonMethod.fileExits(htmlFile);
				if(bb==false){
					Item it = news.getSubItem().getItem();
					List<SubItem> subItemList = subItemService.findAllSubItem(it.getItemID());
					//将招聘教室及招聘校区put进root
					root.put("recruitSchoolName",recruitSchoolName);
					root.put("recruitRoomName",recruitRoomName);
					root.put("news",news);
					root.put("item",it);
					root.put("subItemList",subItemList);
					
					FreeMarker.analysisTemplate(templatesPath,templateFile,htmlFile,root);
				}
			}else{
				Item it = news.getSubItem().getItem();
				List<SubItem> subItemList = subItemService.findAllSubItem(it.getItemID());
				//将招聘教室及招聘校区put进root
				root.put("recruitSchoolName",recruitSchoolName);
				root.put("recruitRoomName",recruitRoomName);
				root.put("news",news);
				root.put("item",it);
				root.put("subItemList",subItemList);
				FreeMarker.analysisTemplate(templatesPath,templateFile,htmlFile,root);
			}
		}
	}
	//p，v操作必须是原子的,因此要加同步关键字
	public synchronized boolean v(){
		CommonMethod.metux++;
		if(CommonMethod.metux>1){
			CommonMethod.metux--;
			return false;
		}
		return true;
	}
	public synchronized boolean p(){
		CommonMethod.metux--;
		if(CommonMethod.metux<0){
			CommonMethod.metux++;
			return false;
		}
		return true;
	}
	/**
	 * 该方法是onekey2线程安全的版本
	 */
	public void onekey(){
		//一会在处理静态化权限问题，把静态化权限去掉
			if(p()==true){//申请锁成功
				onekey_unsafe();
				createRecrutList();//同时生成7天招聘的内容！
				CommonMethod.ajaxMessage("一键静态化成功！", false);
				v();
			}else{
				CommonMethod.ajaxMessage("其他用户正在静态化中,您发布的新闻将在下一次静态化生成！", true);
			}
	}
	/**
	 * 此方法不要调用，因为会产生多用户同时调用该方法，会导致cpu使用率过高，请调用onekey方法onekey方法是线程安全的
	 */
	private void onekey_unsafe(){
			List<SubItem> subItems= subItemService.findAllSubItem();
			int length = subItems.size();
			subItemList = new int[length];

			for(int i=0;i<length;i++){
				subItemList[i] = subItems.get(i).getSubItemID();
			}
			List<Item> items = itemService.findAllItem();
			length = items.size();
			itemList=new int[length];
			for(int i=0;i<length;i++){
				itemList[i] = items.get(i).getItemID();
			}
		createIndex();
		createSubItem(subItemList);
		createItem();
	}
	public String createItem(){
		//判断header.heml是否存在，如果不存在，生成一下
		boolean b=CommonMethod.fileExits("header.html");
		if(!b){
			createHeaderAndFooter();
		}
		
		//分页查询，每页20条，当前页是第1页
		everyPage = 20;
		Page page=new Page();
		page.setEveryPage(everyPage);
		int currentPage = 1;
		page.setCurrentPage(currentPage);
		
		//模板文件地址，生成目标文件地址
		String templatePath = "/";
		String templateFile = "WEB-INF/templates/itemList.ftl";
		String rootPath="html/";
		String dirPath="items/";
		//创建目录
		CommonMethod.dirMake(rootPath, dirPath);
		
		for(int i=0;i<itemList.length;i++){
			currentPage = 1;//每次重置当前页
			page.setCurrentPage(currentPage);
			//得到一级栏目名称和其下二级栏目的名称
			Item it = itemService.findItemByItemID(itemList[i]);
			String itemName = it.getItemName();
			List<SubItem> subItemList = subItemService.findAllSubItem(itemList[i]);
			//求出新闻条数和新闻页数
			int newsNum = newsService.queryNewsCountByItemID(itemList[i]);
			int pageNum;
			if(newsNum%everyPage==0){
				pageNum = newsNum/everyPage;
			}
			else{
				pageNum = newsNum/everyPage+1;
			}
			//为每个一级栏目分页生成静态文件
			for(int j=0;j<pageNum;j++){
				page=PageUtil.createPage(page,newsNum);
				List<News> newsList = newsService.queryNewsListByNewsItemID(itemList[i], page);
				String FilePath = "html/items/"+"item"+itemList[i]+"-"+currentPage+".html";
				Map<String,Object> root=new HashMap<String, Object>();
				root.put("itemID",itemList[i]);
				root.put("itemName", itemName);
				root.put("subItemList", subItemList);
				root.put("newsList", newsList);
				root.put("currentPage", currentPage);
				root.put("pageNum",pageNum);
				root.put("basePath",CommonMethod.getBasePath());
					
				//如果是校内招聘，用特定模板，其他的用另外模板
				if(itemList[i]==7){
					//为新闻list中的每个新闻添加recruitAddress2属性
					for(News news_temp:newsList){
						int recruitAddress=news_temp.getRecruitAddress();
						RecruitRoom recruitRoom_temp=recruitRoomService.findRecruitRoomByID(recruitAddress);
						news_temp.setRecruitRoomName(recruitRoom_temp.getRecruitRoomName());
						
						//查询招聘校区信息
						int recruitSchoolNum=recruitRoom_temp.getRecruitRoomBelong();
						RecruitSchool recruitSchool_temp=recruitSchoolService.findRecruitSchoolByNum(recruitSchoolNum);
						news_temp.setRecruitSchoolName(recruitSchool_temp.getRecruitSchoolName());
					}
					String templateFileSpecial = "WEB-INF/templates/schoolrecuit_item.ftl";
					FreeMarker.analysisTemplate(templatePath,templateFileSpecial,FilePath,root);
				}

				else{
					FreeMarker.analysisTemplate(templatePath,templateFile,FilePath,root);
				}
				//FreeMarker.analysisTemplate(templatePath,templateFile,FilePath,root);
				currentPage++;
				page.setCurrentPage(currentPage);
			}
		}
		
		this.addActionMessage("一级列表页静态化成功！");
		return SUCCESS;
	}
	public String createSubItem(int []subitemlist){
		//判断header.heml是否存在，如果不存在，生成一下
		boolean b=CommonMethod.fileExits("header.html");
		if(!b){
			createHeaderAndFooter();
		}
		//分页查询，每页20条，当前页是滴1页
		everyPage = 20;
		Page page=new Page();
		page.setEveryPage(everyPage);
		int currentPage = 1;
		page.setCurrentPage(currentPage);
		
		//模板文件地址，生成目标文件地址
		String templatePath = "/";
		String templateFile = "WEB-INF/templates/subItemList.ftl";
		String rootPath="html/";
		String dirPath="subItems/";
		//创建目录
		CommonMethod.dirMake(rootPath, dirPath);
		//处理需要传递的数据对象
		ServletContext  actionContext = ServletActionContext.getServletContext();  
		String basePath=CommonMethod.getBasePath();
		StaticActionMulti staticactionmulti=new StaticActionMulti();
		int [] subItemList=subitemlist;
		
		staticactionmulti.initSubitem(subItemList.length, subItemList, everyPage, subItemService, newsService,recruitSchoolService,recruitRoomService, basePath, actionContext, templateFile);
		
		if(staticactionmulti.createSubitem()==true){
			this.addActionMessage("二级页表页静态化成功！");
			return SUCCESS;
		}else{
			this.addActionMessage("二级页表页静态化失败！");
			return null;
		}
		/*
		for(int i=0;i<subItemList.length;i++){
			currentPage = 1;//每次重置当前页
			page.setCurrentPage(currentPage);
			//得到一级栏目名称和其下二级栏目的名称
			SubItem subItem = subItemService.findSubItemByID(subItemList[i]);
			Item it = subItem.getItem();
			List<SubItem> subItemList1 = subItemService.findAllSubItem(it.getItemID());
			//求出新闻条数和新闻页数
			int newsNum = newsService.queryNewsCountBySubItemID(subItemList[i]);
			int pageNum;
			if(newsNum%everyPage==0){
				pageNum = newsNum/everyPage;
			}
			else{
				pageNum = newsNum/everyPage+1;
			}
			//为每个二级栏目分页生成静态文件
			for(int j=0;j<pageNum;j++){
				page=PageUtil.createPage(page,newsNum);
				List<News> newsList = newsService.queryNewsListByNewsSubItemID(subItemList[i], page);
				String FilePath = "html/subItems/"+"subItem"+subItemList[i]+"-"+currentPage+".html";
				Map<String,Object> root=new HashMap<String, Object>();
				root.put("item",it);
				root.put("subItem",subItem);
				root.put("subItemList", subItemList1);
				root.put("newsList", newsList);
				root.put("currentPage", currentPage);
				root.put("pageNum",pageNum);
				String basePath=CommonMethod.getBasePath();
				root.put("basePath",basePath);
					
				//如果是校内招聘，用特定模板，其他的用另外模板
				if(subItemList[i]==17){
					//为新闻list中的每个新闻添加recruitAddress2属性
					for(News news_temp:newsList){
						int recruitAddress=news_temp.getRecruitAddress();
						RecruitRoom recruitRoom_temp=recruitRoomService.findRecruitRoomByID(recruitAddress);
						news_temp.setRecruitRoomName(recruitRoom_temp.getRecruitRoomName());
						
						//查询招聘校区信息
						int recruitSchoolNum=recruitRoom_temp.getRecruitRoomBelong();
						RecruitSchool recruitSchool_temp=recruitSchoolService.findRecruitSchoolByNum(recruitSchoolNum);
						news_temp.setRecruitSchoolName(recruitSchool_temp.getRecruitSchoolName());
					}
					String templateFileSpecial = "WEB-INF/templates/schoolrecuit.ftl";
					FreeMarker.analysisTemplate(templatePath,templateFileSpecial,FilePath,root);
				}
				else{
					FreeMarker.analysisTemplate(templatePath,templateFile,FilePath,root);
				}
				//FreeMarker.analysisTemplate(templatePath,templateFile,FilePath,root);
				currentPage++;
				page.setCurrentPage(currentPage);
			}
		}
		
		this.addActionMessage("二级页表页静态化成功！");
		return SUCCESS;
		*/
	}
	public String createRecrutList(){
		//分页查询，每页20条，当前页是滴1页
		everyPage = 20;
		Page page=new Page();
		page.setEveryPage(everyPage);
		int currentPage = 1;
		page.setCurrentPage(currentPage);
		//获得当前日期和7天前日期，查询招聘信息最近一周的新闻条数
		Date beginDate = new Date();//开始时间
		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		c.add(c.DAY_OF_YEAR, 7);
		String endTime =new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date endDate = null;
		try {
			endDate = sdf.parse(endTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}//结束时间
		
		int newsNum = newsService.queryXnzpNewsCount(beginDate,endDate);
		int pageNum;
		System.out.println(newsNum+"newsNum");
		if(newsNum%everyPage==0){
			pageNum = newsNum/everyPage;
		}
		else{
			pageNum = newsNum/everyPage+1;
		}
		//模板文件地址，生成目标文件地址
		String templatePath = "/";
		String templateFile = "WEB-INF/templates/schoolrecuit.ftl";
		String rootPath="html/";
		String dirPath="recruit/";
		//创建目录
		CommonMethod.dirMake(rootPath, dirPath);
		//获得二级和一级栏目对象
		
		//为每个二级栏目分页生成静态文件
		for(int j=0;j<pageNum;j++){
			page=PageUtil.createPage(page,newsNum);
			List<News> newsList = newsService.queryXnzpNews(page,beginDate,endDate);
			//为新闻list中的每个新闻添加recruitAddress2属性
			for(News news_temp:newsList){
				int recruitAddress=news_temp.getRecruitAddress();
				RecruitRoom recruitRoom_temp=recruitRoomService.findRecruitRoomByID(recruitAddress);
				news_temp.setRecruitRoomName(recruitRoom_temp.getRecruitRoomName());
				
				//查询招聘校区信息
				int recruitSchoolNum=recruitRoom_temp.getRecruitRoomBelong();
				RecruitSchool recruitSchool_temp=recruitSchoolService.findRecruitSchoolByNum(recruitSchoolNum);
				news_temp.setRecruitSchoolName(recruitSchool_temp.getRecruitSchoolName());
			}
			String FilePath = "html/recruit/"+"recruit"+"-"+currentPage+".html";
			Map<String,Object> root=new HashMap<String, Object>();
			root.put("newsList", newsList);
			root.put("currentPage", currentPage);
			root.put("pageNum",pageNum);
			root.put("basePath",CommonMethod.getBasePath());
				
			FreeMarker.analysisTemplate(templatePath,templateFile,FilePath,root);
			currentPage++;
			page.setCurrentPage(currentPage);
		}
		this.addActionMessage("未来7天招聘信息页静态化成功");
		return SUCCESS;
	}	
	/**
	 * 静态化生成所有问答的列表页
	 * @return
	 */
	public void createQuestionList(){
		//分页查询，每页20条，当前页是滴1页
		everyPage = 20;
		Page page=new Page();
		page.setEveryPage(everyPage);
		int currentPage = 1;
		page.setCurrentPage(currentPage);
		int newsNum=questionService.queryShowCount();
		int pageNum;
		if(newsNum%everyPage==0){
			pageNum = newsNum/everyPage;
		}
		else{
			pageNum = newsNum/everyPage+1;
		}
		//模板文件地址，生成目标文件地址
		String templatePath = "/";
		String templateFile = "WEB-INF/templates/question_list.ftl";
		String rootPath="html/";
		String dirPath="question/";
		//创建目录
		CommonMethod.dirMake(rootPath, dirPath);
		//为每个二级栏目分页生成静态文件
		for(int j=0;j<pageNum;j++){
			page=PageUtil.createPage(page,newsNum);
			List<Question> newsList = questionService.queryShowDetail(page);
			String FilePath = "html/question/"+"question_list"+"-"+currentPage+".html";
			Map<String,Object> root=new HashMap<String, Object>();
			root.put("newsList", newsList);
			root.put("currentPage", currentPage);
			root.put("pageNum",pageNum);
			root.put("basePath",CommonMethod.getBasePath());

			FreeMarker.analysisTemplate(templatePath,templateFile,FilePath,root);
			currentPage++;
			page.setCurrentPage(currentPage);
		}
		
	}
	public void createQuestionDetail(){
		//模板文件地址，生成目标文件地址
		String templatePath = "/";
		String templateFile = "WEB-INF/templates/question_detail.ftl";
		String rootPath="html/";
		String dirPath="question/";
		//创建目录
		CommonMethod.dirMake(rootPath, dirPath);
		//为每个二级栏目分页生成静态文件
		List<Question> newsList = questionService.queryAllShow();
		
		for(int i=0;i<newsList.size();i++){
			Question question_temp=newsList.get(i);
			String FilePath = "html/question/"+"question_detail"+"-"+question_temp.getQuestionID()+".html";
			Map<String,Object> root=new HashMap<String, Object>();
			root.put("question", question_temp);
			root.put("basePath",CommonMethod.getBasePath()); 
			FreeMarker.analysisTemplate(templatePath,templateFile,FilePath,root);
		}
		
	}
	public String createQuestion(){
		Map<String,Object> root=new HashMap<String, Object>();
		root.put("basePath", CommonMethod.getBasePath());
		String templatesPath="/";
		//提问页
		FreeMarker.analysisTemplate(templatesPath,"WEB-INF/templates/question/question.ftl","question/index.html",root);
		createQuestionDetail();
		createQuestionList();
		this.addActionMessage("就业问答静态化成功!");
		return SUCCESS;
	}
	public void createOthers(){
		Map<String,Object> root=new HashMap<String, Object>();
		root.put("basePath", CommonMethod.getBasePath());
		String templatesPath="/";
		//提问
		FreeMarker.analysisTemplate(templatesPath,"WEB-INF/templates/question/question.ftl","question/index.html",root);
		//友情链接
		FreeMarker.analysisTemplate(templatesPath,"WEB-INF/templates/special/flink.ftl","html/special/flink.html",root);
	}
}

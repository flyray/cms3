package com.qllt.action;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.struts2.ServletActionContext;

import com.qllt.po.RecruitSchool;
import com.qllt.service.RecruitSchoolService;
public class RecruitSchoolAction {
	private RecruitSchool recruitSchool=new RecruitSchool();
	private RecruitSchoolService recruitSchoolService;
	private int recruitSchoolID;
	private String recruitSchoolName;
	private int recruitSchoolNum;
	private List<RecruitSchool> recruitSchoolList;//记录查询得到的校区名字列表
	
	
	public int getRecruitSchoolID() {
		return recruitSchoolID;
	}
	public void setRecruitSchoolID(int recruitSchoolID) {
		this.recruitSchoolID = recruitSchoolID;
	}
	public String getRecruitSchoolName() {
		return recruitSchoolName;
	}
	public void setRecruitSchoolName(String recruitSchoolName) {
		this.recruitSchoolName = recruitSchoolName;
	}
	public int getRecruitSchoolNum() {
		return recruitSchoolNum;
	}
	public void setRecruitSchoolNum(int recruitSchoolNum) {
		this.recruitSchoolNum = recruitSchoolNum;
	}
	public List<RecruitSchool> getRecruitSchoolList() {
		return recruitSchoolList;
	}
	public void setRecruitSchoolList(List<RecruitSchool> recruitSchoolList) {
		this.recruitSchoolList = recruitSchoolList;
	}
	public RecruitSchool getRecruitSchool() {
		return recruitSchool;
	}
	public void setRecruitSchool(RecruitSchool recruitSchool) {
		this.recruitSchool = recruitSchool;
	}
	public RecruitSchoolService getRecruitSchoolService() {
		return recruitSchoolService;
	}
	public void setRecruitSchoolService(RecruitSchoolService recruitSchoolService) {
		this.recruitSchoolService = recruitSchoolService;
	}
	/**
	 * 添加
	 * @return
	 */
	public String add(){
		RecruitSchool recruitSchool=new RecruitSchool();
		recruitSchool.setRecruitSchoolName(recruitSchoolName);
		recruitSchool.setRecruitSchoolNum(recruitSchoolNum);
		recruitSchoolService.add(recruitSchool);
		return "add_s";
	}
	public String delete(){
		RecruitSchool recruitSchool=new RecruitSchool();
		recruitSchool.setRecruitSchoolName(recruitSchoolName);
		recruitSchool.setRecruitSchoolNum(recruitSchoolNum);
		recruitSchool.setRecruitSchoolID(recruitSchoolID);
		
		recruitSchoolService.delete(recruitSchool);
		return "delete_s";
	}
	public String update(){
		RecruitSchool recruitSchool=new RecruitSchool();
		recruitSchool.setRecruitSchoolName(recruitSchoolName);
		recruitSchool.setRecruitSchoolNum(recruitSchoolNum);
		recruitSchool.setRecruitSchoolID(recruitSchoolID);
		recruitSchoolService.update(recruitSchool);
		return "update_s";
	}
	public String findAll(){
		recruitSchoolService.findAll(recruitSchool);
		return "findAll_s";
	}
	/**
	 * ajax查询
	 */
	public String findAllAjax(){
		List<RecruitSchool> list=recruitSchoolService.findAllSchool();
		JSONArray jsonArray2 = JSONArray.fromObject(list);
		//ajax返回客户端
		jsonArray2.toString();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(jsonArray2.toString());
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
	
}

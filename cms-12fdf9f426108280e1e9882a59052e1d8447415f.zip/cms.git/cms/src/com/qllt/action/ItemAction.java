package com.qllt.action;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.qllt.po.Item;
import com.qllt.service.ItemService;

public class ItemAction extends ActionSupport{
	private int itemID;
	private String itemName;
	private int order;
	private List<Item> list;
	private ItemService itemService;
	
	public int getItemID() {
		return itemID;
	}
	public void setItemID(int itemID) {
		this.itemID = itemID;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	
	public void setItemService(ItemService itemService) {
		this.itemService = itemService;
	}
	public List<Item> getList() {
		return list;
	}
	public void setList(List<Item> list) {
		this.list = list;
	}
	/**
	 *添加导航
	 * @return
	 */
	public String add(){
		Item item=new Item();
		item.setItemName(itemName);
		item.setOrder(order);
		item.setCreateTime(new Date());
		if(itemService.addItem(item)){
			this.addActionMessage("添加成功！");
		}else{
			this.addActionMessage("添加失败！");
			
		}
		return "add_s";
	}
	/**
	 * 查找所有导航
	 * @return
	 */
	public String findAll(){
		list=itemService.findAllItem();
		return "findAll_s";
	}
	/**
	 * 查询详细信息
	 * @return
	 */
	public String findAjax(){
		HttpServletRequest request=ServletActionContext.getRequest();
		int itemID=Integer.parseInt(request.getParameter("itemID"));
		Item item=itemService.findItemByItemID(itemID);
		itemName=item.getItemName();
		order=item.getOrder();
		String ajax_message;
		ajax_message="{'itemName':'"+itemName+"','order':'"+order+"'}";
		//ajax返回客户端
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(ajax_message);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
	/**
	 * 修改一级导航
	 * @return
	 */
	public String update(){
		Item item=new Item();
		item.setItemID(itemID);
		item.setItemName(itemName);
		item.setCreateTime(new Date());
		item.setOrder(order);
		if(itemService.updateItem(item)){
			this.addActionMessage("修改成功！");
		}else{
			this.addActionMessage("修改成功！");
		}
		return "update_s";
	}
	/**
	 * 删除一级导航
	 * @return 
	 */
	public String delete(){
		if(itemService.deleteItemByID(itemID)){
			this.addActionMessage("删除成功！");
		}else{
			this.addActionMessage("删除失败！");
		}
		return "delete_s";
	}
	public String findAllAjax(){
		list=itemService.findAllItem();
		JSONArray jsonArray2 = JSONArray.fromObject(list);
		//ajax返回客户端
		jsonArray2.toString();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/html;charset=UTF-8");
		try {
			response.getWriter().write(jsonArray2.toString());
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return null;
	}
}	

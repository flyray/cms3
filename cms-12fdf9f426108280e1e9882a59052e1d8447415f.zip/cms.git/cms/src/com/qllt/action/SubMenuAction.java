package com.qllt.action;

import java.util.List;

import com.opensymphony.xwork2.ActionSupport;
import com.qllt.po.Menu;
import com.qllt.po.SubMenu;
import com.qllt.service.MenuService;
import com.qllt.service.SubMenuService;

public class SubMenuAction extends ActionSupport{
	private SubMenu subMenu;
	private List<Menu> menus;
	private List<SubMenu> subMenus;
	private MenuService menuService;
	private SubMenuService subMenuService;
	/**
	 * 添加
	 * @return
	 */
	public String add(){
		if(subMenuService.addSubMenu(subMenu)){
			addActionMessage("添加成功！");
		}else{
			addActionMessage("添加失败！");
		}
		return "add_s";
	}
	/**
	 * 查找所有
	 * @return
	 */
	public String findAll(){
		subMenuService.queryAllSubMenu();
		return "findAll_s";
	}
	/**
	 * 查找所有一级导航
	 * @return
	 */

	public String findMenuAll(){
		menus=menuService.queryAllMenu();
		return "findMenuAll_s";
	}
	/**
	 * 查找单个
	 * @return
	 */
	public String find(){
		subMenu=subMenuService.queryBySubMenuID(subMenu.getSubMenuID());
		return "find_s";
	}
	public String update(){
		if(subMenuService.updateSubMenu(subMenu)){
			addActionMessage("修改成功！");
		}else{
			addActionMessage("修改失败！");
		}
		return "update_s";
	}
	public String delete(){
		subMenuService.deleteSubMenu(subMenu.getSubMenuID());
		return "delete_s";
	}
	public SubMenu getSubMenu() {
		return subMenu;
	}

	
	
	
	public void setSubMenu(SubMenu subMenu) {
		this.subMenu = subMenu;
	}

	public void setSubMenuService(SubMenuService subMenuService) {
		this.subMenuService = subMenuService;
	}
	public List<SubMenu> getSubMenus() {
		return subMenus;
	}
	public void setSubMenus(List<SubMenu> subMenus) {
		this.subMenus = subMenus;
	}
	public MenuService getMenuService() {
		return menuService;
	}
	public void setMenuService(MenuService menuService) {
		this.menuService = menuService;
	}
	public List<Menu> getMenus() {
		return menus;
	}
	public void setMenus(List<Menu> menus) {
		this.menus = menus;
	}
	
}

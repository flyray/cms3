package com.qllt.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.struts2.ServletActionContext;

import com.qllt.po.News;

import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import freemarker.template.TemplateException;

public class FreeMarker {
	// templatePath模板文件存放路径
	// templateName 模板文件名称
	// filename 生成的文件名称
	public static int listCount;//list的大小
	private static int listIndex;//新闻list的索引 
	/**
	 * 用于生成单个html
	 * @param templatePath
	 * @param templateName
	 * @param fileName
	 * @param root
	 */
	public static void analysisTemplate(String templatePath,String templateName, String fileName, Map<?,?> root) {
		Writer out=null;
		try {
			Configuration config = new Configuration();
			// 设置要解析的模板所在的目录，并加载模板文件
		    templatePath=ServletActionContext.getServletContext().getRealPath(templatePath);//获取服务器的真正的文件位置
		    fileName=ServletActionContext.getServletContext().getRealPath(fileName);
			config.setDirectoryForTemplateLoading(new File(templatePath));
			// 设置包装器，并将对象包装为数据模型
			config.setObjectWrapper(new DefaultObjectWrapper());

			// 获取模板,并设置编码方式，这个编码必须要与页面中的编码格式一致
			// 否则会出现乱码
			Template template = config.getTemplate(templateName, "UTF-8");
			// 合并数据模型与模板
			FileOutputStream fos = new FileOutputStream(fileName);//写到文件中
			out = new OutputStreamWriter(fos, "UTF-8");
			template.process(root, out);
			out.flush();
			//关闭资源
			out.close();
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (TemplateException e) {
			e.printStackTrace();
		}finally{
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	//templatePath和fileName直接传递进来的
	public static void analysisTemplatePath(String templatePath,String templateName, String fileName, Map<?,?> root,ServletContext actionContext) {
		Writer out=null;
		try {
			Configuration config = new Configuration();
			// 设置要解析的模板所在的目录，并加载模板文件
		    templatePath=actionContext.getRealPath(templatePath);//获取服务器的真正的文件位置
		    fileName=actionContext.getRealPath(fileName);
			config.setDirectoryForTemplateLoading(new File(templatePath));
			// 设置包装器，并将对象包装为数据模型
			config.setObjectWrapper(new DefaultObjectWrapper());

			// 获取模板,并设置编码方式，这个编码必须要与页面中的编码格式一致
			// 否则会出现乱码
			Template template = config.getTemplate(templateName, "UTF-8");
			// 合并数据模型与模板
			FileOutputStream fos = new FileOutputStream(fileName);//写到文件中
			out = new OutputStreamWriter(fos, "UTF-8");
			template.process(root, out);
			out.flush();
			//关闭资源
			out.close();
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (TemplateException e) {
			e.printStackTrace();
		}finally{
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 用于生成多个html
	 * @param templatePath
	 * @param templateName
	 * @param fileName
	 * @param root
	 */
	public static void analysisTemplate(String templatePath,String templateName, String fileName,List<News> list, Map<?,?> root) {
		Writer out=null;
		FileOutputStream fos=null;
		try {
			Configuration config = new Configuration();
			// 设置要解析的模板所在的目录，并加载模板文件
		    templatePath=ServletActionContext.getServletContext().getRealPath(templatePath);//获取服务器的真正的文件位置
		    fileName=ServletActionContext.getServletContext().getRealPath(fileName);
			config.setDirectoryForTemplateLoading(new File(templatePath));
			// 设置包装器，并将对象包装为数据模型
			config.setObjectWrapper(new DefaultObjectWrapper());

			// 获取模板,并设置编码方式，这个编码必须要与页面中的编码格式一致
			// 否则会出现乱码
			Template template = config.getTemplate(templateName, "UTF-8");
			// 合并数据模型与模板
			fos= new FileOutputStream(fileName);//写到文件中
			for(Object o:list){
				
			}
			out = new OutputStreamWriter(fos, "UTF-8");
			template.process(root, out);
			out.flush();
			//关闭资源
			out.close();
			fos.close();
		} catch (IOException e) {
		} catch (TemplateException e) {
			e.printStackTrace();
		}finally{
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
package com.qllt.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

public class CommonMethod {
	/**
	 * 判断filepath在服务器上是否存在
	 * @param filepath
	 * @return
	 */
	public static int metux=1;//一建静态化互斥变量
	public static int allmetux=1;//生成所有新闻互斥变量
	public static boolean fileExits(String filepath){
		filepath=ServletActionContext.getServletContext().getRealPath(filepath);
		File file=new File(filepath);
		if(file.exists()){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * 获取文件的真实路径
	 * @param filepath
	 * @return
	 */
	public static String getRealPath(String filepath){
		return ServletActionContext.getServletContext().getRealPath(filepath);
	}
	/**
	 * 获取项目的basePath，本项目的basePath为http://localhost:8080/cms/
	 * @return
	 */
	public static String getBasePath(){
		HttpServletRequest request=ServletActionContext.getRequest();
		String basePath=request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath()+"/";
		return basePath;
	}
	/**
	 * 创建多级目录
	 * @param rootPath 相对于网站根目录的根目录，可理解为父目录
	 * @param dirPath 待创建的多级子文件夹
	 */
	public static void  dirMake(String rootPath,String dirPath){
		String realPath=ServletActionContext.getServletContext().getRealPath(rootPath);
		String ss[]=dirPath.split("/");
		for(int i=0;i<ss.length;i++){
			realPath+="/"+ss[i];
			File mkdir=new File(realPath);
			if(!mkdir.exists()){
//				 System.out.println("目录不存在");
				 mkdir.mkdir();
			}
		}
	}
	/**
	 * String[]转成string
	 * @param array
	 * @return
	 */
	public static String SA2S(String[] array){
		String s=null;
		for(int i=0;i<array.length;i++){
			if(i==(array.length-1)){
				s+=array[i];
			}else if(i==0){
				s=array[0]+",";
			}else{
				s+=array[i]+",";
			}
	    }
		return s;
	}
	/**
	 * 把String s转成String[]
	 * @param s
	 * @return
	 */
	public static String[] S2SA(String s){
		return s.split(",");
	}
	/**
	 * 把文件f转成字节byte[]
	 * @param f
	 * @return
	 */
	public static byte[] getBytesFromFile(File f){
		if(f==null){
			return null;
		}
		try {
			FileInputStream stream =new FileInputStream(f);//初始化文件输入流
			ByteArrayOutputStream out=new ByteArrayOutputStream(100);//初始化字节数组输出流
			byte[] b=new byte[1000];
			int n;
			while((n=stream.read(b))!=-1)
				out.write(b,0,n);//把字节数组写入到输出流
			stream.close();
			out.close();
			return out.toByteArray();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	/**
	 * 返回客户端提示语句
	 * @param s 要返回的提示语句
	 * @param isScript 语句是否是脚本 false为普通文本，true为javascript脚本
	 */
			
	public static void ajaxMessage(String s,boolean isScript){
		HttpServletResponse response = ServletActionContext.getResponse();
		String message=null;
		if(isScript==false){
			message="<html><body><div style='color:red;font-size:14px;font-weight:boleder;'>"+s+"</div></body></html>";
		}else{
			message="<html><script type='text/javascript'>alert('"+s+"');</script></html>";
		}
		response.setContentType("text/html;charset=UTF-8");
		try {
			response.getWriter().write(message);
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
}

package com.qllt.service;

import java.util.List;

import com.qllt.dao.AdminDAO;
import com.qllt.po.Admin;
import com.qllt.util.MD5;

public class AdminServiceImpl implements AdminService{
	private AdminDAO adminDAO;
	
	public void setAdminDAO(AdminDAO adminDAO) {
		this.adminDAO = adminDAO;
	}
	//添加管理员
	public boolean addAdmin(Admin admin){
		String adminName=admin.getAdminName();
		if(adminDAO.queryByAdminName(adminName)==null){
			adminDAO.save(admin);
			return true;
		}else{
			return false;
		}
	}
	//修改管理员
	public boolean updateAdmin(Admin admin){
		if(admin==null){
			return false;
		}else{
			adminDAO.updateAdmin(admin);
			return true; 
		}
	}
	//删除
	public boolean deleteAdmin(int adminID){
		Admin admin=queryAdminByID(adminID);
		adminDAO.deleteAdmin(admin);
		if(queryAdminByID(adminID)==null){
			return true;
		}else{
			return false;
		}
	}
	//根据adminID查询
	public Admin queryAdminByID(int adminID){
		Admin admin=adminDAO.queryByAdminID(adminID);
		return admin;
	}
	//根据adminNamec查询
	public Admin queryAdminByAdminName(String adminName){
		Admin admin=adminDAO.queryByAdminName(adminName);
		System.out.println(admin.getSex()+"  "+admin.getAdminName());
		return admin;
	}
	//查看所有管理员
	public List<Admin> queryAllAdmin(){
		List<Admin> list=adminDAO.queryAll();
		return list;
	}
	//判断登录
	public boolean isLogin(Admin admin){
		Admin query_admin=adminDAO.queryByAdminName(admin.getAdminName());
		if(query_admin==null){
			return false;
		}
		
		else{
			String query_password=query_admin.getAdminPassword();
			if(admin.getAdminPassword().equals(query_password)){
				if(query_admin.getAdminGroup().getAgName().equals("冻结组")){
					return false;
				}
				return true;
			}
			return false;
		}
	}
}

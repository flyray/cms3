package com.qllt.service;

import java.util.List;

import com.qllt.po.SubMenu;

public interface SubMenuService {

	//添加
	public abstract boolean addSubMenu(SubMenu subMenu);

	//删除
	public abstract boolean deleteSubMenu(int subMenuID);

	//修改
	public abstract boolean updateSubMenu(SubMenu subMenu);

	//根据ID查询
	public abstract SubMenu queryBySubMenuID(int subMenuID);

	//查询所有
	public abstract List<SubMenu> queryAllSubMenu();

}
package com.qllt.service;

import java.util.Date;
import java.util.List;

import com.qllt.dao.AdminDAO;
import com.qllt.dao.NewsDAO;
import com.qllt.po.Admin;
import com.qllt.po.News;
import com.qllt.util.Page;
import com.qllt.util.PageUtil;
import com.qllt.util.Result;

public class NewsServiceImpl implements NewsService {
	private NewsDAO newsDAO;
	private AdminDAO adminDAO;
	public void setNewsDAO(NewsDAO newsDAO) {
		this.newsDAO = newsDAO;
	}
	

	public void setAdminDAO(AdminDAO adminDAO) {
		this.adminDAO = adminDAO;
	}
	
	
	//统计功能用到的三个方法
		public String checkNewsAndPosition(String start_time,String end_time,List<Integer> news_number_list,List<Integer> news_number_list_byauthor){
			newsDAO.checkNewsAndPosition(start_time, end_time, news_number_list,news_number_list_byauthor);	
			return "checkNewsAndPosition_s";
		}
		
		public String checkNewsAndPositionByAuthor(String author,String start_time,String end_time,List<Integer> news_number_list_byauthor,List<Integer> news_number_list){
			newsDAO.checkNewsAndPositionByAuthor(author, start_time, end_time, news_number_list_byauthor,news_number_list);		
			return "checkNewAndPositionByAuthor_s";
		}
		
		public String divideByWeek(String divide_year,List<String> divide_week_list,List<Integer> divide_number_list,List<String> divide_position_list){
			newsDAO.divideByWeek(divide_year, divide_week_list, divide_number_list, divide_position_list);
			
			return "divideByWeek_s";
		}

	//添加
	public boolean addNews(News news){
		Admin admin=adminDAO.queryByAdminName(news.getEditor().getAdminName());
		if(admin!=null){
			news.setEditor(admin);
			newsDAO.saveNews(news);
			return true;
		}
		return false;
	}
	//删除
	public boolean deleteNewsByID(int newsID){
		News news=newsDAO.queryByNewsID(newsID);
		if(news==null){
			return false;
		}else{
			newsDAO.deleteNews(news);
			return true;
		}
	}
	//修改
	public boolean updateNews(News news){
		Admin admin=adminDAO.queryByAdminName(news.getEditor().getAdminName());
		if(admin==null){
			return false;
		}else{
			news.setEditor(admin);
			newsDAO.updateNews(news);
			return true;
		}
	}
	//浏览新闻
	public News findNewsByID(int newsID){
		return newsDAO.queryByNewsID(newsID);
	}
	//高级搜索
	public Result advancedSearch(Page page,String keywords,String editorName,String content,String author,Date createtime,Date recrutTime,String starttime,String endtime,int recruitAddress,String source){
		page=PageUtil.createPage(page,newsDAO.queryCountAdvancedSearch(keywords,editorName,content,author,createtime,recrutTime,starttime,endtime,recruitAddress,source));
		List<News> newslist=newsDAO.queryAdvancedSearch(page,keywords,editorName,content,author,createtime,recrutTime,starttime,endtime,recruitAddress,source);
		Result result=new Result();
		result.setPage(page);
		result.setList(newslist);
		return result;
	}
	/**
	 * 分页查询关键字
	 * @param page
	 * @param keywords
	 * @return
	 */
	public Result findByKeyWords(Page page,String keywords){
		page=PageUtil.createPage(page,newsDAO.queryCountByKeywords(keywords));
		List<News> newslist=newsDAO.queryByKeywods(keywords, page);
		Result result=new Result();
		result.setPage(page);
		result.setList(newslist);
		return result;
	}
	/*
	 * 获得所有新闻
	 * @see com.qllt.service.NewsService#findAllNews(com.qllt.util.Page, int subItemID, int itemID)
	 */
	public Result findAllNews(Page page,int subItemID,int itemID){
		int count;
		List<News> newslist = null;
		if(itemID==0&&subItemID==0){//查询所有新闻
			count=newsDAO.queryNewsCount();
			page=PageUtil.createPage(page,count);
			newslist=newsDAO.queryNewsAll(page);
		}else if(itemID!=0&&subItemID==0){//按itemID查询新闻
			count=newsDAO.queryNewsCountByItemID(itemID);
			page=PageUtil.createPage(page,count);
			newslist=newsDAO.queryNewsByNewsItemID(itemID, page);
		}else{//subItem!=0按subItemID查询新闻
			count=newsDAO.queryNewsCountBySubItemID(subItemID);
			page=PageUtil.createPage(page,count);
			newslist=newsDAO.queryNewsByNewsSubItemID(subItemID, page);
		}
		Result result=new Result();
		result.setPage(page);
		result.setList(newslist);
		return result;
	}
	public News findBydate(Date date){
		return newsDAO.queryByDate(date);
	}
	public void setTop(int newsID,int settop){
		newsDAO.setTop(newsID, settop);
	}
	/**
	 * 查询每个分类下的新闻总数
	 * @return
	 */
	public int queryNewsCountByItemID(int itemID){
		return newsDAO.queryNewsCountByItemID(itemID);
	}

	public int queryNewsCountBySubItemID(int subItemID){
		return newsDAO.queryNewsCountBySubItemID(subItemID);
	}
	public int queryXnzpNewsCount(Date beginDate,Date endDate){
		return newsDAO.queryXnzpNewsCount(beginDate, endDate);
	}
	public List<News> queryXnzpNews(Page page,Date beginDate,Date endDate){
		return newsDAO.queryXnzpNews(page, beginDate, endDate);
	}
	/**
	 * 查询每个分类下所有新闻
	 * @return
	 */
	public List<News> queryNewsByNewsItemID(int itemID, Page page){
		return newsDAO.queryNewsByNewsItemID(itemID,page);
	}

	public List<News> queryNewsByNewsSubItemID(int subItemID, Page page){
		return newsDAO.queryNewsByNewsSubItemID(subItemID,page);
	}
	public int queryNewsCount(){
		return newsDAO.queryNewsCount();
	}
	//搜索
	public List<News> searchNews(String tip,Page page){
		return newsDAO.searchNews(tip, page);
	}
	/**
	 * 获取最新动态新闻
	 * @param newsNum 新闻条数
	 * @return
	 */
	public List<News> findRecentNewsList(int newsNum){
		return newsDAO.findRecentNewsList(newsNum);
	}
	/**
	 * 获取不同分类新闻list
	 * @param page 页数
	 * @param subItemID 
	 * @param itemID
	 * @return
	 */
	public Result findAllNewsList(Page page,int subItemID,int itemID){
		int count;
		List<News> newslist = null;
		if(itemID==0&&subItemID==0){//查询所有新闻
			count=newsDAO.queryNewsCount();
			page=PageUtil.createPage(page,count);
			newslist=newsDAO.queryNewsAllList(page);
		}else if(itemID!=0&&subItemID==0){//按itemID查询新闻
			count=newsDAO.queryNewsCountByItemID(itemID);
			page=PageUtil.createPage(page,count);
			newslist=newsDAO.queryNewsByNewsItemIDList(itemID, page);
		}else{//subItem!=0按subItemID查询新闻
			count=newsDAO.queryNewsCountBySubItemID(subItemID);
			page=PageUtil.createPage(page,count);
			newslist=newsDAO.queryNewsByNewsSubItemIDList(subItemID, page);
		}
		Result result=new Result();
		result.setPage(page);
		result.setList(newslist);
		return result;
	}
	/**
	 * 查询关键词，返回查询得到的新闻列表
	 * @param keywords
	 * @return
	 */
	public List<News> findNewsListByKeywords(String keywords){
		return newsDAO.findNewsListByKeywords(keywords);
	}
	/**
	 * 分页查询新闻list，返回news新闻列表
	 */
	public List<News> queryNewsListByNewsItemID(int itemID,Page page){
		return newsDAO.queryNewsListByNewsItemID(itemID, page);
	}
	public List<News> queryNewsListByNewsSubItemID(int subItemID,Page page){
		return newsDAO.queryNewsListByNewsSubItemID(subItemID, page);
	}
	public List<News> queryNewsListAll(Page page){
		return newsDAO.queryNewsAll(page);
	}
	
	
}

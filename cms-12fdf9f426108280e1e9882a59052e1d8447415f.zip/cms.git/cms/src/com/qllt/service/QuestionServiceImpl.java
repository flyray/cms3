package com.qllt.service;

import java.util.List;

import com.qllt.dao.QuestionDAO;
import com.qllt.po.Question;
import com.qllt.util.Page;
import com.qllt.util.PageUtil;
import com.qllt.util.Result;

public class QuestionServiceImpl implements QuestionService
{
	private QuestionDAO questionDAO;
	
	public void setQuestionDAO(QuestionDAO questionDAO) {
		this.questionDAO = questionDAO;
	}
	//添加
	public boolean addQuestion(Question question)
	{
			questionDAO.saveQuestion(question);
			return true;
	}
	//删除
	public boolean deleteQuestionByID(int questionID){
		Question question=questionDAO.queryByQuestionID(questionID);
		if(question==null)
		{
			return false;
		}
		else
		{
			questionDAO.deleteQuestion(question);
			return true;
		}
	}
	//修改
	public boolean updateQuestion(Question question)
	{
		questionDAO.updateQuestion(question);
		return true;
	}
	//浏览
	public Question findQuestionByID(int questionID)
	{
		return questionDAO.queryByQuestionID(questionID);
	}
	//分页查询所有提问
	public Result findAllQuestion(Page page)
	{
		int count;
		List<Question> list = null;
		count=questionDAO.queryQuestionCount();
		page=PageUtil.createPage(page,count);
		list=questionDAO.queryQuestionAll(page);
		Result result=new Result();
		result.setPage(page);
		result.setList(list);
		return result;
	}
	//分页查询所有未回复提问
	public Result findAllQuestion1(Page page)
	{
		int count;
		List<Question> list = null;
		count=questionDAO.queryNotShowQuestionCount();
		page=PageUtil.createPage(page,count);
		list=questionDAO.queryNotShowQuestion(page);
		Result result=new Result();
		result.setPage(page);
		result.setList(list);
		return result;
	}
	//不分页查询所有未回复提问
	public List<Question> findAllNotAnswer(){
		return questionDAO.queryAllNotAnswer();
	}
	//分页查询每个分类下所有提问(各部门)
	public Result findClassifyQuestion(Page page,String classify)
	{
		int count;
		List<Question> list = null;
		count=questionDAO.queryClassifyQuestionCount(classify);
		page=PageUtil.createPage(page,count);
		list=questionDAO.queryClassifyQuestion(page,classify);
		Result result=new Result();
		result.setPage(page);
		result.setList(list);
		return result;
	}
	//查询每个分类下未回复提问(各部门)
	public List<Question> findClassifyQuestionNot(String classify)
	{
		return questionDAO.queryClassifyQuestionNot(classify);
	}
	//分页查询每个分类下所有已回复提问(前台列表显示)
	public Result findClassifyQuestionYes(Page page,String classify)
	{
		int count;
		List<Question> list = null;
		count=questionDAO.queryClassifyQuestionCountYes(classify);
		page=PageUtil.createPage(page,count);
		list=questionDAO.queryClassifyQuestionYes(page,classify);
		Result result=new Result();
		result.setPage(page);
		result.setList(list);
		return result;
	}
	//查询需要显示的新闻的的数目
	public int queryShowCount(){
		return questionDAO.queryShowCount();
	}
	//分页查询需要显示的问答
	public List<Question> queryShowDetail(Page page){
		return questionDAO.queryShowDetail(page);
	}
	//查询所有需要显示的问答
	public List<Question> queryAllShow(){
		return questionDAO.queryAllShow();
	}
	
}


package com.qllt.service;

import java.util.List;
import com.qllt.dao.LogDAO;
import com.qllt.dao.LogDAOImpl;
import com.qllt.po.Log;
import com.qllt.po.AdminGroup;
import com.qllt.po.News;
import com.qllt.util.Page;
import com.qllt.util.PageUtil;
import com.qllt.util.Result;
public class LogServiceImpl implements LogService {
	private LogDAO logDAO;

	public void setLogDAO(LogDAO logdao) {
		this.logDAO = logdao;
	}
	public void add(Log log){
		logDAO.add(log);
	}
	
	public boolean delete(int logID){
		return logDAO.delete(logID);
	}
	
	//查询所有日志
	public Result queryAll(Page page){
		int count;
		List<Log> loglist = null;
		count=logDAO.queryLogCount();
		page=PageUtil.createPage(page,count);
		loglist=logDAO.queryAll(page);
		
		Result result=new Result();
		result.setPage(page);
		result.setList(loglist);
		return result;
	}
	//通过adminName查询日志
	public Result queryByAdminName(Page page,String adminName){
		int count;
		List<Log> loglist = null;
		count=logDAO.queryLogCountbyAdminName(adminName);
		page=PageUtil.createPage(page,count);
		loglist=logDAO.queryByAdminName(page,adminName);
		Result result=new Result();
		result.setPage(page);
		result.setList(loglist);
		return result;
	}

	//通过newsTitle查询日志
	public Result queryByNewsTitle(Page page,String newsTitle){
		int count;
		List<Log> loglist = null;
		count=logDAO.queryLogCountbyNewsTitle(newsTitle);
		page=PageUtil.createPage(page,count);
		loglist=logDAO.queryByNewsTitle(page,newsTitle);
		Result result=new Result();
		result.setPage(page);
		result.setList(loglist);
		return result;
	}
}

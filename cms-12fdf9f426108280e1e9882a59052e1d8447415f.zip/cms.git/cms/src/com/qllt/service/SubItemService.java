package com.qllt.service;

import java.util.List;

import com.qllt.dao.SubItemDAO;
import com.qllt.po.SubItem;

public interface SubItemService {

	public abstract void setSubItemDAO(SubItemDAO subItemDAO);

	//添加
	public abstract boolean addSubItem(SubItem subItem);

	//删除
	public abstract boolean deleteSubItemd(int subItemID);

	//修改
	public abstract boolean updateSubItem(SubItem subItem);

	//查看所有
	public abstract List<SubItem> findAllSubItem(int itemID);

	//查询单个
	public abstract SubItem findSubItemByID(int subItemID);
	public abstract List<SubItem> findAllSubItem();
}
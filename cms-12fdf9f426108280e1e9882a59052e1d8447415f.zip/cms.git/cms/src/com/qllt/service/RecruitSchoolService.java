package com.qllt.service;

import java.util.List;

import com.qllt.dao.RecruitSchoolDAO;
import com.qllt.po.RecruitSchool;

public interface RecruitSchoolService {

	public abstract RecruitSchoolDAO getRecruitSchoolDAO();

	public abstract void setRecruitSchoolDAO(RecruitSchoolDAO recruitSchoolDAO);

	/**
	 * 添加
	 * @param recruitSchool
	 */
	public abstract void add(RecruitSchool recruitSchool);

	/**
	 * 删除
	 * @param recruitSchool
	 */
	public abstract void delete(RecruitSchool recruitSchool);

	/**
	 * 更新
	 * @param recruitSchool
	 */
	public abstract void update(RecruitSchool recruitSchool);

	/**
	 * 查找
	 */
	public abstract void findAll(RecruitSchool recruitSchool);
	
	/**
	 * ajax查询所有校区
	 * @return
	 */
	public abstract List<RecruitSchool> findAllSchool();
	/**
	 * 根据招聘教室编号查询招聘校区
	 * @param recruitSchoolNum
	 * @return
	 */
	public abstract  RecruitSchool findRecruitSchoolByNum(int recruitSchoolNum);
}


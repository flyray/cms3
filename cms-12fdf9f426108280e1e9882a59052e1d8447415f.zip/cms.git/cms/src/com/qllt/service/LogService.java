package com.qllt.service;

import java.util.List;

import com.qllt.dao.LogDAO;
import com.qllt.po.Log;
import com.qllt.util.Page;
import com.qllt.util.Result;

public interface LogService {

	public abstract void setLogDAO(LogDAO logdao);

	public abstract void add(Log log);

	public abstract boolean delete(int logID);

	//查询所有日志
	public abstract Result queryAll(Page page);

	//通过adminName查询日志
	public abstract Result queryByAdminName(Page page,String adminName);

	//通过newsTitle查询日志
	public abstract Result queryByNewsTitle(Page page,String newsTitle);

}
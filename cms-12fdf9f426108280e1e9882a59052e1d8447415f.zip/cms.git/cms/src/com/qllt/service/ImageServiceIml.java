package com.qllt.service;

import java.util.List;

import com.qllt.dao.ImageDAO;
import com.qllt.po.Image;
import com.qllt.util.Page;
import com.qllt.util.PageUtil;
import com.qllt.util.Result;

public class ImageServiceIml implements ImageService {
	private ImageDAO imageDAO;

	public void setImageDAO(ImageDAO imageDAO) {
		this.imageDAO = imageDAO;
	}
	public boolean addImage(Image image){
		imageDAO.save(image);
		return true;
	}
	public boolean deleteImage(int imageID){
		Image image=findImageByID(imageID);
		imageDAO.delete(image);
		if(findImageByID(imageID)==null){
			return true;
		}else{
			return false;
		}
	}
	public Image findImageByID(int imageID){
		Image image;
		image=imageDAO.queryByID(imageID);
		return image;
	}
	public boolean updateImage(Image image){
		imageDAO.updateImage(image);
		return true;
	}
	public Result findAllImage(Page page,int imageType){
		List imageList=imageDAO.queryAllImage(page,imageType);
		page=PageUtil.createPage(page, imageDAO.queryImageCount(imageType));
		Result result =new Result();
		result.setList(imageList);
		result.setPage(page);
		return result;
	}
	
}

package com.qllt.service;

import java.util.Date;
import java.util.List;

import com.qllt.dao.AdminDAO;
import com.qllt.dao.NewsDAO;
import com.qllt.po.News;
import com.qllt.util.Page;
import com.qllt.util.Result;

public interface NewsService {

	public abstract void setNewsDAO(NewsDAO newsDAO);

	public abstract void setAdminDAO(AdminDAO adminDAO);

	//添加
	public abstract boolean addNews(News news);

	//删除
	public abstract boolean deleteNewsByID(int newsID);

	//修改
	public abstract boolean updateNews(News news);

	//浏览新闻
	public abstract News findNewsByID(int newsID);

	/**
	 * 分页查询关键字
	 * @param page
	 * @param keywords
	 * @return
	 */
	public abstract Result findByKeyWords(Page page, String keywords);
	
	//高级搜索
	public abstract Result advancedSearch(Page zpage,String keywords,String editorName,String content,String author,Date createtime,Date recrutTime,String starttime,String endtime,int recruitAddress,String source);

	/*
	 * 获得所有新闻
	 * @see com.qllt.service.NewsService#findAllNews(com.qllt.util.Page, int subItemID, int itemID)
	 */
	public abstract Result findAllNews(Page page, int subItemID, int itemID);

	public abstract News findBydate(Date date);

	public abstract void setTop(int newsID, int settop);
	/**
	 * 查询每个分类下的新闻总数
	 * @return
	 */
	public abstract int queryNewsCountByItemID(int itemID);

	public abstract int queryNewsCountBySubItemID(int subItemID);
	
	/**
	 * 查询校内招聘一周内的新闻数量
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	public abstract int queryXnzpNewsCount(Date beginDate,Date endDate);
	/**
	 * 查询校内招聘一周内的新闻
	 * @param page
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	public abstract List<News> queryXnzpNews(Page page,Date beginDate,Date endDate);
	/**
	 * 查询每个分类下所有新闻
	 * @return
	 */
	public abstract List<News> queryNewsByNewsItemID(int itemID, Page page);

	public abstract List<News> queryNewsByNewsSubItemID(int subItemID, Page page);
	
	//统计功能用到的三个方法
	public abstract String checkNewsAndPosition(String start_time,String end_time,List<Integer> news_number_list,List<Integer> news_number_list_byauthor);

	public abstract String checkNewsAndPositionByAuthor(String author,String start_time,String end_time,List<Integer> news_number_list_byauthor,List<Integer> news_number_list);
	
	public abstract String divideByWeek(String divide_year,List<String> divide_week_list,List<Integer> divide_number_list,List<String> divide_position_list);
	public abstract int queryNewsCount();
	
	/**
	 * 搜索
	 */
	public abstract List<News> searchNews(String tip,Page page);
	/**
	 * 获取最新动态新闻
	 * @param newsNum
	 * @return
	 */
	public abstract List<News> findRecentNewsList(int newsNum);
	/**
	 * 分类查询新闻列表
	 * @param page
	 * @param subItemID
	 * @param itemID
	 * @return
	 */
	public abstract Result findAllNewsList(Page page,int subItemID,int itemID);
	/**
	 * 查询关键词，返回查询得到的新闻列表
	 * @param keywords
	 * @return
	 */
	public abstract List<News> findNewsListByKeywords(String keywords);
	
	/**
	 * 分页查询新闻list，返回news新闻列表
	 */
	public abstract List<News> queryNewsListByNewsItemID(int itemID,Page page);
	public abstract List<News> queryNewsListByNewsSubItemID(int subItemID,Page page);
	public abstract List<News> queryNewsListAll(Page page);
	
}
package com.qllt.service;

import java.util.List;

import com.qllt.dao.RecruitRoomDAO;
import com.qllt.po.RecruitRoom;
import com.qllt.po.RecruitSchool;

public class RecruitRoomServiceImpl implements RecruitRoomService {
	private RecruitRoomDAO recruitRoomDAO;

	public RecruitRoomDAO getRecruitRoomDAO() {
		return recruitRoomDAO;
	}

	public void setRecruitRoomDAO(RecruitRoomDAO recruitRoomDAO) {
		this.recruitRoomDAO = recruitRoomDAO;
	}
	/**
	 * 添加
	 * @param recruitSchool
	 */
	public void add(RecruitRoom recruitRoom){
		recruitRoomDAO.add(recruitRoom);
	}
	/**
	 * 删除
	 * @param recruitSchool
	 */
	public void delete(RecruitRoom recruitRoom){
		recruitRoomDAO.delete(recruitRoom);
	}
	/**
	 * 更新
	 * @param recruitSchool
	 */
	public void update(RecruitRoom recruitRoom){
		recruitRoomDAO.update(recruitRoom);
	}
	/**
	 * 查找
	 */
	public void findAll(RecruitRoom recruitRoom){
		recruitRoomDAO.findAll(recruitRoom);	
	}
	/**
	 * ajax各校区查询所有教室
	 */
	public List<RecruitRoom> findAllRoom(int recruitSchoolNum){
		return recruitRoomDAO.findAllRoom(recruitSchoolNum);
	}
	
	public RecruitRoom findRecruitRoomByID(int recruitRoomID){
		
		return recruitRoomDAO.findRecruitRoomByID(recruitRoomID);
	}
	
}

package com.qllt.service;


import java.util.List;

import com.qllt.dao.SubMenuDAO;
import com.qllt.po.SubMenu;

public class SubMenuServiceImpl implements SubMenuService  {
	private SubMenuDAO subMenuDAO;
	
	//添加
	public boolean addSubMenu(SubMenu subMenu){
		String subMenuName=subMenu.getSubMenuName();
		if(subMenuDAO.queryByName(subMenuName)==null){
			subMenuDAO.save(subMenu);
			return true;
		}else{
			return false;
		}
	}
	//删除
	public boolean deleteSubMenu(int subMenuID){
		SubMenu subMenu=queryBySubMenuID(subMenuID);
		subMenuDAO.delete(subMenu);
		if(queryBySubMenuID(subMenuID)==null){
			return true;
		}else{
			return false;
		}
	}
	
	//修改
	public boolean updateSubMenu(SubMenu subMenu){
		if(subMenu==null){
			return false;
		}else{
			subMenuDAO.update(subMenu);
			return true;
		}
	}
	
	//根据ID查询
	public SubMenu queryBySubMenuID(int subMenuID){
		return subMenuDAO.queryByID(subMenuID);
	}
	
	//查询所有
	public List<SubMenu> queryAllSubMenu(){
		List<SubMenu> list=subMenuDAO.queryAll();
		return list;
	}
	public void setSubMenuDAO(SubMenuDAO subMenuDAO) {
		this.subMenuDAO = subMenuDAO;
	}
	
}

package com.qllt.service;

import java.util.List;

import com.qllt.dao.AdminDAO;
import com.qllt.po.Admin;

public interface AdminService {

	public abstract void setAdminDAO(AdminDAO adminDAO);

	//添加管理员
	public abstract boolean addAdmin(Admin admin);

	//修改管理员
	public abstract boolean updateAdmin(Admin admin);

	//删除
	public abstract boolean deleteAdmin(int adminID);

	//根据adminID查询
	public abstract Admin queryAdminByID(int adminID);

	//根据adminNamec查询
	public abstract Admin queryAdminByAdminName(String adminName);
	//查看所有管理员
	public abstract List<Admin> queryAllAdmin();

	public abstract boolean isLogin(Admin admin);
}
package com.qllt.service;

import java.util.List;

import com.qllt.dao.MenuDAO;
import com.qllt.po.Menu;

public interface MenuService {

	public abstract void setMenuDAO(MenuDAO menuDAO);

	//添加
	public abstract boolean addMenu(Menu menu);

	//删除
	public abstract boolean deleteMenu(int menuID);

	//修改
	public abstract boolean updateMenu(Menu menu);

	//根据ID查询
	public abstract Menu queryByMenuID(int menuID);

	//查询所有
	public abstract List<Menu> queryAllMenu();

}
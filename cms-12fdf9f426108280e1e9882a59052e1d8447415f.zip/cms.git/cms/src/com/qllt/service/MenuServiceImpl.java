package com.qllt.service;


import java.util.List;

import com.qllt.dao.MenuDAO;
import com.qllt.po.Menu;

public class MenuServiceImpl implements MenuService {
	private MenuDAO menuDAO;

	public void setMenuDAO(MenuDAO menuDAO) {
		this.menuDAO = menuDAO;
	}
	
	//添加
	public boolean addMenu(Menu menu){
		String menuName=menu.getMenuName();
		if(menuDAO.queryByName(menuName)==null){
			menuDAO.save(menu);
			return true;
		}else{
			return false;
		}
	}
	//删除
	public boolean deleteMenu(int menuID){
		Menu menu=queryByMenuID(menuID);
		menuDAO.delete(menu);
		if(queryByMenuID(menuID)==null){
			return true;
		}else{
			return false;
		}
	}
	
	//修改
	public boolean updateMenu(Menu menu){
		if(menu==null){
			return false;
		}else{
			menuDAO.update(menu);
			return true;
		}
	}
	
	//根据ID查询
	public Menu queryByMenuID(int menuID){
		return menuDAO.queryByID(menuID);
	}
	
	//查询所有
	public List<Menu> queryAllMenu(){
		List<Menu> list=menuDAO.queryAll();
		return list;
	}
}

package com.qllt.service;

import java.util.List;

import com.qllt.dao.SubItemDAO;
import com.qllt.po.SubItem;

public class SubItemServiceImpl implements SubItemService {
	private SubItemDAO subItemDAO;
	public void setSubItemDAO(SubItemDAO subItemDAO) {
		this.subItemDAO = subItemDAO;
	}
	//添加
	public boolean addSubItem(SubItem subItem){
		String subItemName=subItem.getSubItemName();
		if(subItemDAO.querySubItemByName(subItemName)==null){
			subItemDAO.saveSubItem(subItem);
			return true;
		}
		return false;
	}
	//删除
	public boolean deleteSubItemd(int subItemID){
		SubItem subItem=subItemDAO.querySubItemByID(subItemID);
		if(subItem==null){
			return false;
		}else{
			subItemDAO.deleteSubItem(subItem);
			return true;
		}
	}
	//修改
	public boolean updateSubItem(SubItem subItem){
		subItemDAO.updateSubItem(subItem);
		return true;
	}
	//查看所有
	public List<SubItem> findAllSubItem(int itemID){
		return subItemDAO.queryAllSubItem(itemID);
	}
	//查询单个
	public  SubItem findSubItemByID(int subItemID){
		SubItem subItem=subItemDAO.querySubItemByID(subItemID);
		return subItem;
	}
	public List<SubItem> findAllSubItem(){
		return subItemDAO.queryAllSubItem();
	}
	
}

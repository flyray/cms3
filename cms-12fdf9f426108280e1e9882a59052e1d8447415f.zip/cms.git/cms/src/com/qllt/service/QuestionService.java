package com.qllt.service;

import java.util.List;

import com.qllt.dao.QuestionDAO;
import com.qllt.po.Question;
import com.qllt.util.Page;
import com.qllt.util.Result;

public interface QuestionService {

	public abstract void setQuestionDAO(QuestionDAO questionDAO);
	//添加
	public abstract boolean addQuestion(Question question);

	//删除
	public abstract boolean deleteQuestionByID(int questionID);

	//修改
	public abstract boolean updateQuestion(Question question);

	//浏览
	public abstract Question findQuestionByID(int questionID);

	//分页查询所有提问
	public abstract Result findAllQuestion(Page page);

	//分页查询所有未回复提问
	public abstract Result findAllQuestion1(Page page);
	
	//分页查询每个分类下所有提问(各部门)
	public abstract Result findClassifyQuestion(Page page,String classify);
	
	//查询每个分类下未回复提问(各部门)
	public abstract List<Question> findClassifyQuestionNot(String classify);
	
	//分页查询每个分类下所有已回复提问(前台列表显示)
	public abstract Result findClassifyQuestionYes(Page page,String classify);
	
	//查询需要显示的新闻的的数目
	public abstract int queryShowCount();
	
	//查询需要显示的问答
	public abstract List<Question> queryShowDetail(Page page);
	
	//查询所有需要显示的问答
	public abstract List<Question> queryAllShow();
	
	//不分页查询所有未回复提问
	public abstract List<Question> findAllNotAnswer();
}
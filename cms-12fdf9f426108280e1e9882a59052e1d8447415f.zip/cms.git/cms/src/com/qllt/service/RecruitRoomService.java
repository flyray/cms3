package com.qllt.service;

import java.util.List;

import com.qllt.dao.RecruitRoomDAO;
import com.qllt.po.RecruitRoom;

public interface RecruitRoomService {

	public abstract RecruitRoomDAO getRecruitRoomDAO();

	public abstract void setRecruitRoomDAO(RecruitRoomDAO recruitRoomDAO);

	/**
	 * 添加
	 * @param recruitSchool
	 */
	public abstract void add(RecruitRoom recruitRoom);

	/**
	 * 删除
	 * @param recruitSchool
	 */
	public abstract void delete(RecruitRoom recruitRoom);

	/**
	 * 更新
	 * @param recruitSchool
	 */
	public abstract void update(RecruitRoom recruitRoom);

	/**
	 * 查找
	 */
	public void findAll(RecruitRoom recruitRoom);
	/**
	 * ajax查询各校区所有教室信息
	 * 
	 */
	public abstract List<RecruitRoom> findAllRoom(int recruitSchoolNum);
	
	/**
	 * 按照recruitRoomID 查询
	 */
	public abstract RecruitRoom findRecruitRoomByID(int recruitRoomID);
	
	
}
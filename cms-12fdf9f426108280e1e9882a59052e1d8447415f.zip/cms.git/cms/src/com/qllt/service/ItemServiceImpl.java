package com.qllt.service;

import java.util.List;

import com.qllt.dao.ItemDAO;
import com.qllt.dao.SubItemDAO;
import com.qllt.po.Item;


public class ItemServiceImpl implements ItemService {
	private ItemDAO itemDAO;
	private SubItemDAO subItemDAO;
	
	public void setSubItemDAO(SubItemDAO subItemDAO) {
		this.subItemDAO = subItemDAO;
	}
	public void setItemDAO(ItemDAO itemDAO) {
		this.itemDAO = itemDAO;
	}
	//添加
	public boolean addItem(Item item){
		String itemName=item.getItemName();
		if(itemDAO.queryItemByName(itemName)==null){
			itemDAO.saveItem(item);
			return true;
		}
		return false;
	}
	//删除
	public boolean deleteItemByID(int itemID){
		Item item=itemDAO.queryByItemID(itemID);
		if(item==null){
			return false;
		}else{
			itemDAO.deleteItem(item);
			return true;
		}
	}
	//修改
	public boolean updateItem(Item item){
		itemDAO.updateItem(item);
		return true;
	}
	//查看所有栏目
	public List<Item> findAllItem(){
		return itemDAO.queryAllItem();
	}
	//根据itemID查询
	public Item findItemByItemID(int itemID){
		Item item;
		item=itemDAO.queryByItemID(itemID);
		return item;
	}
}

package com.qllt.service;

import java.util.List;

import com.qllt.dao.AdminGroupDAO;
import com.qllt.po.AdminGroup;

public class AdminGroupServiceImpl implements AdminGroupService {
	private AdminGroupDAO adminGroupDAO;
	public void setAdminGroupDAO(AdminGroupDAO adminGroupDAO) {
		this.adminGroupDAO = adminGroupDAO;
	}
	
	
	public void add(AdminGroup adminGroup){
		adminGroupDAO.add(adminGroup);
	}
	
	public void update(AdminGroup adminGroup){
		adminGroupDAO.update(adminGroup);
	}
	
	public void delete(AdminGroup adminGroup){
		adminGroupDAO.delete(adminGroup);
	}
	public List<AdminGroup> findAll(){
		return adminGroupDAO.queryAll();
	}
	public AdminGroup findByID(int gid){
		return adminGroupDAO.queryByID(gid);
	}
	
}

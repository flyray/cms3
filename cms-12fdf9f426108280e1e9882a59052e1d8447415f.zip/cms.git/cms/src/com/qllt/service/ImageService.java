package com.qllt.service;

import com.qllt.dao.ImageDAO;
import com.qllt.po.Image;
import com.qllt.util.Page;
import com.qllt.util.Result;

public interface ImageService {

	public abstract void setImageDAO(ImageDAO imageDAO);

	public abstract boolean addImage(Image image);

	public abstract boolean deleteImage(int imageID);

	public abstract Image findImageByID(int imageID);

	public abstract boolean updateImage(Image image);
	public abstract Result findAllImage(Page page,int imageType);
}
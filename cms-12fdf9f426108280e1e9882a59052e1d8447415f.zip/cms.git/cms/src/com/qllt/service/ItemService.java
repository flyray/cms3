package com.qllt.service;

import java.util.List;

import com.qllt.dao.ItemDAO;
import com.qllt.dao.SubItemDAO;
import com.qllt.po.Item;

public interface ItemService {

	public abstract void setSubItemDAO(SubItemDAO subItemDAO);

	public abstract void setItemDAO(ItemDAO itemDAO);

	//添加
	public abstract boolean addItem(Item item);

	//删除
	public abstract boolean deleteItemByID(int itemID);

	//修改
	public abstract boolean updateItem(Item item);

	//查看所有栏目
	public abstract List<Item> findAllItem();

	//根据itemID查询
	public abstract Item findItemByItemID(int itemID);

}
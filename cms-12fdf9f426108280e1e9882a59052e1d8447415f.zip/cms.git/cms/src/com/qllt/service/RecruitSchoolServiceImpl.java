package com.qllt.service;

import java.util.List;

import com.qllt.dao.RecruitSchoolDAO;
import com.qllt.po.RecruitRoom;
import com.qllt.po.RecruitSchool;

public class RecruitSchoolServiceImpl implements RecruitSchoolService {
	private RecruitSchoolDAO recruitSchoolDAO;
	
	public RecruitSchoolDAO getRecruitSchoolDAO() {
		return recruitSchoolDAO;
	}

	public void setRecruitSchoolDAO(RecruitSchoolDAO recruitSchoolDAO) {
		this.recruitSchoolDAO = recruitSchoolDAO;
	}
	/**
	 * 添加
	 * @param recruitSchool
	 */
	public void add(RecruitSchool recruitSchool){
		recruitSchoolDAO.add(recruitSchool);
	}
	/**
	 * 删除
	 * @param recruitSchool
	 */
	public void delete(RecruitSchool recruitSchool){
		recruitSchoolDAO.delete(recruitSchool);
	}
	/**
	 * 更新
	 * @param recruitSchool
	 */
	public void update(RecruitSchool recruitSchool){
		recruitSchoolDAO.update(recruitSchool);
	}
	/**
	 * 查找
	 * @param recruitSchoolNum
	 * @return
	 */
	public void findAll(RecruitSchool recruitSchool){
		recruitSchoolDAO.findAll(recruitSchool);	
	}
	/**
	 * ajax查询所有校区
	 */
	public List<RecruitSchool> findAllSchool(){
		return recruitSchoolDAO.findAllSchool();
	}
	/**
	 * 根据招聘校区编号查询招聘校区
	 * @param recruitSchoolNum
	 * @return
	 */
	public RecruitSchool findRecruitSchoolByNum(int recruitSchoolNum){
		RecruitSchool recruitSchool=recruitSchoolDAO.findRecruitSchoolByNum(recruitSchoolNum);
		return recruitSchool;
	
	}
}

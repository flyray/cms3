package com.qllt.service;

import java.util.List;

import com.qllt.dao.AdminGroupDAO;
import com.qllt.po.AdminGroup;

public interface AdminGroupService {

	public abstract void setAdminGroupDAO(AdminGroupDAO adminGroupDAO);

	public abstract void add(AdminGroup adminGroup);

	public abstract void update(AdminGroup adminGroup);

	public abstract void delete(AdminGroup adminGroup);

	public abstract List<AdminGroup> findAll();
	public abstract AdminGroup findByID(int gid);
}
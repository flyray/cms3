//Nav导航
$(function(){
	/*2013-10-3之前的导航效果
	$(".nav li").hover(function(){
		$(this).find("dl").show().parent().siblings().find("dl").hide();
	},function(){
		$(this).find("dl").hide();
	});
	*/
	//2013-10-3之后的导航效果
	/*
	$('li.mainlevel').mousemove(function(){
		  $(this).find('ul').slideDown();//you can give it a speed
		  });
		  $('li.mainlevel').mouseleave(function(){
		  $(this).find('ul').slideUp("fast");
		  });
		  */
	//2013-10-4之后的导航效果
	$(function(){		   
		//头页登录
		$("#nav > li").hover(function(){$(this).addClass("navmoon")},function(){$(this).removeClass("navmoon")})
		var maxwidth = 580;
		$(".news_text img").each(function(){
		  if ($(this).width() > maxwidth) {
		   $(this).width(maxwidth);}
		   }); 
		}); 
		function $tomato(id) {
			return document.getElementById(id);
		}
		function runCode(obj) {
			var winname = window.open('', "_blank", '');
			winname.document.open('text/html', 'replace');
			winname.document.writeln(obj.value);
			winname.document.close();
		}


		(function($){
		    $.fn.capacityFixed = function(options) {
		        var opts = $.extend({},$.fn.capacityFixed.deflunt,options);
		        var FixedFun = function(element) {
		            var top = opts.top;
		            element.css({
		                "top":top
		            });
		            $(window).scroll(function() {
		                var scrolls = $(this).scrollTop();
		                if (scrolls > top) {

		                    if (window.XMLHttpRequest) {
		                        element.css({
		                            position: "fixed",
		                            top: 0							
		                        });
		                    } else {
		                        element.css({
		                            top: scrolls
		                        });
		                    }
		                }else {
		                    element.css({
		                        position: "absolute",
		                        top: top
		                    });
		                }
		            });
		            element.find(".close-ico").click(function(event){
		                element.remove();
		                event.preventDefault();
		            })
		        };
		        return $(this).each(function() {
		            FixedFun($(this));
		        });
		    };
		    $.fn.capacityFixed.deflunt={
				right : 0,//相对于页面宽度的右边定位
		        top:95
			};
		})(jQuery);
	//火箭
	$("#goTopBtn").click(function(){
		   //var sc=$(window).scrollTop();
		   $('body,html').animate({scrollTop:$("#nav_back").offset().top},500);
	}); 
});
$(window).scroll(function(){
    var sc=$(window).scrollTop()-300;
    var rwidth=$(window).width()
        if(sc>0){
   $("#goTopBtn").css("display","block");
   $("#goTopBtn").css("left",(rwidth-160)+"px")
   }else{
  $("#goTopBtn").css("display","none");
   }
   });

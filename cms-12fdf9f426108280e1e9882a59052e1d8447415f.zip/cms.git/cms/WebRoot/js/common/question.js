function checkit()
{
	if(document.form1.title.value.length>20||document.form1.title.value=="")
	{
		alert("条件不符，请检查");
		document.form1.title.focus();
		return false;
	}
	else if(document.form1.content.value.length>100||document.form1.content.value=="")
	{
		alert("条件不符，请检查");
		document.form1.content.focus();
		return false;
	}
	else if(document.form1.name.value.length>20||document.form1.name.value=="")
	{
		alert("条件不符，请检查");
		document.form1.name.focus();
		return false;
	}
	else if(!checkemail(document.form1.email.value)||document.form1.email.value=="")
	{
		alert("邮箱格式不正确，请检查");
		document.form1.content.focus();
		return false;
	}
	else if(!checkphone(document.form1.phone.value)||document.form1.phone.value==""){
		alert("手机号码格式不正确，请检查");
		document.form1.content.focus();
		return false;
	}
	else
	{
		return true;
	}
}
function check()
{
	if(document.form1.title.value.length>20)
	{
		document.getElementById("titlex").style.display="";
		document.form1.title.focus();
	}
	else
	{
		document.getElementById("titlex").style.display="none";
	}
	
	if(document.form1.content.value.length>100)
	{
		document.getElementById("contentx").style.display="";
		document.form1.content.focus();
	}
	else
	{
		document.getElementById("contentx").style.display="none";
	}
	
	if(document.form1.name.value.length>20)
	{
		document.getElementById("namex").style.display=""; 
		document.form1.content.focus();
	}
	else
	{
		document.getElementById("namex").style.display="none"; 
	}
}
function checkel()
{
	if(!checkemail(document.form1.email.value))
	{
		document.getElementById("emailx").style.display=""; 
		document.form1.content.focus();
	}
	else
	{
		document.getElementById("emailx").style.display="none"; 
	}
}
function checkemail(email)
{ 
	var remail= /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/; 
	return(remail.test(email));
}
function checkphone(phone){
	
	var rephone =/^1[3,5,8]{1}[0-9]{1}[0-9]{8}$/;
	
	return (rephone.test(phone));
}
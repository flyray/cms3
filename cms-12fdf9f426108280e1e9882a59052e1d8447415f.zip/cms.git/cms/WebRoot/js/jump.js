function jump(){
	var h = window.location.href;
	var strs= new Array(); //定义一数组存放第一次按照"-"分割之后的字符串
	var srts2 = new Array();//定义另一数组，用来存放第二次按照“.”分割之后的字符串
	

    strs=h.split("-"); //字符分割    
	strs2 = strs[1].split(".");
	
	var realHREF = strs[0]+"-"+document.getElementById("rb_search").value+".html";
	location.href=realHREF;	
}
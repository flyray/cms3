
$(function(){
	var $imgrolls=$("#jnBrandTab li a");
	var len=$imgrolls.length;
	var index=0;
	var autoRun=null;
	$imgrolls.click(function(){
		$(this).parent().css("opacity","0.3").siblings().css("opacity","0.7");
		index=$imgrolls.index(this);
		showImg(index);
	}).eq(0).click();
	
	
	//鼠标滑入，停止动画
	$("#jnBrand").hover(function(){
		if(autoRun){
			clearInterval(autoRun);
	}
	},function(){
			autoRun=setInterval(function(){
				showImg(index);
				index++;
				if(index==len){index=0;}
			},4000);
	}).trigger("mouseleave");
	
//tab选项页
	$(".tab_t_li1").css("color","#c7000a");
	$(".tab_title li").hover(function(){
			var tb_index=$(".tab_title li").index(this);
			$(".tab div").eq(tb_index).show().siblings("div").hide();
			$(this).css("color","#c7000a").css("opacity","0.8").siblings("li").css("color","#434343").css("opacity","1");
	},function(){
		$(this).css("opacity","1");
	});
	
//图片滑动
	 $("#slide_img").jCarouselLite({
        btnNext: ".slide_rig_btn",
        btnPrev: ".slide_left_btn",
        speed: 400
    });
	
//foot table变化
	$(".tab_ft_li2").css("color","#c7000a");
	$("#tabfoot_tit li").hover(function(){
			var tba_index=$("#tabfoot_tit li").index(this);
			$("#tab_foot div").eq(tba_index).show().siblings("div").hide();
			$(this).css("color","#c7000a").css("opacity","0.8").siblings("li").css("color","#434343").css("opacity","1");
	},function(){
		$(this).css("opacity","1");
	});
//-------
});
//显示不同的模块
function showImg(index){
	$("#jnBrandTab li a").eq(index).parent().css("opacity","0.3").siblings().css("opacity","0.7");
	var $rollobj = $("#jnBrandList");
    var rollWidth = $rollobj.find("li").outerWidth();
	rollWidth = rollWidth * 1; //一个版面的宽度
	$rollobj.stop(true,false).animate({ left : -rollWidth*index},1000);
	index++;
}


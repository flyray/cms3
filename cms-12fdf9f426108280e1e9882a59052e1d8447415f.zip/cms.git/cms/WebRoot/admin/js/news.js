function newsFind(newsID){
	$.ajax({
		type:'GET',
		url:'news_findAjax',
		proccess:true,
		datatype:'json',
		data:'newsID='+newsID,
		success:function(result){
			var json = eval('(' + result + ')');
			$("#div_detail").show();
			$("#n_title").text(json.title);
			$("#n_atrname").text(json.atrname);
			$("#n_newsType").text(json.newsType);
			$("#n_content").html(json.content);
			$("#n_hasread").text(json.hasread+"/"+json.hasrepeat);
			$("#n_settop").text(json.settop);
			$("#n_sethot").text(json.sethot);
			$("#n_createtime").text(json.createtime);
		}
		
	});
}
function shouqi(){
	$("#div_detail").hide();
}
function newsFind2(newsID){
	$.ajax({
		type:'GET',
		url:'item_find',
		proccess:true,
		datatype:'json',
		data:'newsID='+newsID,
		success:function(result){
			var json = eval('(' + result + ')');
			var ipt_newsID="<input type='hidden' name='newsID'/>";
			if($("input[name='newsID']").length<=0){$("#form1").append(ipt_newsID);}
			$("input[name='newsID']").val(newsID);
			$("input[name='itemName']").val(json.itemName);
			$("input[name='itemDescription']").val(json.itemDescription);
			$("input[name='order']").val(json.order);
			$("input[name='username']").val(json.username);
			$("select[name='hot']").val(json.hot);
			$("#sbt").val("修改");
			$("#ac_title").text("修改");
			$("#spnan_h").show();
			$("#form1").attr("action","item_update");
		}
		
	});
}
function returnAdd(){
	$("input[name='newsID']").remove();
	$("#sbt").val("添加");
	$("#ac_title").text("添加");
	$("#form1").attr("action","item_add");
	$("#spnan_h").hide();
	document.getElementById("form1").reset();
}
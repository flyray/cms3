$(document).ready(function(){
    $("table tr").mouseover(function(){
    	$(this).addClass("tover");
  }).mouseout(function(){
    	$(this).removeClass("tover");
    });
});
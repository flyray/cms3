// JavaScript Document
$(document).ready(function(){

	   var checkcode=null;
	   $.get("imageNumCheck ",{inputString:$(this).val()}
		,function(result){
			var json = eval('(' + result + ')');
			if(json.yes==1){
				$("#chekmsg").text();
				
				return checkcode=true;
			}else{
				$("#chekmsg").text();
				
				return checkcode=false;
			}
		});
		//验证用户名
		$("#adminname").focus(function(){
			$("#name_tixing").text("");
		});
		
		$("#adminname").blur(function(){
			var username=$("#adminname").val();
			if(username==""){
			$("#name_tixing").text("请输入用户名！");
			return false;
			}else{
				$("#name_tixing").text("");
				}
			});
		
		//验证密码	
		$("#adminpass").focus(function(){
			$("#psw_tixing").text("");
		});
		
		$("#adminpass").blur(function(){
			var password=$("#adminpass").val();
			if(password==""){
			$("#psw_tixing").text("请输入密码！");
			return false;
			}else{
				$("#psw_tixing").text("");
				}
			});
		//验证验证码
		$("#checkCodeImg").click(function(){
			$(this).attr("src","imagevalidate");
			$("#chekmsg").text("");
		});
		$("#chknumber").blur(function(){
			$.get("imageNumCheck ",{inputString:$(this).val()}
			,function(result){
				var json = eval('(' + result + ')');
				if(json.yes==1){
					$("#chekmsg").text();
					$("#chekmsg").text("√");
					return checkcode=true;
				}else{
					$("#chekmsg").text();
					$("#chekmsg").text("×");
					return checkcode=false;
				}
			});
		});
			//登录验证

		
		$("#enter").click(function(){
			
			
			var password=$("#adminpass").val();
			var username=$("#adminname").val();
			var chkval=$("#chknumber").val();
			 if(username==""){
			$("#name_tixing").text("请输入用户名！");
			return false;
			}
			if(password==""){
			$("#psw_tixing").text("请输入密码！");
			return false;
			}
			if(chkval == ""){

				$("#chekmsg").text("×");
				return false;
			}
			if(checkcode == false){
				return false;
			}
			
			document.getElementById("login").submit();

			});
		
	       //重置
		   $("#reset").click(function(){
			   $(".testfield").val(this.defaultValue);
			   $("#chknumber").val(this.defaultValue);
			   $("#name_tixing").text("");
			   $("#psw_tixing").text("");
			   $("#chk_tixing").text("");

			   });   
		//----------------------------------

















	
		
	
	});
		